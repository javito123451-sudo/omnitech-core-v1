--
-- PostgreSQL database dump
--

\restrict iCWwGulIsalvBax5cpoJ5sURpVuZTc6cW1xgE9S44gOjKYdC4VCY7cmzL23J5Nt

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity (
    id integer NOT NULL,
    type text NOT NULL,
    description text NOT NULL,
    client_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL,
    user_id integer
);


ALTER TABLE public.activity OWNER TO postgres;

--
-- Name: activity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_id_seq OWNER TO postgres;

--
-- Name: activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_id_seq OWNED BY public.activity.id;


--
-- Name: agent_memory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_memory (
    id integer NOT NULL,
    org_id integer NOT NULL,
    agent_slug text NOT NULL,
    memory_key text NOT NULL,
    memory_val text NOT NULL,
    source text DEFAULT 'user_input'::text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    title text,
    category text,
    tags text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.agent_memory OWNER TO postgres;

--
-- Name: agent_memory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agent_memory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_memory_id_seq OWNER TO postgres;

--
-- Name: agent_memory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agent_memory_id_seq OWNED BY public.agent_memory.id;


--
-- Name: ai_budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_budgets (
    id integer NOT NULL,
    org_id integer NOT NULL,
    monthly_budget_usd numeric(10,2) DEFAULT 10.00,
    alert_80 boolean DEFAULT true,
    alert_90 boolean DEFAULT true,
    block_at_100 boolean DEFAULT true,
    is_blocked boolean DEFAULT false,
    block_reason text,
    updated_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_budgets OWNER TO postgres;

--
-- Name: ai_budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_budgets_id_seq OWNER TO postgres;

--
-- Name: ai_budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_budgets_id_seq OWNED BY public.ai_budgets.id;


--
-- Name: ai_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_messages (
    id integer NOT NULL,
    session_id uuid NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    tokens_used integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_messages OWNER TO postgres;

--
-- Name: ai_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_messages_id_seq OWNER TO postgres;

--
-- Name: ai_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_messages_id_seq OWNED BY public.ai_messages.id;


--
-- Name: ai_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id integer NOT NULL,
    user_id integer NOT NULL,
    agent_slug text DEFAULT 'operator'::text NOT NULL,
    title text,
    client_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_sessions OWNER TO postgres;

--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_usage_logs (
    id integer NOT NULL,
    org_id integer,
    user_clerk_id text,
    function_name text NOT NULL,
    model text NOT NULL,
    tokens_input integer DEFAULT 0,
    tokens_output integer DEFAULT 0,
    tokens_total integer DEFAULT 0,
    cost_usd numeric(10,6) DEFAULT 0,
    duration_ms integer,
    status text DEFAULT 'ok'::text,
    error_msg text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_usage_logs OWNER TO postgres;

--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_usage_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_usage_logs_id_seq OWNER TO postgres;

--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_usage_logs_id_seq OWNED BY public.ai_usage_logs.id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    client_id integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    type text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    reminder boolean DEFAULT false NOT NULL,
    tags text,
    location text,
    org_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    actor_clerk_id text,
    actor_email text,
    action text NOT NULL,
    resource text,
    resource_id text,
    org_id integer,
    ip_address text,
    user_agent text,
    details jsonb,
    severity text DEFAULT 'info'::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_jobs (
    id integer NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    org_id integer,
    file_path text,
    file_name text,
    size_bytes bigint,
    checksum text,
    row_count integer,
    error text,
    triggered_by text,
    metadata jsonb,
    started_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    expires_at timestamp without time zone
);


ALTER TABLE public.backup_jobs OWNER TO postgres;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_jobs_id_seq OWNER TO postgres;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_jobs_id_seq OWNED BY public.backup_jobs.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    company text,
    status text DEFAULT 'lead'::text NOT NULL,
    tags text,
    notes text,
    value real,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL,
    telegram_chat_id text,
    lead_score text DEFAULT 'cold'::text,
    lead_intent text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_id_seq OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: import_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.import_jobs (
    id integer NOT NULL,
    org_id integer,
    user_clerk_id text,
    status text DEFAULT 'completed'::text,
    file_name text,
    file_type text,
    detected_type text,
    confidence_pct integer DEFAULT 0,
    raw_text text,
    extracted_data jsonb,
    suggested_dest text,
    duplicates_found jsonb,
    records_created integer DEFAULT 0,
    errors text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.import_jobs OWNER TO postgres;

--
-- Name: import_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.import_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.import_jobs_id_seq OWNER TO postgres;

--
-- Name: import_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.import_jobs_id_seq OWNED BY public.import_jobs.id;


--
-- Name: integration_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_events (
    id integer NOT NULL,
    org_id integer NOT NULL,
    integration_slug text NOT NULL,
    direction text DEFAULT 'inbound'::text NOT NULL,
    event_type text NOT NULL,
    status text DEFAULT 'processed'::text NOT NULL,
    summary text,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    payload_json text
);


ALTER TABLE public.integration_events OWNER TO postgres;

--
-- Name: integration_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.integration_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.integration_events_id_seq OWNER TO postgres;

--
-- Name: integration_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.integration_events_id_seq OWNED BY public.integration_events.id;


--
-- Name: integrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrations (
    id integer NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    auth_type text NOT NULL,
    description text,
    icon_slug text,
    plan_required text DEFAULT 'free'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.integrations OWNER TO postgres;

--
-- Name: integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.integrations_id_seq OWNER TO postgres;

--
-- Name: integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.integrations_id_seq OWNED BY public.integrations.id;


--
-- Name: knowledge_base; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knowledge_base (
    id integer NOT NULL,
    org_id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.knowledge_base OWNER TO postgres;

--
-- Name: knowledge_base_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knowledge_base_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_base_id_seq OWNER TO postgres;

--
-- Name: knowledge_base_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knowledge_base_id_seq OWNED BY public.knowledge_base.id;


--
-- Name: license_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.license_plans (
    id integer NOT NULL,
    org_id integer NOT NULL,
    plan text DEFAULT 'starter'::text NOT NULL,
    seats integer DEFAULT 5,
    valid_from timestamp without time zone DEFAULT now(),
    valid_until timestamp without time zone,
    is_active boolean DEFAULT true,
    billing_cycle text DEFAULT 'monthly'::text,
    notes text,
    assigned_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.license_plans OWNER TO postgres;

--
-- Name: license_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.license_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.license_plans_id_seq OWNER TO postgres;

--
-- Name: license_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.license_plans_id_seq OWNED BY public.license_plans.id;


--
-- Name: memory_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.memory_history (
    id integer NOT NULL,
    memory_id integer NOT NULL,
    org_id integer NOT NULL,
    action text NOT NULL,
    prev_title text,
    new_title text,
    prev_val text,
    new_val text,
    source text,
    changed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.memory_history OWNER TO postgres;

--
-- Name: memory_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.memory_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.memory_history_id_seq OWNER TO postgres;

--
-- Name: memory_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.memory_history_id_seq OWNED BY public.memory_history.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    client_id integer NOT NULL,
    content text NOT NULL,
    direction text DEFAULT 'outbound'::text NOT NULL,
    is_ai boolean DEFAULT false,
    status text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL,
    channel text DEFAULT 'telegram'::text
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: module_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.module_configs (
    id integer NOT NULL,
    org_id integer NOT NULL,
    module_slug text NOT NULL,
    is_enabled boolean DEFAULT true,
    config jsonb DEFAULT '{}'::jsonb,
    updated_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.module_configs OWNER TO postgres;

--
-- Name: module_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.module_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.module_configs_id_seq OWNER TO postgres;

--
-- Name: module_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.module_configs_id_seq OWNED BY public.module_configs.id;


--
-- Name: org_integrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_integrations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    integration_slug text NOT NULL,
    status text DEFAULT 'inactive'::text NOT NULL,
    config text,
    credentials_enc text,
    display_name text,
    external_id text,
    last_synced_at timestamp without time zone,
    expires_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.org_integrations OWNER TO postgres;

--
-- Name: org_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_integrations_id_seq OWNER TO postgres;

--
-- Name: org_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_integrations_id_seq OWNED BY public.org_integrations.id;


--
-- Name: org_invitations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_invitations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    invited_by integer NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    accepted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.org_invitations OWNER TO postgres;

--
-- Name: org_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_invitations_id_seq OWNER TO postgres;

--
-- Name: org_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_invitations_id_seq OWNED BY public.org_invitations.id;


--
-- Name: org_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_members (
    id integer NOT NULL,
    org_id integer NOT NULL,
    user_id integer NOT NULL,
    role text DEFAULT 'owner'::text NOT NULL,
    joined_at timestamp without time zone DEFAULT now() NOT NULL,
    is_suspended boolean DEFAULT false
);


ALTER TABLE public.org_members OWNER TO postgres;

--
-- Name: org_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_members_id_seq OWNER TO postgres;

--
-- Name: org_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_members_id_seq OWNED BY public.org_members.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    plan text DEFAULT 'free'::text NOT NULL,
    logo_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'active'::text NOT NULL
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizations_id_seq OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: platform_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_roles (
    id integer NOT NULL,
    clerk_user_id text NOT NULL,
    role text DEFAULT 'STAFF_OMNITECH'::text NOT NULL,
    display_name text,
    email text,
    granted_by text,
    is_active boolean DEFAULT true,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.platform_roles OWNER TO postgres;

--
-- Name: platform_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.platform_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.platform_roles_id_seq OWNER TO postgres;

--
-- Name: platform_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.platform_roles_id_seq OWNED BY public.platform_roles.id;


--
-- Name: quote_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quote_items (
    id integer NOT NULL,
    quote_id integer NOT NULL,
    description text NOT NULL,
    quantity real DEFAULT 1 NOT NULL,
    unit_price real DEFAULT 0 NOT NULL,
    total real DEFAULT 0 NOT NULL,
    order_index integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.quote_items OWNER TO postgres;

--
-- Name: quote_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quote_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quote_items_id_seq OWNER TO postgres;

--
-- Name: quote_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quote_items_id_seq OWNED BY public.quote_items.id;


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotes (
    id integer NOT NULL,
    org_id integer NOT NULL,
    client_id integer NOT NULL,
    title text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    subtotal real DEFAULT 0 NOT NULL,
    tax_rate real DEFAULT 21 NOT NULL,
    tax_amount real DEFAULT 0 NOT NULL,
    total real DEFAULT 0 NOT NULL,
    notes text,
    valid_until timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quotes OWNER TO postgres;

--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotes_id_seq OWNER TO postgres;

--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- Name: role_catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_catalog (
    role text NOT NULL,
    scope text NOT NULL,
    description text,
    priority integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.role_catalog OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    clerk_id text NOT NULL,
    email text NOT NULL,
    name text,
    avatar_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    suspended_reason text,
    suspended_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity ALTER COLUMN id SET DEFAULT nextval('public.activity_id_seq'::regclass);


--
-- Name: agent_memory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory ALTER COLUMN id SET DEFAULT nextval('public.agent_memory_id_seq'::regclass);


--
-- Name: ai_budgets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets ALTER COLUMN id SET DEFAULT nextval('public.ai_budgets_id_seq'::regclass);


--
-- Name: ai_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages ALTER COLUMN id SET DEFAULT nextval('public.ai_messages_id_seq'::regclass);


--
-- Name: ai_usage_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_usage_logs_id_seq'::regclass);


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backup_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_jobs ALTER COLUMN id SET DEFAULT nextval('public.backup_jobs_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: import_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs ALTER COLUMN id SET DEFAULT nextval('public.import_jobs_id_seq'::regclass);


--
-- Name: integration_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events ALTER COLUMN id SET DEFAULT nextval('public.integration_events_id_seq'::regclass);


--
-- Name: integrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations ALTER COLUMN id SET DEFAULT nextval('public.integrations_id_seq'::regclass);


--
-- Name: knowledge_base id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base ALTER COLUMN id SET DEFAULT nextval('public.knowledge_base_id_seq'::regclass);


--
-- Name: license_plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans ALTER COLUMN id SET DEFAULT nextval('public.license_plans_id_seq'::regclass);


--
-- Name: memory_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history ALTER COLUMN id SET DEFAULT nextval('public.memory_history_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: module_configs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs ALTER COLUMN id SET DEFAULT nextval('public.module_configs_id_seq'::regclass);


--
-- Name: org_integrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations ALTER COLUMN id SET DEFAULT nextval('public.org_integrations_id_seq'::regclass);


--
-- Name: org_invitations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations ALTER COLUMN id SET DEFAULT nextval('public.org_invitations_id_seq'::regclass);


--
-- Name: org_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members ALTER COLUMN id SET DEFAULT nextval('public.org_members_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: platform_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles ALTER COLUMN id SET DEFAULT nextval('public.platform_roles_id_seq'::regclass);


--
-- Name: quote_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items ALTER COLUMN id SET DEFAULT nextval('public.quote_items_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity (id, type, description, client_name, created_at, org_id, user_id) FROM stdin;
93	quote_accepted	Presupuesto aceptado: Campaña Marketing Digital Q3 2026	Clínica Dental Peñalver	2026-05-26 12:58:18.48976	10	\N
94	quote_accepted	Presupuesto aceptado: Consultoría Estratégica CRM	Inmobiliaria Costa Blanca	2026-05-31 12:58:18.48976	10	\N
95	client_created	Nuevo lead registrado desde WhatsApp	Fontanería García e Hijos	2026-06-08 12:58:18.48976	10	\N
96	message_received	Mensaje recibido: consulta sobre CRM para hostelería	Restaurante El Rincón de Pepe	2026-06-08 12:58:18.48976	10	\N
97	appointment_set	Cita agendada: Demo CRM para restaurante	Restaurante El Rincón de Pepe	2026-06-14 12:58:18.48976	10	\N
98	client_created	Nuevo lead: interés en módulo de citas online	Peluquería Estilo Moderno	2026-06-10 12:58:18.48976	10	\N
99	quote_sent	Presupuesto enviado: Mantenimiento Web Plan Anual	Construcciones Martínez S.L.	2026-06-10 12:58:18.48976	10	\N
100	appointment_set	Reunión de seguimiento confirmada — mañana 10h	Construcciones Martínez S.L.	2026-06-12 12:58:18.48976	10	\N
101	client_added	[Omni Import AI] Cliente 1 (Empresa 1)	\N	2026-06-15 14:45:09.802158	8	\N
102	client_added	[Omni Import AI] Cliente 2 (Empresa 2)	\N	2026-06-15 14:45:09.841919	8	\N
103	client_added	[Omni Import AI] Cliente 3 (Empresa 3)	\N	2026-06-15 14:45:09.862771	8	\N
104	client_added	[Omni Import AI] Cliente 4 (Empresa 4)	\N	2026-06-15 14:45:09.920503	8	\N
105	client_added	[Omni Import AI] Cliente 5 (Empresa 5)	\N	2026-06-15 14:45:09.929981	8	\N
106	client_added	[Omni Import AI] Cliente 6 (Empresa 6)	\N	2026-06-15 14:45:09.947678	8	\N
107	client_added	[Omni Import AI] Cliente 7 (Empresa 7)	\N	2026-06-15 14:45:09.967857	8	\N
108	client_added	[Omni Import AI] Cliente 8 (Empresa 8)	\N	2026-06-15 14:45:10.001711	8	\N
109	client_added	[Omni Import AI] Cliente 9 (Empresa 9)	\N	2026-06-15 14:45:10.028063	8	\N
110	client_added	[Omni Import AI] Cliente 10 (Empresa 10)	\N	2026-06-15 14:45:10.055612	8	\N
111	client_added	[Omni Import AI] Cliente 11 (Empresa 11)	\N	2026-06-15 14:45:10.090005	8	\N
112	client_added	[Omni Import AI] Cliente 12 (Empresa 12)	\N	2026-06-15 14:45:10.145147	8	\N
113	client_added	[Omni Import AI] Cliente 13 (Empresa 13)	\N	2026-06-15 14:45:10.170714	8	\N
114	client_added	[Omni Import AI] Cliente 14 (Empresa 14)	\N	2026-06-15 14:45:10.212827	8	\N
115	client_added	[Omni Import AI] Cliente 15 (Empresa 15)	\N	2026-06-15 14:45:10.223899	8	\N
116	client_added	[Omni Import AI] Cliente 16 (Empresa 16)	\N	2026-06-15 14:45:10.241139	8	\N
117	client_added	[Omni Import AI] Cliente 17 (Empresa 17)	\N	2026-06-15 14:45:10.24849	8	\N
118	client_added	[Omni Import AI] Cliente 18 (Empresa 18)	\N	2026-06-15 14:45:10.27235	8	\N
119	client_added	[Omni Import AI] Cliente 19 (Empresa 19)	\N	2026-06-15 14:45:10.300192	8	\N
120	client_added	[Omni Import AI] Cliente 20 (Empresa 20)	\N	2026-06-15 14:45:10.339924	8	\N
121	quote_created	Presupuesto "Propuesta de Automatización de WhatsApp para Cliente 20" creado para Cliente 20 — 3025,00 €	Cliente 20	2026-06-15 14:47:08.603355	8	7
122	client_added	New client PRUEBA REAL 001 was added	PRUEBA REAL 001	2026-06-16 10:44:12.221878	8	7
\.


--
-- Data for Name: agent_memory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_memory (id, org_id, agent_slug, memory_key, memory_val, source, updated_at, title, category, tags, created_at) FROM stdin;
\.


--
-- Data for Name: ai_budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_budgets (id, org_id, monthly_budget_usd, alert_80, alert_90, block_at_100, is_blocked, block_reason, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_messages (id, session_id, role, content, tokens_used, created_at) FROM stdin;
\.


--
-- Data for Name: ai_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_sessions (id, org_id, user_id, agent_slug, title, client_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_usage_logs (id, org_id, user_clerk_id, function_name, model, tokens_input, tokens_output, tokens_total, cost_usd, duration_ms, status, error_msg, metadata, created_at) FROM stdin;
7	8	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	import_ai_analysis	gpt-4o	1547	204	1751	0.010795	3425	ok	\N	\N	2026-06-15 14:42:10.237815
8	8	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	import_ai_analysis	gpt-4o	719	1921	2640	0.032410	13557	ok	\N	\N	2026-06-15 14:44:25.612386
9	8	\N	executive_ceo	gpt-4o-mini	878	477	1355	0.000418	\N	ok	\N	\N	2026-06-15 14:49:24.226377
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (id, title, description, start_time, end_time, client_id, status, type, created_at, reminder, tags, location, org_id) FROM stdin;
33	Seguimiento proyecto e-Commerce	Revisión avance módulos y planificación siguiente sprint.	2026-06-16 22:58:18.48976	2026-06-16 23:58:18.48976	202	confirmed	meeting	2026-06-12 12:58:18.48976	t	\N	Av. del Puerto 32, Valencia	10
34	Resultados campaña marketing Q2	Dashboard de métricas y propuesta Q3.	2026-06-18 04:58:18.48976	2026-06-18 05:58:18.48976	203	confirmed	call	2026-06-10 12:58:18.48976	t	\N	Videollamada Google Meet	10
35	Consultoría CRM: Análisis de procesos	Mapeo de flujos comerciales actuales y pain points.	2026-06-18 21:58:18.48976	2026-06-18 23:58:18.48976	209	confirmed	meeting	2026-06-13 12:58:18.48976	t	\N	Calle Mayor 15, Madrid	10
36	Entrega identidad corporativa	Presentación propuestas de logo. Cliente revisa y aprueba.	2026-06-20 00:58:18.48976	2026-06-20 01:58:18.48976	205	pending	call	2026-06-14 12:58:18.48976	f	\N	Videollamada Zoom	10
37	Demo OmniTech CRM — Restaurante	Demostración módulo gestión de clientes y reservas.	2026-06-20 23:58:18.48976	2026-06-21 00:58:18.48976	204	pending	demo	2026-06-15 12:58:18.48976	f	\N	Plaza Mayor 7, Sevilla	10
38	Propuesta gestión citas peluquería	Explicación módulo calendario y reservas online.	2026-06-22 22:58:18.48976	2026-06-22 23:28:18.48976	206	pending	call	2026-06-15 12:58:18.48976	f	\N	Videollamada WhatsApp	10
39	Consultoría CRM: Configuración inicial	Configuración CRM, importación de datos y flujos automatizados.	2026-06-25 21:58:18.48976	2026-06-25 23:58:18.48976	209	confirmed	meeting	2026-06-14 12:58:18.48976	t	\N	Calle Mayor 15, Madrid	10
40	Kick-off campaña Q3 — Planning	Calendario editorial y distribución presupuesto Ads.	2026-06-28 03:58:18.48976	2026-06-28 04:58:18.48976	203	pending	meeting	2026-06-15 12:58:18.48976	f	\N	Videollamada Google Meet	10
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, actor_clerk_id, actor_email, action, resource, resource_id, org_id, ip_address, user_agent, details, severity, created_at) FROM stdin;
18	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	7	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "Omnitech venta", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-15 11:42:55.740574
19	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	7	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "Omnitech venta", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-15 11:42:55.741882
20	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_login	session	\N	7	192.168.1.10	\N	{"result": "success", "userName": "Juan García"}	info	2026-06-15 12:25:33.153457
21	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_logout	session	\N	7	192.168.1.10	\N	{"result": "success", "userName": "Juan García"}	info	2026-06-15 12:25:33.153457
22	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_created	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "email": "info@modelo.es", "result": "success", "status": "lead"}	info	2026-06-15 12:25:33.153457
23	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_updated	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "result": "success", "changes": ["phone", "status"]}	info	2026-06-15 12:25:33.153457
24	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_deleted	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "email": "info@modelo.es", "result": "success"}	warning	2026-06-15 12:25:33.153457
25	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	import_completed	import	\N	7	192.168.1.10	\N	{"errors": 0, "result": "success", "created": 47, "updated": 3, "fileName": "clientes_mayo.xlsx"}	info	2026-06-15 12:25:33.153457
26	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	integration_connected	integration	whatsapp	7	192.168.1.10	\N	{"slug": "whatsapp", "result": "success"}	info	2026-06-15 12:25:33.153457
27	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	integration_disconnected	integration	whatsapp	7	192.168.1.10	\N	{"slug": "whatsapp", "result": "success"}	warning	2026-06-15 12:25:33.153457
28	system:whatsapp:7	\N	whatsapp_message_received	whatsapp_message	wamid.test001	7	\N	\N	{"text": "Acepto el presupuesto", "phone": "611234567", "result": "success", "clientName": "Pedro López"}	info	2026-06-15 12:25:33.153457
29	system:whatsapp:7	\N	whatsapp_quote_accepted	quote	15	7	\N	\N	{"result": "accepted", "clientName": "Pedro López", "quoteTitle": "Mantenimiento Anual"}	info	2026-06-15 12:25:33.153457
30	system:whatsapp:7	\N	whatsapp_quote_rejected	quote	16	7	\N	\N	{"result": "rejected", "clientName": "Ana Martínez", "quoteTitle": "Instalación Premium"}	info	2026-06-15 12:25:33.153457
31	user_3ExXLGMKxDArT1bBizVRyyNkH9N	admin@omnitech.com	workspace_suspended	workspace	5	\N	10.0.0.1	\N	{"reason": "Pago pendiente", "result": "success"}	warning	2026-06-15 12:25:33.153457
32	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	\N	import_completed	import	\N	8	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"total": 20, "errors": 0, "result": "success", "created": 20, "skipped": 0, "updated": 0}	info	2026-06-15 14:45:10.339917
33	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "userName": "a3servicios servicios"}	info	2026-06-15 14:57:45.343305
34	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	8	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "Demos", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-16 07:04:15.596168
35	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_login	session	\N	10	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "OmniTech Demo", "orgRole": "owner", "userName": "a3servicios servicios"}	info	2026-06-16 07:04:34.156061
36	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	\N	integration_connected	integration	whatsapp	10	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"name": "WhatsApp Business", "slug": "whatsapp", "result": "success", "displayName": null, "hasCredentials": true}	info	2026-06-16 07:12:22.336582
37	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "userName": "Javilisto123 123"}	info	2026-06-16 09:07:11.131973
38	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "userName": "Javilisto123 123"}	info	2026-06-16 09:07:40.77428
39	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	\N	integration_connected	integration	whatsapp	8	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	{"name": "WhatsApp Business", "slug": "whatsapp", "result": "success", "displayName": null, "hasCredentials": true}	info	2026-06-16 10:14:21.324991
40	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	\N	integration_connected	integration	whatsapp	8	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	{"name": "WhatsApp Business", "slug": "whatsapp", "result": "success", "displayName": null, "hasCredentials": true}	info	2026-06-16 10:31:27.436354
41	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	\N	client_created	client	230	8	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	{"name": "PRUEBA REAL 001", "email": "PRUEBA@GMAIL.COM", "result": "success", "status": "lead", "company": "TECORE"}	info	2026-06-16 10:44:12.257919
42	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	8	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	{"result": "success", "orgName": "Demos", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-16 20:03:03.9867
43	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	\N	integration_connected	integration	whatsapp	8	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	{"name": "WhatsApp Business", "slug": "whatsapp", "result": "success", "displayName": null, "hasCredentials": true}	info	2026-06-16 20:03:36.769949
44	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_login	session	\N	10	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "OmniTech Demo", "orgRole": "owner", "userName": "a3servicios servicios"}	info	2026-06-16 21:41:24.447975
45	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	\N	integration_connected	integration	telegram	8	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"name": "Telegram Bot", "slug": "telegram", "result": "success", "displayName": "Omnitech_bot", "hasCredentials": true}	info	2026-06-16 21:50:46.511206
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_jobs (id, type, status, org_id, file_path, file_name, size_bytes, checksum, row_count, error, triggered_by, metadata, started_at, completed_at, expires_at) FROM stdin;
26	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 09:13:26.336949	2026-06-16 09:13:26.369	2026-07-16 09:13:26.336
5	workspace	completed	7	/home/runner/workspace/backups/workspace_7_2026-06-15T12-40-10.json	workspace_7_2026-06-15T12-40-10.json	1205	c3d508a9cc90b7d8cd274596d7b84eb9056a5c786fd6ba0053c44374aedc10f6	4	\N	test:manual	{"orgId": 7}	2026-06-15 12:42:42.229026	2026-06-15 12:42:42.229026	2026-07-15 12:42:42.229026
6	config	completed	\N	/home/runner/workspace/backups/config_platform_2026-06-15T12-40-14.json	config_platform_2026-06-15T12-40-14.json	2672	a6c53f51ebab5c39b6c2c00e30b4244cc62e504e6a14035167d9fdb496a23e6d	12	\N	test:manual	{}	2026-06-15 12:42:44.326804	2026-06-15 12:42:44.326804	2026-07-15 12:42:44.326804
7	audit	completed	\N	/home/runner/workspace/backups/audit_platform_2026-06-15T12-40-34.json	audit_platform_2026-06-15T12-40-34.json	5510	67c35082b40bf169c703ca1d497727b4650ca0fde1377150977581237fd0a4f3	14	\N	test:manual	{"totalLogs": 14}	2026-06-15 12:42:45.081958	2026-06-15 12:42:45.081958	2026-07-15 12:42:45.081958
11	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-15T12-41-15.sql.gz	full_db_2026-06-15T12-41-15.sql.gz	9597	132088dfdb2ea80cdb811265fa281b0212731371b6c85c7183c01fa10795eae0	\N	\N	test:manual	{"lines": 2228, "tables": 26}	2026-06-15 12:43:34.332691	2026-06-15 12:43:34.332691	2026-07-15 12:43:34.332691
12	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-15T12-45-35.sql.gz	full_db_2026-06-15T12-45-35.sql.gz	10056	81858cd91083e8472850c3b9448e6580d7f68739d5ee1044416106d68ace30f1	\N	\N	auto:scheduler	\N	2026-06-15 12:45:35.206557	2026-06-15 12:45:36.274	2026-07-15 12:45:35.163
13	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-15 12:45:36.344582	2026-06-15 12:45:36.42	2026-07-15 12:45:36.343
14	full_db	completed	\N	/home/runner/workspace/backups/pre_launch_backup_2026-06-15T12-54-21.sql.gz	pre_launch_backup_2026-06-15T12-54-21.sql.gz	10184	3e650f5ce78cba09f14239e72e21bc275551b512fa2f1b0f51e751f3b5ff63a6	\N	\N	system:pre_launch	{"reason": "pre-launch cleanup backup"}	2026-06-15 12:54:22.530745	2026-06-15 12:54:22.530745	2026-09-13 12:54:22.530745
15	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-15T14-38-15.sql.gz	full_db_2026-06-15T14-38-15.sql.gz	12038	99c578e3d63a70afd1b450d792f4a4e7b32391693389eac27e8d3f5a723d5899	\N	\N	auto:scheduler	\N	2026-06-15 14:38:15.604663	2026-06-15 14:38:17.959	2026-07-15 14:38:15.602
16	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-15 14:38:18.06243	2026-06-15 14:38:18.25	2026-07-15 14:38:18.061
17	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T07-04-09.sql.gz	full_db_2026-06-16T07-04-09.sql.gz	18561	1ab21accaa49e79834964a4a237d52f51d24a8cffbb4a23cc305c03514aaa8fb	\N	\N	auto:scheduler	\N	2026-06-16 07:04:09.553833	2026-06-16 07:04:11.66	2026-07-16 07:04:09.437
18	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 07:04:11.698879	2026-06-16 07:04:11.932	2026-07-16 07:04:11.696
19	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T07-21-41.sql.gz	full_db_2026-06-16T07-21-41.sql.gz	18951	9388c23b46c309c4f6c248fafce39411497e65ec4a1123a3ffba74cbe7f3cc90	\N	\N	auto:scheduler	\N	2026-06-16 07:21:41.659997	2026-06-16 07:21:42.453	2026-07-16 07:21:41.447
20	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 07:21:42.461017	2026-06-16 07:21:42.498	2026-07-16 07:21:42.46
21	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T08-14-21.sql.gz	full_db_2026-06-16T08-14-21.sql.gz	19048	b3530459d25e223b2f34b971c91fc6b1e12060adf098c50bf8b9cf89eeb1dbd4	\N	\N	auto:scheduler	\N	2026-06-16 08:14:21.609585	2026-06-16 08:14:22.335	2026-07-16 08:14:21.44
22	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 08:14:22.343009	2026-06-16 08:14:22.39	2026-07-16 08:14:22.342
23	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T09-05-10.sql.gz	full_db_2026-06-16T09-05-10.sql.gz	19140	5312db359d3108a62a9f4cb3d08963ae9bdc1b2c6a24aa941aae9d4e3d6cb02a	\N	\N	auto:scheduler	\N	2026-06-16 09:05:10.247245	2026-06-16 09:05:11.375	2026-07-16 09:05:09.334
24	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 09:05:11.403153	2026-06-16 09:05:11.437	2026-07-16 09:05:11.402
25	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T09-13-25.sql.gz	full_db_2026-06-16T09-13-25.sql.gz	19266	e217e7bfc8566bcd5cda4724b87ccf4544a6c279d7fd91e6d4ef21579e204ba1	\N	\N	auto:scheduler	\N	2026-06-16 09:13:25.697565	2026-06-16 09:13:26.33	2026-07-16 09:13:25.676
27	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T09-37-37.sql.gz	full_db_2026-06-16T09-37-37.sql.gz	19372	17420a79c543179048862af2e7658c3b87ea1b3239efed76bf6374e1d1609057	\N	\N	auto:scheduler	\N	2026-06-16 09:37:37.273143	2026-06-16 09:37:38.02	2026-07-16 09:37:36.845
28	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 09:37:38.027355	2026-06-16 09:37:38.058	2026-07-16 09:37:38.026
29	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T10-20-58.sql.gz	full_db_2026-06-16T10-20-58.sql.gz	20028	0e66a9d07bde5aab3098c098d526f7a05921aef4f6140799d6e2b10fd2d52377	\N	\N	auto:scheduler	\N	2026-06-16 10:20:58.652784	2026-06-16 10:20:59.376	2026-07-16 10:20:58.552
30	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 10:20:59.386474	2026-06-16 10:20:59.437	2026-07-16 10:20:59.385
31	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T10-36-27.sql.gz	full_db_2026-06-16T10-36-27.sql.gz	20126	b2ef8f038e33f120abed1dfbf1f5cfbecf0dc858606427107ca37dd23e22f3bb	\N	\N	auto:scheduler	\N	2026-06-16 10:36:27.496374	2026-06-16 10:36:28.265	2026-07-16 10:36:27.366
32	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 10:36:28.275734	2026-06-16 10:36:28.312	2026-07-16 10:36:28.273
33	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T10-39-05.sql.gz	full_db_2026-06-16T10-39-05.sql.gz	20245	f3a03cbe78598785b6e834b03f49686832b19c847fa0abdab2b080d5df92fb34	\N	\N	auto:scheduler	\N	2026-06-16 10:39:05.269023	2026-06-16 10:39:06.208	2026-07-16 10:39:04.642
34	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 10:39:06.215685	2026-06-16 10:39:06.273	2026-07-16 10:39:06.214
35	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T20-04-32.sql.gz	full_db_2026-06-16T20-04-32.sql.gz	20688	445437a6108643a24f1a14c429d127d0ea0f49cc38faf2edd78f4ccd286c4190	\N	\N	auto:scheduler	\N	2026-06-16 20:04:32.240266	2026-06-16 20:04:34.239	2026-07-16 20:04:31.71
36	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 20:04:34.257037	2026-06-16 20:04:34.35	2026-07-16 20:04:34.256
37	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T21-32-21.sql.gz	full_db_2026-06-16T21-32-21.sql.gz	20804	6c9793d91cf24eb1983ea6dec770124bb88af3e2011833abe1768750eff62553	\N	\N	auto:scheduler	\N	2026-06-16 21:32:20.95524	2026-06-16 21:32:22.392	2026-07-16 21:32:20.828
38	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 21:32:22.403106	2026-06-16 21:32:22.449	2026-07-16 21:32:22.402
39	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T21-39-53.sql.gz	full_db_2026-06-16T21-39-53.sql.gz	20915	1df84c69dc1f3824b8cf60c6fe370a81880479c6beae7d1af233dd02e8bf749b	\N	\N	auto:scheduler	\N	2026-06-16 21:39:53.876274	2026-06-16 21:39:54.197	2026-07-16 21:39:53.667
40	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 21:39:54.215324	2026-06-16 21:39:54.24	2026-07-16 21:39:54.214
41	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T21-51-13.sql.gz	full_db_2026-06-16T21-51-13.sql.gz	21222	85024f3e9cf50bc135a8a7862826ecdb59dbc01bd4cf3c8ed258163236c5d52d	\N	\N	auto:scheduler	\N	2026-06-16 21:51:13.528255	2026-06-16 21:51:13.923	2026-07-16 21:51:13.527
42	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 21:51:13.931976	2026-06-16 21:51:13.963	2026-07-16 21:51:13.931
43	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T22-44-07.sql.gz	full_db_2026-06-16T22-44-07.sql.gz	23011	37d927658df5aea175acd8982ab9546ef9c117b1d8b872312b05000361f42079	\N	\N	auto:scheduler	\N	2026-06-16 22:44:07.301082	2026-06-16 22:44:07.99	2026-07-16 22:44:07.013
44	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 22:44:08.008358	2026-06-16 22:44:08.165	2026-07-16 22:44:08.007
45	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T22-56-19.sql.gz	full_db_2026-06-16T22-56-19.sql.gz	24923	a13bd28b1a3196dc832b3866dc9b5da01da126104e9e934c4de2e6f07b83b79c	\N	\N	auto:scheduler	\N	2026-06-16 22:56:19.186568	2026-06-16 22:56:23.765	2026-07-16 22:56:18.79
46	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 22:56:23.788547	2026-06-16 22:56:23.87	2026-07-16 22:56:23.787
47	full_db	running	\N	\N	\N	\N	\N	\N	\N	auto:scheduler	\N	2026-06-16 23:12:48.689669	\N	2026-07-16 23:12:48.164
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, name, email, phone, company, status, tags, notes, value, created_at, org_id, telegram_chat_id, lead_score, lead_intent, updated_at) FROM stdin;
202	Construcciones Martínez S.L.	info@construccionesmartinez.es	963 412 870	Construcciones Martínez S.L.	active	empresa,construcción,alto-valor	Cliente recurrente. Obras en Valencia y Alicante.	24500	2026-04-01 12:56:10.80667	10	\N	cold	\N	2026-06-16 22:46:24.658883
203	Clínica Dental Peñalver	admin@clinicapenalver.com	91 554 2301	Clínica Dental Peñalver	active	salud,clínica,profesional	Interesados en módulo de citas y recordatorios.	8900	2026-04-16 12:56:10.80667	10	\N	cold	\N	2026-06-16 22:46:24.658883
204	Restaurante El Rincón de Pepe	pepe@elrincondepepe.es	955 234 100	El Rincón de Pepe	lead	hostelería,restaurante,local	Primer contacto por WhatsApp. Pendiente propuesta.	3200	2026-06-01 12:56:10.80667	10	\N	cold	\N	2026-06-16 22:46:24.658883
205	Academia de Idiomas Berlín	direccion@academiaberlín.com	93 667 4412	Academia Berlín S.L.	active	educación,idiomas,academia	Contrato anual renovado. Muy satisfechos.	6400	2026-05-01 12:56:10.80667	10	\N	cold	\N	2026-06-16 22:46:24.658883
206	Fontanería García e Hijos	fontaneria.garcia@gmail.com	687 334 921	García Fontanería	lead	fontanería,autónomo,local	Referido por Construcciones Martínez. Llamar esta semana.	1800	2026-06-08 12:56:10.80667	10	\N	cold	\N	2026-06-16 22:46:24.658883
207	Peluquería Estilo Moderno	hola@estilomoderno.es	671 008 445	Estilo Moderno	lead	belleza,peluquería,local	Quiere presupuesto para gestión de citas online.	2100	2026-06-10 12:56:10.80667	10	\N	cold	\N	2026-06-16 22:46:24.658883
208	Transportes Rápidos Valencia	operaciones@transportesrv.com	961 885 320	Transportes Rápidos Valencia	inactive	logística,transporte,empresa	Contrato pausado. Retomar contacto en septiembre.	15000	2026-02-15 12:56:10.80667	10	\N	cold	\N	2026-06-16 22:46:24.658883
209	Inmobiliaria Costa Blanca	ventas@costablancainmuebles.com	966 734 210	Costa Blanca Inmuebles S.L.	active	inmobiliaria,empresa,alto-valor	CRM para gestión de leads de compra/venta.	19200	2026-05-16 12:56:10.80667	10	\N	cold	\N	2026-06-16 22:46:24.658883
210	Cliente 1	cliente1@test.com	600111001	Empresa 1	client	\N	\N	600	2026-06-15 14:45:09.647975	8	\N	cold	\N	2026-06-16 22:46:24.658883
211	Cliente 2	cliente2@test.com	600111002	Empresa 2	client	\N	\N	700	2026-06-15 14:45:09.83069	8	\N	cold	\N	2026-06-16 22:46:24.658883
212	Cliente 3	cliente3@test.com	600111003	Empresa 3	prospect	\N	\N	800	2026-06-15 14:45:09.841458	8	\N	cold	\N	2026-06-16 22:46:24.658883
213	Cliente 4	cliente4@test.com	600111004	Empresa 4	client	\N	\N	900	2026-06-15 14:45:09.898903	8	\N	cold	\N	2026-06-16 22:46:24.658883
214	Cliente 5	cliente5@test.com	600111005	Empresa 5	client	\N	\N	1000	2026-06-15 14:45:09.920682	8	\N	cold	\N	2026-06-16 22:46:24.658883
215	Cliente 6	cliente6@test.com	600111006	Empresa 6	prospect	\N	\N	1100	2026-06-15 14:45:09.930901	8	\N	cold	\N	2026-06-16 22:46:24.658883
216	Cliente 7	cliente7@test.com	600111007	Empresa 7	client	\N	\N	1200	2026-06-15 14:45:09.947191	8	\N	cold	\N	2026-06-16 22:46:24.658883
217	Cliente 8	cliente8@test.com	600111008	Empresa 8	client	\N	\N	1300	2026-06-15 14:45:09.967138	8	\N	cold	\N	2026-06-16 22:46:24.658883
218	Cliente 9	cliente9@test.com	600111009	Empresa 9	prospect	\N	\N	1400	2026-06-15 14:45:10.001681	8	\N	cold	\N	2026-06-16 22:46:24.658883
219	Cliente 10	cliente10@test.com	600111010	Empresa 10	client	\N	\N	1500	2026-06-15 14:45:10.028046	8	\N	cold	\N	2026-06-16 22:46:24.658883
220	Cliente 11	cliente11@test.com	600111011	Empresa 11	client	\N	\N	1600	2026-06-15 14:45:10.054994	8	\N	cold	\N	2026-06-16 22:46:24.658883
221	Cliente 12	cliente12@test.com	600111012	Empresa 12	prospect	\N	\N	1700	2026-06-15 14:45:10.089701	8	\N	cold	\N	2026-06-16 22:46:24.658883
222	Cliente 13	cliente13@test.com	600111013	Empresa 13	client	\N	\N	1800	2026-06-15 14:45:10.142841	8	\N	cold	\N	2026-06-16 22:46:24.658883
223	Cliente 14	cliente14@test.com	600111014	Empresa 14	client	\N	\N	1900	2026-06-15 14:45:10.171837	8	\N	cold	\N	2026-06-16 22:46:24.658883
224	Cliente 15	cliente15@test.com	600111015	Empresa 15	prospect	\N	\N	2000	2026-06-15 14:45:10.211925	8	\N	cold	\N	2026-06-16 22:46:24.658883
225	Cliente 16	cliente16@test.com	600111016	Empresa 16	client	\N	\N	2100	2026-06-15 14:45:10.22344	8	\N	cold	\N	2026-06-16 22:46:24.658883
226	Cliente 17	cliente17@test.com	600111017	Empresa 17	client	\N	\N	2200	2026-06-15 14:45:10.241927	8	\N	cold	\N	2026-06-16 22:46:24.658883
227	Cliente 18	cliente18@test.com	600111018	Empresa 18	prospect	\N	\N	2300	2026-06-15 14:45:10.248395	8	\N	cold	\N	2026-06-16 22:46:24.658883
228	Cliente 19	cliente19@test.com	600111019	Empresa 19	client	\N	\N	2400	2026-06-15 14:45:10.272476	8	\N	cold	\N	2026-06-16 22:46:24.658883
229	Cliente 20	cliente20@test.com	600111020	Empresa 20	client	\N	\N	2500	2026-06-15 14:45:10.300742	8	\N	cold	\N	2026-06-16 22:46:24.658883
230	PRUEBA REAL 001	PRUEBA@GMAIL.COM	677966378	TECORE	lead	SAAS	ES EL PILOTO DE PRUEBAS	2000	2026-06-16 10:44:12.076633	8	\N	cold	\N	2026-06-16 22:46:24.658883
\.


--
-- Data for Name: import_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.import_jobs (id, org_id, user_clerk_id, status, file_name, file_type, detected_type, confidence_pct, raw_text, extracted_data, suggested_dest, duplicates_found, records_created, errors, created_at) FROM stdin;
5	8	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	completed	OmniTech_Import_100_Clientes.xlsx	xlsx	contact_list	95	[\n  {\n    "ID": 1,\n    "Nombre": "Elena Ortega",\n    "Empresa": "Empresa 1",\n    "Email": "cliente1@empresa.com",\n    "Telefono": "694770925",\n    "Direccion": "Calle 1, Nº 8",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28191",\n    "Estado": "Inactivo",\n    "Preferencia": "Llamada",\n    "Notas": "Cliente de prueba OmniTech"\n  },\n  {\n    "ID": 2,\n    "Nombre": "Laura López",\n    "Empresa": "Empresa 2",\n    "Email": "cliente2@empresa.com",\n    "Telefono": "614891780",\n    "Direccion": "Calle 2, Nº 27",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28922",\n    "Estado": "Activo",\n    "Preferencia": "WhatsApp",\n    "Notas": "Cliente de prueba OmniTech"\n  },\n  {\n    "ID": 3,\n    "Nombre": "Marta García",\n    "Empresa": "Empresa 3",\n    "Email": "cliente3@empresa.com",\n    "Telefono": "617216900",\n    "Direccion": "Calle 3, Nº 84",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28818",\n    "Estado": "Prospecto",\n    "Preferencia": "Email",\n    "Notas": "Cliente de prueba OmniTech"\n  },\n  {\n    "ID": 4,\n    "Nombre": "Luis Torres",\n    "Empresa": "Empresa 4",\n    "Email": "cliente4@empresa.com",\n    "Telefono": "641745314",\n    "Direccion": "Calle 4, Nº 61",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28250",\n    "Estado": "Prospecto",\n    "Preferencia": "WhatsApp",\n    "Notas": "Cliente de prueba OmniTech"\n  },\n  {\n    "ID": 5,\n    "Nombre": "David Ortega",\n    "Empresa": "Empresa 5",\n    "Email": "cliente5@empresa.com",\n    "Telefono": "676537919",\n    "Direccion": "Calle 5, Nº 7",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28560",\n    "Estado": "Activo",\n    "Preferencia": "Llamada",\n    "Notas": "Cliente de prueba OmniTech"\n  }\n]	{"records": [{"cif": null, "name": "Elena Ortega", "tags": null, "email": "cliente1@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "694770925", "value": null, "status": "prospect", "address": "Calle 1, Nº 8, Madrid, Madrid, 28191", "company": "Empresa 1", "website": null, "position": null}, {"cif": null, "name": "Laura López", "tags": null, "email": "cliente2@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "614891780", "value": null, "status": "client", "address": "Calle 2, Nº 27, Madrid, Madrid, 28922", "company": "Empresa 2", "website": null, "position": null}, {"cif": null, "name": "Marta García", "tags": null, "email": "cliente3@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "617216900", "value": null, "status": "prospect", "address": "Calle 3, Nº 84, Madrid, Madrid, 28818", "company": "Empresa 3", "website": null, "position": null}, {"cif": null, "name": "Luis Torres", "tags": null, "email": "cliente4@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "641745314", "value": null, "status": "prospect", "address": "Calle 4, Nº 61, Madrid, Madrid, 28250", "company": "Empresa 4", "website": null, "position": null}, {"cif": null, "name": "David Ortega", "tags": null, "email": "cliente5@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "676537919", "value": null, "status": "client", "address": "Calle 5, Nº 7, Madrid, Madrid, 28560", "company": "Empresa 5", "website": null, "position": null}, {"cif": null, "name": "Elena Martín", "tags": null, "email": "cliente6@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "677040185", "value": null, "status": "client", "address": "Calle 6, Nº 30, Madrid, Madrid, 28390", "company": "Empresa 6", "website": null, "position": null}, {"cif": null, "name": "Sara Martín", "tags": null, "email": "cliente7@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "652959920", "value": null, "status": "prospect", "address": "Calle 7, Nº 98, Madrid, Madrid, 28528", "company": "Empresa 7", "website": null, "position": null}, {"cif": null, "name": "Marta Romero", "tags": null, "email": "cliente8@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "610951633", "value": null, "status": "client", "address": "Calle 8, Nº 26, Madrid, Madrid, 28238", "company": "Empresa 8", "website": null, "position": null}, {"cif": null, "name": "Laura García", "tags": null, "email": "cliente9@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "688646441", "value": null, "status": "prospect", "address": "Calle 9, Nº 90, Madrid, Madrid, 28746", "company": "Empresa 9", "website": null, "position": null}, {"cif": null, "name": "Javier García", "tags": null, "email": "cliente10@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "659351597", "value": null, "status": "prospect", "address": "Calle 10, Nº 65, Madrid, Madrid, 28892", "company": "Empresa 10", "website": null, "position": null}, {"cif": null, "name": "Carlos Pérez", "tags": null, "email": "cliente11@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "672084505", "value": null, "status": "client", "address": "Calle 11, Nº 35, Madrid, Madrid, 28277", "company": "Empresa 11", "website": null, "position": null}, {"cif": null, "name": "Carlos García", "tags": null, "email": "cliente12@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "617083712", "value": null, "status": "client", "address": "Calle 12, Nº 18, Madrid, Madrid, 28904", "company": "Empresa 12", "website": null, "position": null}, {"cif": null, "name": "Carlos Sánchez", "tags": null, "email": "cliente13@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "639076468", "value": null, "status": "prospect", "address": "Calle 13, Nº 7, Madrid, Madrid, 28176", "company": "Empresa 13", "website": null, "position": null}, {"cif": null, "name": "Javier Torres", "tags": null, "email": "cliente14@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "679528055", "value": null, "status": "client", "address": "Calle 14, Nº 62, Madrid, Madrid, 28452", "company": "Empresa 14", "website": null, "position": null}, {"cif": null, "name": "Luis Pérez", "tags": null, "email": "cliente15@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "653661799", "value": null, "status": "client", "address": "Calle 15, Nº 13, Madrid, Madrid, 28406", "company": "Empresa 15", "website": null, "position": null}, {"cif": null, "name": "Javier García", "tags": null, "email": "cliente16@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "688276040", "value": null, "status": "prospect", "address": "Calle 16, Nº 1, Madrid, Madrid, 28685", "company": "Empresa 16", "website": null, "position": null}, {"cif": null, "name": "David Martín", "tags": null, "email": "cliente17@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "677444929", "value": null, "status": "prospect", "address": "Calle 17, Nº 79, Madrid, Madrid, 28604", "company": "Empresa 17", "website": null, "position": null}, {"cif": null, "name": "Sara Navarro", "tags": null, "email": "cliente18@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "652191563", "value": null, "status": "prospect", "address": "Calle 18, Nº 49, Madrid, Madrid, 28390", "company": "Empresa 18", "website": null, "position": null}, {"cif": null, "name": "Sara Sánchez", "tags": null, "email": "cliente19@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "628471045", "value": null, "status": "client", "address": "Calle 19, Nº 56, Madrid, Madrid, 28883", "company": "Empresa 19", "website": null, "position": null}, {"cif": null, "name": "Elena López", "tags": null, "email": "cliente20@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "613763262", "value": null, "status": "prospect", "address": "Calle 20, Nº 94, Madrid, Madrid, 28139", "company": "Empresa 20", "website": null, "position": null}, {"cif": null, "name": "Marta Romero", "tags": null, "email": "cliente21@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "632230875", "value": null, "status": "prospect", "address": "Calle 21, Nº 16, Madrid, Madrid, 28132", "company": "Empresa 21", "website": null, "position": null}, {"cif": null, "name": "Laura Martín", "tags": null, "email": "cliente22@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "671482392", "value": null, "status": "client", "address": "Calle 22, Nº 21, Madrid, Madrid, 28503", "company": "Empresa 22", "website": null, "position": null}, {"cif": null, "name": "Javier López", "tags": null, "email": "cliente23@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "618211430", "value": null, "status": "prospect", "address": "Calle 23, Nº 87, Madrid, Madrid, 28333", "company": "Empresa 23", "website": null, "position": null}, {"cif": null, "name": "Carlos Martín", "tags": null, "email": "cliente24@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "638270204", "value": null, "status": "prospect", "address": "Calle 24, Nº 34, Madrid, Madrid, 28735", "company": "Empresa 24", "website": null, "position": null}, {"cif": null, "name": "Marta López", "tags": null, "email": "cliente25@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "635030747", "value": null, "status": "prospect", "address": "Calle 25, Nº 47, Madrid, Madrid, 28370", "company": "Empresa 25", "website": null, "position": null}, {"cif": null, "name": "Laura López", "tags": null, "email": "cliente26@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "652450419", "value": null, "status": "prospect", "address": "Calle 26, Nº 69, Madrid, Madrid, 28477", "company": "Empresa 26", "website": null, "position": null}, {"cif": null, "name": "Miguel Sánchez", "tags": null, "email": "cliente27@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "618389320", "value": null, "status": "prospect", "address": "Calle 27, Nº 5, Madrid, Madrid, 28262", "company": "Empresa 27", "website": null, "position": null}, {"cif": null, "name": "Miguel Torres", "tags": null, "email": "cliente28@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "651479227", "value": null, "status": "prospect", "address": "Calle 28, Nº 78, Madrid, Madrid, 28890", "company": "Empresa 28", "website": null, "position": null}, {"cif": null, "name": "Javier Torres", "tags": null, "email": "cliente29@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "612859666", "value": null, "status": "prospect", "address": "Calle 29, Nº 14, Madrid, Madrid, 28422", "company": "Empresa 29", "website": null, "position": null}, {"cif": null, "name": "Sara López", "tags": null, "email": "cliente30@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "691990671", "value": null, "status": "prospect", "address": "Calle 30, Nº 52, Madrid, Madrid, 28529", "company": "Empresa 30", "website": null, "position": null}, {"cif": null, "name": "Miguel Martín", "tags": null, "email": "cliente31@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "639319372", "value": null, "status": "prospect", "address": "Calle 31, Nº 89, Madrid, Madrid, 28883", "company": "Empresa 31", "website": null, "position": null}, {"cif": null, "name": "Laura López", "tags": null, "email": "cliente32@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "675060389", "value": null, "status": "client", "address": "Calle 32, Nº 64, Madrid, Madrid, 28426", "company": "Empresa 32", "website": null, "position": null}, {"cif": null, "name": "Miguel Ortega", "tags": null, "email": "cliente33@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "624282297", "value": null, "status": "client", "address": "Calle 33, Nº 56, Madrid, Madrid, 28411", "company": "Empresa 33", "website": null, "position": null}, {"cif": null, "name": "David Navarro", "tags": null, "email": "cliente34@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "684793661", "value": null, "status": "prospect", "address": "Calle 34, Nº 39, Madrid, Madrid, 28198", "company": "Empresa 34", "website": null, "position": null}, {"cif": null, "name": "Ana Navarro", "tags": null, "email": "cliente35@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "623175151", "value": null, "status": "prospect", "address": "Calle 35, Nº 44, Madrid, Madrid, 28331", "company": "Empresa 35", "website": null, "position": null}, {"cif": null, "name": "Laura Martín", "tags": null, "email": "cliente36@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "630417898", "value": null, "status": "client", "address": "Calle 36, Nº 48, Madrid, Madrid, 28861", "company": "Empresa 36", "website": null, "position": null}, {"cif": null, "name": "Miguel Torres", "tags": null, "email": "cliente37@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "617225870", "value": null, "status": "client", "address": "Calle 37, Nº 23, Madrid, Madrid, 28422", "company": "Empresa 37", "website": null, "position": null}, {"cif": null, "name": "Elena Martín", "tags": null, "email": "cliente38@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "672603427", "value": null, "status": "client", "address": "Calle 38, Nº 9, Madrid, Madrid, 28868", "company": "Empresa 38", "website": null, "position": null}, {"cif": null, "name": "Luis Ruiz", "tags": null, "email": "cliente39@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "684209246", "value": null, "status": "prospect", "address": "Calle 39, Nº 93, Madrid, Madrid, 28512", "company": "Empresa 39", "website": null, "position": null}, {"cif": null, "name": "David García", "tags": null, "email": "cliente40@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "622565668", "value": null, "status": "prospect", "address": "Calle 40, Nº 70, Madrid, Madrid, 28589", "company": "Empresa 40", "website": null, "position": null}, {"cif": null, "name": "Elena Navarro", "tags": null, "email": "cliente41@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "646419371", "value": null, "status": "prospect", "address": "Calle 41, Nº 60, Madrid, Madrid, 28796", "company": "Empresa 41", "website": null, "position": null}, {"cif": null, "name": "Sara Ruiz", "tags": null, "email": "cliente42@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "657508317", "value": null, "status": "prospect", "address": "Calle 42, Nº 46, Madrid, Madrid, 28108", "company": "Empresa 42", "website": null, "position": null}, {"cif": null, "name": "Elena Romero", "tags": null, "email": "cliente43@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "673478683", "value": null, "status": "prospect", "address": "Calle 43, Nº 98, Madrid, Madrid, 28541", "company": "Empresa 43", "website": null, "position": null}, {"cif": null, "name": "Miguel García", "tags": null, "email": "cliente44@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "646395654", "value": null, "status": "client", "address": "Calle 44, Nº 6, Madrid, Madrid, 28949", "company": "Empresa 44", "website": null, "position": null}, {"cif": null, "name": "Carlos Sánchez", "tags": null, "email": "cliente45@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "627370608", "value": null, "status": "prospect", "address": "Calle 45, Nº 57, Madrid, Madrid, 28263", "company": "Empresa 45", "website": null, "position": null}, {"cif": null, "name": "Sara García", "tags": null, "email": "cliente46@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "643955381", "value": null, "status": "prospect", "address": "Calle 46, Nº 81, Madrid, Madrid, 28200", "company": "Empresa 46", "website": null, "position": null}, {"cif": null, "name": "David Ruiz", "tags": null, "email": "cliente47@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "670716911", "value": null, "status": "client", "address": "Calle 47, Nº 23, Madrid, Madrid, 28940", "company": "Empresa 47", "website": null, "position": null}, {"cif": null, "name": "Carlos Ruiz", "tags": null, "email": "cliente48@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "643315338", "value": null, "status": "prospect", "address": "Calle 48, Nº 15, Madrid, Madrid, 28589", "company": "Empresa 48", "website": null, "position": null}, {"cif": null, "name": "David López", "tags": null, "email": "cliente49@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "625904237", "value": null, "status": "client", "address": "Calle 49, Nº 49, Madrid, Madrid, 28316", "company": "Empresa 49", "website": null, "position": null}, {"cif": null, "name": "Sara García", "tags": null, "email": "cliente50@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "664230928", "value": null, "status": "prospect", "address": "Calle 50, Nº 18, Madrid, Madrid, 28543", "company": "Empresa 50", "website": null, "position": null}, {"cif": null, "name": "David Torres", "tags": null, "email": "cliente51@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "626872360", "value": null, "status": "prospect", "address": "Calle 51, Nº 72, Madrid, Madrid, 28659", "company": "Empresa 51", "website": null, "position": null}, {"cif": null, "name": "Laura Martín", "tags": null, "email": "cliente52@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "643496619", "value": null, "status": "client", "address": "Calle 52, Nº 46, Madrid, Madrid, 28905", "company": "Empresa 52", "website": null, "position": null}, {"cif": null, "name": "Laura Torres", "tags": null, "email": "cliente53@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "628053374", "value": null, "status": "prospect", "address": "Calle 53, Nº 45, Madrid, Madrid, 28932", "company": "Empresa 53", "website": null, "position": null}, {"cif": null, "name": "Marta Torres", "tags": null, "email": "cliente54@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "693848579", "value": null, "status": "prospect", "address": "Calle 54, Nº 85, Madrid, Madrid, 28779", "company": "Empresa 54", "website": null, "position": null}, {"cif": null, "name": "Carlos Pérez", "tags": null, "email": "cliente55@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "622193283", "value": null, "status": "prospect", "address": "Calle 55, Nº 23, Madrid, Madrid, 28525", "company": "Empresa 55", "website": null, "position": null}, {"cif": null, "name": "Carlos Navarro", "tags": null, "email": "cliente56@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "645142774", "value": null, "status": "prospect", "address": "Calle 56, Nº 9, Madrid, Madrid, 28862", "company": "Empresa 56", "website": null, "position": null}, {"cif": null, "name": "Javier García", "tags": null, "email": "cliente57@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "672235027", "value": null, "status": "prospect", "address": "Calle 57, Nº 22, Madrid, Madrid, 28723", "company": "Empresa 57", "website": null, "position": null}, {"cif": null, "name": "Ana Ruiz", "tags": null, "email": "cliente58@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "699343039", "value": null, "status": "prospect", "address": "Calle 58, Nº 6, Madrid, Madrid, 28793", "company": "Empresa 58", "website": null, "position": null}, {"cif": null, "name": "Elena Navarro", "tags": null, "email": "cliente59@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "662076422", "value": null, "status": "prospect", "address": "Calle 59, Nº 96, Madrid, Madrid, 28227", "company": "Empresa 59", "website": null, "position": null}, {"cif": null, "name": "Javier López", "tags": null, "email": "cliente60@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "695245052", "value": null, "status": "prospect", "address": "Calle 60, Nº 96, Madrid, Madrid, 28885", "company": "Empresa 60", "website": null, "position": null}, {"cif": null, "name": "David Ruiz", "tags": null, "email": "cliente61@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "673938075", "value": null, "status": "client", "address": "Calle 61, Nº 15, Madrid, Madrid, 28875", "company": "Empresa 61", "website": null, "position": null}, {"cif": null, "name": "Luis Navarro", "tags": null, "email": "cliente62@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "689932699", "value": null, "status": "client", "address": "Calle 62, Nº 91, Madrid, Madrid, 28467", "company": "Empresa 62", "website": null, "position": null}, {"cif": null, "name": "Carlos Ruiz", "tags": null, "email": "cliente63@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "680125407", "value": null, "status": "prospect", "address": "Calle 63, Nº 5, Madrid, Madrid, 28413", "company": "Empresa 63", "website": null, "position": null}, {"cif": null, "name": "David Pérez", "tags": null, "email": "cliente64@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "655160623", "value": null, "status": "client", "address": "Calle 64, Nº 67, Madrid, Madrid, 28155", "company": "Empresa 64", "website": null, "position": null}, {"cif": null, "name": "Carlos García", "tags": null, "email": "cliente65@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "690232215", "value": null, "status": "client", "address": "Calle 65, Nº 97, Madrid, Madrid, 28978", "company": "Empresa 65", "website": null, "position": null}, {"cif": null, "name": "Marta Torres", "tags": null, "email": "cliente66@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "617273857", "value": null, "status": "client", "address": "Calle 66, Nº 49, Madrid, Madrid, 28732", "company": "Empresa 66", "website": null, "position": null}, {"cif": null, "name": "Ana Navarro", "tags": null, "email": "cliente67@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "616831738", "value": null, "status": "prospect", "address": "Calle 67, Nº 61, Madrid, Madrid, 28328", "company": "Empresa 67", "website": null, "position": null}, {"cif": null, "name": "David López", "tags": null, "email": "cliente68@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "636315141", "value": null, "status": "prospect", "address": "Calle 68, Nº 43, Madrid, Madrid, 28607", "company": "Empresa 68", "website": null, "position": null}, {"cif": null, "name": "Ana Torres", "tags": null, "email": "cliente69@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "672514158", "value": null, "status": "prospect", "address": "Calle 69, Nº 3, Madrid, Madrid, 28556", "company": "Empresa 69", "website": null, "position": null}, {"cif": null, "name": "Javier Romero", "tags": null, "email": "cliente70@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "656964782", "value": null, "status": "prospect", "address": "Calle 70, Nº 90, Madrid, Madrid, 28510", "company": "Empresa 70", "website": null, "position": null}, {"cif": null, "name": "Miguel Sánchez", "tags": null, "email": "cliente71@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "654151768", "value": null, "status": "prospect", "address": "Calle 71, Nº 65, Madrid, Madrid, 28283", "company": "Empresa 71", "website": null, "position": null}, {"cif": null, "name": "Carlos Martín", "tags": null, "email": "cliente72@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "640701881", "value": null, "status": "client", "address": "Calle 72, Nº 24, Madrid, Madrid, 28433", "company": "Empresa 72", "website": null, "position": null}, {"cif": null, "name": "Laura García", "tags": null, "email": "cliente73@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "623283169", "value": null, "status": "prospect", "address": "Calle 73, Nº 14, Madrid, Madrid, 28931", "company": "Empresa 73", "website": null, "position": null}, {"cif": null, "name": "Luis Pérez", "tags": null, "email": "cliente74@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "644708025", "value": null, "status": "prospect", "address": "Calle 74, Nº 79, Madrid, Madrid, 28407", "company": "Empresa 74", "website": null, "position": null}, {"cif": null, "name": "Miguel Sánchez", "tags": null, "email": "cliente75@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "667176748", "value": null, "status": "client", "address": "Calle 75, Nº 62, Madrid, Madrid, 28474", "company": "Empresa 75", "website": null, "position": null}, {"cif": null, "name": "Marta Pérez", "tags": null, "email": "cliente76@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "651048290", "value": null, "status": "prospect", "address": "Calle 76, Nº 59, Madrid, Madrid, 28688", "company": "Empresa 76", "website": null, "position": null}, {"cif": null, "name": "Luis Sánchez", "tags": null, "email": "cliente77@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "612621152", "value": null, "status": "prospect", "address": "Calle 77, Nº 82, Madrid, Madrid, 28478", "company": "Empresa 77", "website": null, "position": null}, {"cif": null, "name": "Ana Sánchez", "tags": null, "email": "cliente78@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "653636582", "value": null, "status": "prospect", "address": "Calle 78, Nº 22, Madrid, Madrid, 28865", "company": "Empresa 78", "website": null, "position": null}, {"cif": null, "name": "Sara Pérez", "tags": null, "email": "cliente79@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "648909608", "value": null, "status": "client", "address": "Calle 79, Nº 12, Madrid, Madrid, 28121", "company": "Empresa 79", "website": null, "position": null}, {"cif": null, "name": "Ana Pérez", "tags": null, "email": "cliente80@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "690514417", "value": null, "status": "prospect", "address": "Calle 80, Nº 20, Madrid, Madrid, 28767", "company": "Empresa 80", "website": null, "position": null}, {"cif": null, "name": "Elena Pérez", "tags": null, "email": "cliente81@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "673432403", "value": null, "status": "client", "address": "Calle 81, Nº 59, Madrid, Madrid, 28134", "company": "Empresa 81", "website": null, "position": null}, {"cif": null, "name": "David Ruiz", "tags": null, "email": "cliente82@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "644422831", "value": null, "status": "client", "address": "Calle 82, Nº 39, Madrid, Madrid, 28387", "company": "Empresa 82", "website": null, "position": null}, {"cif": null, "name": "Sara García", "tags": null, "email": "cliente83@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "621572998", "value": null, "status": "client", "address": "Calle 83, Nº 87, Madrid, Madrid, 28644", "company": "Empresa 83", "website": null, "position": null}, {"cif": null, "name": "Ana Pérez", "tags": null, "email": "cliente84@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "631354305", "value": null, "status": "client", "address": "Calle 84, Nº 92, Madrid, Madrid, 28135", "company": "Empresa 84", "website": null, "position": null}, {"cif": null, "name": "David Ortega", "tags": null, "email": "cliente85@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "696310266", "value": null, "status": "client", "address": "Calle 85, Nº 93, Madrid, Madrid, 28782", "company": "Empresa 85", "website": null, "position": null}, {"cif": null, "name": "Sara Navarro", "tags": null, "email": "cliente86@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "671729151", "value": null, "status": "prospect", "address": "Calle 86, Nº 59, Madrid, Madrid, 28376", "company": "Empresa 86", "website": null, "position": null}, {"cif": null, "name": "Sara Romero", "tags": null, "email": "cliente87@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "668715937", "value": null, "status": "prospect", "address": "Calle 87, Nº 89, Madrid, Madrid, 28842", "company": "Empresa 87", "website": null, "position": null}, {"cif": null, "name": "Miguel Ruiz", "tags": null, "email": "cliente88@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "664225241", "value": null, "status": "client", "address": "Calle 88, Nº 60, Madrid, Madrid, 28252", "company": "Empresa 88", "website": null, "position": null}, {"cif": null, "name": "Carlos Torres", "tags": null, "email": "cliente89@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "659225376", "value": null, "status": "prospect", "address": "Calle 89, Nº 68, Madrid, Madrid, 28698", "company": "Empresa 89", "website": null, "position": null}, {"cif": null, "name": "Javier Martín", "tags": null, "email": "cliente90@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "638976364", "value": null, "status": "client", "address": "Calle 90, Nº 76, Madrid, Madrid, 28672", "company": "Empresa 90", "website": null, "position": null}, {"cif": null, "name": "Luis Torres", "tags": null, "email": "cliente91@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "653453222", "value": null, "status": "client", "address": "Calle 91, Nº 26, Madrid, Madrid, 28845", "company": "Empresa 91", "website": null, "position": null}, {"cif": null, "name": "Elena Sánchez", "tags": null, "email": "cliente92@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "680249670", "value": null, "status": "client", "address": "Calle 92, Nº 84, Madrid, Madrid, 28497", "company": "Empresa 92", "website": null, "position": null}, {"cif": null, "name": "Javier García", "tags": null, "email": "cliente93@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "625300075", "value": null, "status": "prospect", "address": "Calle 93, Nº 38, Madrid, Madrid, 28688", "company": "Empresa 93", "website": null, "position": null}, {"cif": null, "name": "Miguel Martín", "tags": null, "email": "cliente94@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "614394031", "value": null, "status": "prospect", "address": "Calle 94, Nº 4, Madrid, Madrid, 28421", "company": "Empresa 94", "website": null, "position": null}, {"cif": null, "name": "Elena García", "tags": null, "email": "cliente95@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "664772445", "value": null, "status": "prospect", "address": "Calle 95, Nº 71, Madrid, Madrid, 28386", "company": "Empresa 95", "website": null, "position": null}, {"cif": null, "name": "David Sánchez", "tags": null, "email": "cliente96@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "688807678", "value": null, "status": "client", "address": "Calle 96, Nº 2, Madrid, Madrid, 28317", "company": "Empresa 96", "website": null, "position": null}, {"cif": null, "name": "Carlos Pérez", "tags": null, "email": "cliente97@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "626056189", "value": null, "status": "client", "address": "Calle 97, Nº 6, Madrid, Madrid, 28874", "company": "Empresa 97", "website": null, "position": null}, {"cif": null, "name": "Ana Martín", "tags": null, "email": "cliente98@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "680979291", "value": null, "status": "prospect", "address": "Calle 98, Nº 81, Madrid, Madrid, 28200", "company": "Empresa 98", "website": null, "position": null}, {"cif": null, "name": "Carlos Martín", "tags": null, "email": "cliente99@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "633580305", "value": null, "status": "client", "address": "Calle 99, Nº 58, Madrid, Madrid, 28925", "company": "Empresa 99", "website": null, "position": null}, {"cif": null, "name": "Elena López", "tags": null, "email": "cliente100@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "654036980", "value": null, "status": "client", "address": "Calle 100, Nº 74, Madrid, Madrid, 28915", "company": "Empresa 100", "website": null, "position": null}], "summary": "El archivo contiene una lista de contactos con información detallada como nombre, empresa, email, teléfono, dirección y estado. Los contactos están clasificados como activos, inactivos o prospectos. (100 registros detectados)", "confidence": 95, "detected_type": "contact_list", "suggested_destination": "CRM"}	CRM	\N	100	\N	2026-06-15 14:42:10.356775
6	8	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	completed	OmniTech_20_Clientes_Ficticios.pdf	pdf	contact_list	95	OmniTech Core - 20 Clientes Ficticios\nDatos de prueba para importar en OmniTech.\nNombre Empresa Email Telefono Estado Valor (€)\nCliente 1 Empresa 1 cliente1@test.com 600111001 Activo 600\nCliente 2 Empresa 2 cliente2@test.com 600111002 Inactivo 700\nCliente 3 Empresa 3 cliente3@test.com 600111003 Prospecto 800\nCliente 4 Empresa 4 cliente4@test.com 600111004 Activo 900\nCliente 5 Empresa 5 cliente5@test.com 600111005 Inactivo 1000\nCliente 6 Empresa 6 cliente6@test.com 600111006 Prospecto 1100\nCliente 7 Empresa 7 cliente7@test.com 600111007 Activo 1200\nCliente 8 Empresa 8 cliente8@test.com 600111008 Inactivo 1300\nCliente 9 Empresa 9 cliente9@test.com 600111009 Prospecto 1400\nCliente 10 Empresa 10 cliente10@test.com 600111010 Activo 1500\nCliente 11 Empresa 11 cliente11@test.com 600111011 Inactivo 1600\nCliente 12 Empresa 12 cliente12@test.com 600111012 Prospecto 1700\nCliente 13 Empresa 13 cliente13@test.com 600111013 Activo 1800\nCliente 14 Empresa 14 cliente14@test.com 600111014 Inactivo 1900\nCliente 15 Empresa 15 cliente15@test.com 600111015 Prospecto 2000\nCliente 16 Empresa 16 cliente16@test.com 600111016 Activo 2100\nCliente 17 Empresa 17 cliente17@test.com 600111017 Inactivo 2200\nCliente 18 Empresa 18 cliente18@test.com 600111018 Prospecto 2300\nCliente 19 Empresa 19 cliente19@test.com 600111019 Activo 2400\nCliente 20 Empresa 20 cliente20@test.com 600111020 Inactivo 2500\n\n-- 1 of 1 --\n\n	{"records": [{"cif": null, "name": "Cliente 1", "tags": null, "email": "cliente1@test.com", "notes": null, "phone": "600111001", "value": 600, "status": "client", "address": null, "company": "Empresa 1", "website": null, "position": null}, {"cif": null, "name": "Cliente 2", "tags": null, "email": "cliente2@test.com", "notes": null, "phone": "600111002", "value": 700, "status": "client", "address": null, "company": "Empresa 2", "website": null, "position": null}, {"cif": null, "name": "Cliente 3", "tags": null, "email": "cliente3@test.com", "notes": null, "phone": "600111003", "value": 800, "status": "prospect", "address": null, "company": "Empresa 3", "website": null, "position": null}, {"cif": null, "name": "Cliente 4", "tags": null, "email": "cliente4@test.com", "notes": null, "phone": "600111004", "value": 900, "status": "client", "address": null, "company": "Empresa 4", "website": null, "position": null}, {"cif": null, "name": "Cliente 5", "tags": null, "email": "cliente5@test.com", "notes": null, "phone": "600111005", "value": 1000, "status": "client", "address": null, "company": "Empresa 5", "website": null, "position": null}, {"cif": null, "name": "Cliente 6", "tags": null, "email": "cliente6@test.com", "notes": null, "phone": "600111006", "value": 1100, "status": "prospect", "address": null, "company": "Empresa 6", "website": null, "position": null}, {"cif": null, "name": "Cliente 7", "tags": null, "email": "cliente7@test.com", "notes": null, "phone": "600111007", "value": 1200, "status": "client", "address": null, "company": "Empresa 7", "website": null, "position": null}, {"cif": null, "name": "Cliente 8", "tags": null, "email": "cliente8@test.com", "notes": null, "phone": "600111008", "value": 1300, "status": "client", "address": null, "company": "Empresa 8", "website": null, "position": null}, {"cif": null, "name": "Cliente 9", "tags": null, "email": "cliente9@test.com", "notes": null, "phone": "600111009", "value": 1400, "status": "prospect", "address": null, "company": "Empresa 9", "website": null, "position": null}, {"cif": null, "name": "Cliente 10", "tags": null, "email": "cliente10@test.com", "notes": null, "phone": "600111010", "value": 1500, "status": "client", "address": null, "company": "Empresa 10", "website": null, "position": null}, {"cif": null, "name": "Cliente 11", "tags": null, "email": "cliente11@test.com", "notes": null, "phone": "600111011", "value": 1600, "status": "client", "address": null, "company": "Empresa 11", "website": null, "position": null}, {"cif": null, "name": "Cliente 12", "tags": null, "email": "cliente12@test.com", "notes": null, "phone": "600111012", "value": 1700, "status": "prospect", "address": null, "company": "Empresa 12", "website": null, "position": null}, {"cif": null, "name": "Cliente 13", "tags": null, "email": "cliente13@test.com", "notes": null, "phone": "600111013", "value": 1800, "status": "client", "address": null, "company": "Empresa 13", "website": null, "position": null}, {"cif": null, "name": "Cliente 14", "tags": null, "email": "cliente14@test.com", "notes": null, "phone": "600111014", "value": 1900, "status": "client", "address": null, "company": "Empresa 14", "website": null, "position": null}, {"cif": null, "name": "Cliente 15", "tags": null, "email": "cliente15@test.com", "notes": null, "phone": "600111015", "value": 2000, "status": "prospect", "address": null, "company": "Empresa 15", "website": null, "position": null}, {"cif": null, "name": "Cliente 16", "tags": null, "email": "cliente16@test.com", "notes": null, "phone": "600111016", "value": 2100, "status": "client", "address": null, "company": "Empresa 16", "website": null, "position": null}, {"cif": null, "name": "Cliente 17", "tags": null, "email": "cliente17@test.com", "notes": null, "phone": "600111017", "value": 2200, "status": "client", "address": null, "company": "Empresa 17", "website": null, "position": null}, {"cif": null, "name": "Cliente 18", "tags": null, "email": "cliente18@test.com", "notes": null, "phone": "600111018", "value": 2300, "status": "prospect", "address": null, "company": "Empresa 18", "website": null, "position": null}, {"cif": null, "name": "Cliente 19", "tags": null, "email": "cliente19@test.com", "notes": null, "phone": "600111019", "value": 2400, "status": "client", "address": null, "company": "Empresa 19", "website": null, "position": null}, {"cif": null, "name": "Cliente 20", "tags": null, "email": "cliente20@test.com", "notes": null, "phone": "600111020", "value": 2500, "status": "client", "address": null, "company": "Empresa 20", "website": null, "position": null}], "summary": "Lista de 20 clientes ficticios con información de contacto y estado para importar en OmniTech.", "confidence": 95, "detected_type": "contact_list", "suggested_destination": "CRM"}	CRM	\N	20	\N	2026-06-15 14:44:25.610794
\.


--
-- Data for Name: integration_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_events (id, org_id, integration_slug, direction, event_type, status, summary, error_message, created_at, payload_json) FROM stdin;
26	10	whatsapp	outbound	connected	processed	Integración "WhatsApp Business" configurada	\N	2026-06-16 07:12:22.482258	\N
28	8	whatsapp	outbound	connected	processed	Integración "WhatsApp Business" configurada	\N	2026-06-16 10:14:21.340591	\N
29	8	whatsapp	outbound	connected	processed	Integración "WhatsApp Business" configurada	\N	2026-06-16 10:31:27.458883	\N
30	8	whatsapp	outbound	connected	processed	Integración "WhatsApp Business" configurada	\N	2026-06-16 20:03:36.830757	\N
31	8	telegram	outbound	connected	processed	Integración "Telegram Bot" configurada	\N	2026-06-16 21:50:46.524982	\N
32	8	telegram	outbound	test_ok	processed	Bot verificado — Omnitech-core_bot @omnitechcore_bot	\N	2026-06-16 21:53:11.609253	"{\\"botName\\":\\"Omnitech-core_bot\\",\\"botUser\\":\\"@omnitechcore_bot\\"}"
33	8	telegram	outbound	connected	processed	Webhook registrado en Telegram → https://807abdee-7a7f-4f85-9057-ebcf18e51204-00-dbuvnu1d9e9l.picard.replit.dev/api/telegram/webhook/d38344882a0a090a1f7162c768242d5e	\N	2026-06-16 21:53:16.447117	"{\\"webhookUrl\\":\\"https://807abdee-7a7f-4f85-9057-ebcf18e51204-00-dbuvnu1d9e9l.picard.replit.dev/api/telegram/webhook/d38344882a0a090a1f7162c768242d5e\\"}"
34	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Hola"	\N	2026-06-16 21:53:51.500133	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Hola\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
35	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "¡Hola, F.J. Rodriguez Tapi! 😊 ¿En qué puedo ayudarte hoy?"	\N	2026-06-16 21:53:53.742095	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Hola\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"¡Hola, F.J. Rodriguez Tapi! 😊 ¿En qué puedo ayudarte hoy?\\",\\"sent\\":true}"
36	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Necesito presupuesto para organizar mi oficina"	\N	2026-06-16 21:56:07.754367	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Necesito presupuesto para organizar mi oficina\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
37	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "¡Hola F.J. Rodriguez Tapi! 😊 Podemos ayudarte a organizar tu oficina. Para ofre"	\N	2026-06-16 21:56:09.645099	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Necesito presupuesto para organizar mi oficina\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"¡Hola F.J. Rodriguez Tapi! 😊 Podemos ayudarte a organizar tu oficina. Para ofrecerte un presupuesto adecuado, ¿podrías compartir más detalles sobre el espacio y tus necesidades específicas?\\",\\"sent\\":true}"
38	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Orden y limpieza serían 200m2"	\N	2026-06-16 21:56:29.489501	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Orden y limpieza serían 200m2\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
39	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "Hola, F.J. Rodríguez Tapi. ¿Te gustaría que te proporcionemos más información so"	\N	2026-06-16 21:56:31.176108	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Orden y limpieza serían 200m2\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"Hola, F.J. Rodríguez Tapi. ¿Te gustaría que te proporcionemos más información sobre nuestros servicios de orden y limpieza para esos 200 m²? Estoy aquí para ayudarte. 😊\\",\\"sent\\":true}"
40	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Si"	\N	2026-06-16 21:56:38.488623	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Si\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
41	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "¡Hola! Veo que has escrito "Si". ¿En qué puedo ayudarte hoy? 😊"	\N	2026-06-16 21:56:39.868091	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Si\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"¡Hola! Veo que has escrito \\\\\\"Si\\\\\\". ¿En qué puedo ayudarte hoy? 😊\\",\\"sent\\":true}"
42	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Si dame más información"	\N	2026-06-16 21:56:54.322429	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Si dame más información\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
43	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "¡Hola F.J. Rodríguez Tapi! Claro, estaré encantado de ayudarte. ¿Sobre qué tema "	\N	2026-06-16 21:56:55.731394	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Si dame más información\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"¡Hola F.J. Rodríguez Tapi! Claro, estaré encantado de ayudarte. ¿Sobre qué tema específico necesitas más información? 😊\\",\\"sent\\":true}"
44	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Qué servicios ofrecéis?"	\N	2026-06-16 21:57:11.209599	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Qué servicios ofrecéis?\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
45	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "Hola F.J. 👋 En Demos ofrecemos una variedad de servicios que incluyen diseño gr"	\N	2026-06-16 21:57:12.953513	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Qué servicios ofrecéis?\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"Hola F.J. 👋 En Demos ofrecemos una variedad de servicios que incluyen diseño gráfico, marketing digital y asesoría en redes sociales, entre otros. Si te gustaría más información sobre algún servicio en particular, ¡estaré encantado de ayudarte! ¿Hay algo específico que te interese?\\",\\"sent\\":true}"
46	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Marketing"	\N	2026-06-16 21:57:33.54625	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Marketing\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
47	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "¡Hola F.J.! ¿Te gustaría saber más sobre nuestros servicios de marketing? Estoy "	\N	2026-06-16 21:57:34.982523	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Marketing\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"¡Hola F.J.! ¿Te gustaría saber más sobre nuestros servicios de marketing? Estoy aquí para ayudarte. 😊\\",\\"sent\\":true}"
48	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Si"	\N	2026-06-16 21:57:38.603332	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Si\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
49	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "¡Hola F.J. Rodriguez Tapi! 😊 ¿En qué puedo ayudarte hoy?"	\N	2026-06-16 21:57:40.893152	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Si\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"¡Hola F.J. Rodriguez Tapi! 😊 ¿En qué puedo ayudarte hoy?\\",\\"sent\\":true}"
50	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Mmmmm"	\N	2026-06-16 21:57:46.114146	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Mmmmm\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
51	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "¡Hola F.J. Rodriguez Tapi! 😊 Parece que tienes algo en mente. ¿Cómo puedo ayuda"	\N	2026-06-16 21:57:47.452162	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Mmmmm\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"¡Hola F.J. Rodriguez Tapi! 😊 Parece que tienes algo en mente. ¿Cómo puedo ayudarte hoy?\\",\\"sent\\":true}"
52	8	telegram	inbound	message_received	processed	Telegram de F.J. Rodriguez Tapi: "Me podes incluir en el Crm de tu empresa?"	\N	2026-06-16 21:58:03.85475	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Me podes incluir en el Crm de tu empresa?\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"quoteFound\\":false}"
53	8	telegram	outbound	ai_reply_sent	processed	IA respondió a F.J. Rodriguez Tapi: "Claro, puedo ayudarte con eso. ¿Podrías proporcionarme tu correo electrónico o c"	\N	2026-06-16 21:58:05.270844	"{\\"chatId\\":8999196249,\\"senderName\\":\\"F.J. Rodriguez Tapi\\",\\"username\\":null,\\"messageText\\":\\"Me podes incluir en el Crm de tu empresa?\\",\\"clientFound\\":false,\\"clientId\\":null,\\"clientName\\":null,\\"isAccepted\\":false,\\"isRejected\\":false,\\"aiReply\\":\\"Claro, puedo ayudarte con eso. ¿Podrías proporcionarme tu correo electrónico o cualquier otra información que necesitemos para incluirte en el CRM? 😊\\",\\"sent\\":true}"
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integrations (id, slug, name, category, auth_type, description, icon_slug, plan_required, is_active, sort_order) FROM stdin;
1	whatsapp	WhatsApp Business	communication	api_key	Recibe y envía mensajes automáticamente. Activa la aceptación de presupuestos vía WhatsApp.	MessageCircle	free	t	0
2	stripe	Stripe	payments	api_key	Procesa pagos y rastrea cobros automáticamente cuando se aceptan presupuestos.	CreditCard	pro	t	1
3	webhook_outbound	Webhooks Salientes	automation	webhook	Envía eventos del CRM a cualquier URL. Conecta con Zapier, Make o tu sistema propio.	Globe	free	t	2
4	gmail	Gmail	communication	oauth2	Envía emails directamente desde el CRM usando tu cuenta de Gmail.	Mail	pro	t	3
5	google_calendar	Google Calendar	calendar	oauth2	Sincroniza citas del CRM con tu Google Calendar en tiempo real.	CalendarDays	pro	t	4
6	slack	Slack	automation	oauth2	Recibe notificaciones cuando se aceptan presupuestos o se añaden nuevos clientes.	Hash	pro	t	5
31	telegram	Telegram Bot	communication	api_key	Envía notificaciones y mensajes a clientes vía Telegram usando tu propio bot.	Send	free	t	6
\.


--
-- Data for Name: knowledge_base; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.knowledge_base (id, org_id, title, content, category, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: license_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.license_plans (id, org_id, plan, seats, valid_from, valid_until, is_active, billing_cycle, notes, assigned_by, created_at, updated_at) FROM stdin;
2	10	professional	10	2026-03-17 12:56:10.80667	\N	t	monthly	Plan demo para presentaciones comerciales	system	2026-06-15 12:56:10.80667	2026-06-15 12:56:10.80667
3	20	starter	5	2026-06-15 12:57:10.271339	\N	t	monthly	Workspace limpio para primeros clientes reales	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
\.


--
-- Data for Name: memory_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.memory_history (id, memory_id, org_id, action, prev_title, new_title, prev_val, new_val, source, changed_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, client_id, content, direction, is_ai, status, created_at, org_id, channel) FROM stdin;
30	204	Hola! Vi vuestra web y me interesa saber más sobre el CRM para mi restaurante. Tengo 3 locales.	inbound	f	read	2026-06-07 22:36:18.48976	10	telegram
31	204	¡Hola Pepe! Encantados. Tenemos un módulo específico para hostelería. ¿Cuándo tienes 30 minutos para una demo?	outbound	f	sent	2026-06-07 21:53:18.48976	10	telegram
32	204	Perfecto! El viernes que viene a las 11h me va bien.	inbound	f	read	2026-06-07 21:13:18.48976	10	telegram
33	202	Buenos días. ¿Ya está lista la propuesta del e-Commerce? Tenemos presión del equipo comercial.	inbound	f	read	2026-06-13 03:48:18.48976	10	telegram
34	202	Buenos días Roberto! Sí, el presupuesto ya está. Te lo enviamos hoy por la tarde. ¿Prefieres que lo repasemos juntos en llamada?	outbound	f	sent	2026-06-13 03:23:18.48976	10	telegram
35	206	Hola! Soy de Peluquería Estilo Moderno. Me pasaron vuestro contacto. Necesitamos sistema para que los clientes reserven cita online.	inbound	f	read	2026-06-10 01:58:18.48976	10	telegram
\.


--
-- Data for Name: module_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.module_configs (id, org_id, module_slug, is_enabled, config, updated_by, created_at, updated_at) FROM stdin;
1	20	crm	t	{"maxClients": 100}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
2	20	quotes	t	{"taxRate": 21, "currency": "EUR"}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
3	20	calendar	t	{"reminderHours": 24}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
4	20	whatsapp	f	{"demoMode": false}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
5	20	ai_chat	t	{"model": "gpt-4o-mini"}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
6	20	import_ai	t	{}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
7	10	crm	t	{"maxClients": 500}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
8	10	quotes	t	{"taxRate": 21, "currency": "EUR"}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
9	10	calendar	t	{"reminderHours": 24}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
10	10	whatsapp	t	{"demoMode": true}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
11	10	ai_chat	t	{"model": "gpt-4o-mini"}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
12	10	import_ai	t	{}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
\.


--
-- Data for Name: org_integrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_integrations (id, org_id, integration_slug, status, config, credentials_enc, display_name, external_id, last_synced_at, expires_at, error_message, created_at, updated_at) FROM stdin;
5	10	whatsapp	active	\N	eyJwaG9uZU51bWJlcklkIjoiMTIwMjA3MTQ1OTY1NDAxMCIsImFjY2Vzc1Rva2VuIjoiRUFBWGxMbDBDNFhNQlJ1ZGw5VWlpSExQTlhsaVpDUkw3SzZaQlE3RnlYRExiTmRTV0dVQUhKakcza05WWFdoTHM4TlpCWkJCZDZpMmFVMGpPT3EyMXJuaWdRWTY4NTE3bFNZT2hoR3lWSjIyMVNwaXNaQ3V2ano2ekF0RG1HVW40WkN5WkFJR0Roa2Fob1ZpTEJucVFPemh1VHhLb3BySHY1WkJWZ1pDVmRpNmRJZFdLcGhlSVdpWkJaQjlRWkM4RXdXVkE5WWlPZVdTWkFjVUtqQklPZGRSWFpCTFpDRWJBUTBSY1lzSUpxWEFBTDd3WW1RNUJGOVBkc1JEWkNIcW9PMVFqZ1pDUUJaQUdOSW1RMXRGVGFWWU9LQ3B4WkE5anRObSIsInZlcmlmeVRva2VuIjoib21uaXRlY2gtd2ViaG9vayJ9	\N	\N	\N	\N	\N	2026-06-16 07:12:22.065126	2026-06-16 10:40:25.375905
6	8	whatsapp	active	\N	eyJwaG9uZU51bWJlcklkIjoiMTA3NDIyMDAyMjQ1MTkzMyJ9	\N	\N	\N	\N	\N	2026-06-16 10:14:21.044538	2026-06-16 20:03:36.711
7	8	telegram	active	{"0":"{","1":"\\"","2":"0","3":"\\"","4":":","5":"\\"","6":"{","7":"\\"","8":",","9":"\\"","10":"1","11":"\\"","12":":","13":"\\"","14":"\\\\","15":"\\"","16":"\\"","17":",","18":"\\"","19":"2","20":"\\"","21":":","22":"\\"","23":"0","24":"\\"","25":",","26":"\\"","27":"3","28":"\\"","29":":","30":"\\"","31":"\\\\","32":"\\"","33":"\\"","34":",","35":"\\"","36":"4","37":"\\"","38":":","39":"\\"","40":":","41":"\\"","42":",","43":"\\"","44":"5","45":"\\"","46":":","47":"\\"","48":"\\\\","49":"\\"","50":"\\"","51":",","52":"\\"","53":"6","54":"\\"","55":":","56":"\\"","57":"{","58":"\\"","59":",","60":"\\"","61":"7","62":"\\"","63":":","64":"\\"","65":"\\\\","66":"\\"","67":"\\"","68":",","69":"\\"","70":"8","71":"\\"","72":":","73":"\\"","74":",","75":"\\"","76":",","77":"\\"","78":"9","79":"\\"","80":":","81":"\\"","82":"\\\\","83":"\\"","84":"\\"","85":",","86":"\\"","87":"1","88":"0","89":"\\"","90":":","91":"\\"","92":"1","93":"\\"","94":",","95":"\\"","96":"1","97":"1","98":"\\"","99":":","100":"\\"","101":"\\\\","102":"\\"","103":"\\"","104":",","105":"\\"","106":"1","107":"2","108":"\\"","109":":","110":"\\"","111":":","112":"\\"","113":",","114":"\\"","115":"1","116":"3","117":"\\"","118":":","119":"\\"","120":"\\\\","121":"\\"","122":"\\"","123":",","124":"\\"","125":"1","126":"4","127":"\\"","128":":","129":"\\"","130":"\\\\","131":"\\\\","132":"\\"","133":",","134":"\\"","135":"1","136":"5","137":"\\"","138":":","139":"\\"","140":"\\\\","141":"\\"","142":"\\"","143":",","144":"\\"","145":"1","146":"6","147":"\\"","148":":","149":"\\"","150":"\\\\","151":"\\"","152":"\\"","153":",","154":"\\"","155":"1","156":"7","157":"\\"","158":":","159":"\\"","160":",","161":"\\"","162":",","163":"\\"","164":"1","165":"8","166":"\\"","167":":","168":"\\"","169":"\\\\","170":"\\"","171":"\\"","172":",","173":"\\"","174":"1","175":"9","176":"\\"","177":":","178":"\\"","179":"2","180":"\\"","181":",","182":"\\"","183":"2","184":"0","185":"\\"","186":":","187":"\\"","188":"\\\\","189":"\\"","190":"\\"","191":",","192":"\\"","193":"2","194":"1","195":"\\"","196":":","197":"\\"","198":":","199":"\\"","200":",","201":"\\"","202":"2","203":"2","204":"\\"","205":":","206":"\\"","207":"\\\\","208":"\\"","209":"\\"","210":",","211":"\\"","212":"2","213":"3","214":"\\"","215":":","216":"\\"","217":"w","218":"\\"","219":",","220":"\\"","221":"2","222":"4","223":"\\"","224":":","225":"\\"","226":"\\\\","227":"\\"","228":"\\"","229":",","230":"\\"","231":"2","232":"5","233":"\\"","234":":","235":"\\"","236":",","237":"\\"","238":",","239":"\\"","240":"2","241":"6","242":"\\"","243":":","244":"\\"","245":"\\\\","246":"\\"","247":"\\"","248":",","249":"\\"","250":"2","251":"7","252":"\\"","253":":","254":"\\"","255":"3","256":"\\"","257":",","258":"\\"","259":"2","260":"8","261":"\\"","262":":","263":"\\"","264":"\\\\","265":"\\"","266":"\\"","267":",","268":"\\"","269":"2","270":"9","271":"\\"","272":":","273":"\\"","274":":","275":"\\"","276":",","277":"\\"","278":"3","279":"0","280":"\\"","281":":","282":"\\"","283":"\\\\","284":"\\"","285":"\\"","286":",","287":"\\"","288":"3","289":"1","290":"\\"","291":":","292":"\\"","293":"e","294":"\\"","295":",","296":"\\"","297":"3","298":"2","299":"\\"","300":":","301":"\\"","302":"\\\\","303":"\\"","304":"\\"","305":",","306":"\\"","307":"3","308":"3","309":"\\"","310":":","311":"\\"","312":",","313":"\\"","314":",","315":"\\"","316":"3","317":"4","318":"\\"","319":":","320":"\\"","321":"\\\\","322":"\\"","323":"\\"","324":",","325":"\\"","326":"3","327":"5","328":"\\"","329":":","330":"\\"","331":"4","332":"\\"","333":",","334":"\\"","335":"3","336":"6","337":"\\"","338":":","339":"\\"","340":"\\\\","341":"\\"","342":"\\"","343":",","344":"\\"","345":"3","346":"7","347":"\\"","348":":","349":"\\"","350":":","351":"\\"","352":",","353":"\\"","354":"3","355":"8","356":"\\"","357":":","358":"\\"","359":"\\\\","360":"\\"","361":"\\"","362":",","363":"\\"","364":"3","365":"9","366":"\\"","367":":","368":"\\"","369":"b","370":"\\"","371":",","372":"\\"","373":"4","374":"0","375":"\\"","376":":","377":"\\"","378":"\\\\","379":"\\"","380":"\\"","381":",","382":"\\"","383":"4","384":"1","385":"\\"","386":":","387":"\\"","388":",","389":"\\"","390":",","391":"\\"","392":"4","393":"2","394":"\\"","395":":","396":"\\"","397":"\\\\","398":"\\"","399":"\\"","400":",","401":"\\"","402":"4","403":"3","404":"\\"","405":":","406":"\\"","407":"5","408":"\\"","409":",","410":"\\"","411":"4","412":"4","413":"\\"","414":":","415":"\\"","416":"\\\\","417":"\\"","418":"\\"","419":",","420":"\\"","421":"4","422":"5","423":"\\"","424":":","425":"\\"","426":":","427":"\\"","428":",","429":"\\"","430":"4","431":"6","432":"\\"","433":":","434":"\\"","435":"\\\\","436":"\\"","437":"\\"","438":",","439":"\\"","440":"4","441":"7","442":"\\"","443":":","444":"\\"","445":"h","446":"\\"","447":",","448":"\\"","449":"4","450":"8","451":"\\"","452":":","453":"\\"","454":"\\\\","455":"\\"","456":"\\"","457":",","458":"\\"","459":"4","460":"9","461":"\\"","462":":","463":"\\"","464":",","465":"\\"","466":",","467":"\\"","468":"5","469":"0","470":"\\"","471":":","472":"\\"","473":"\\\\","474":"\\"","475":"\\"","476":",","477":"\\"","478":"5","479":"1","480":"\\"","481":":","482":"\\"","483":"6","484":"\\"","485":",","486":"\\"","487":"5","488":"2","489":"\\"","490":":","491":"\\"","492":"\\\\","493":"\\"","494":"\\"","495":",","496":"\\"","497":"5","498":"3","499":"\\"","500":":","501":"\\"","502":":","503":"\\"","504":",","505":"\\"","506":"5","507":"4","508":"\\"","509":":","510":"\\"","511":"\\\\","512":"\\"","513":"\\"","514":",","515":"\\"","516":"5","517":"5","518":"\\"","519":":","520":"\\"","521":"o","522":"\\"","523":",","524":"\\"","525":"5","526":"6","527":"\\"","528":":","529":"\\"","530":"\\\\","531":"\\"","532":"\\"","533":",","534":"\\"","535":"5","536":"7","537":"\\"","538":":","539":"\\"","540":",","541":"\\"","542":",","543":"\\"","544":"5","545":"8","546":"\\"","547":":","548":"\\"","549":"\\\\","550":"\\"","551":"\\"","552":",","553":"\\"","554":"5","555":"9","556":"\\"","557":":","558":"\\"","559":"7","560":"\\"","561":",","562":"\\"","563":"6","564":"0","565":"\\"","566":":","567":"\\"","568":"\\\\","569":"\\"","570":"\\"","571":",","572":"\\"","573":"6","574":"1","575":"\\"","576":":","577":"\\"","578":":","579":"\\"","580":",","581":"\\"","582":"6","583":"2","584":"\\"","585":":","586":"\\"","587":"\\\\","588":"\\"","589":"\\"","590":",","591":"\\"","592":"6","593":"3","594":"\\"","595":":","596":"\\"","597":"o","598":"\\"","599":",","600":"\\"","601":"6","602":"4","603":"\\"","604":":","605":"\\"","606":"\\\\","607":"\\"","608":"\\"","609":",","610":"\\"","611":"6","612":"5","613":"\\"","614":":","615":"\\"","616":",","617":"\\"","618":",","619":"\\"","620":"6","621":"6","622":"\\"","623":":","624":"\\"","625":"\\\\","626":"\\"","627":"\\"","628":",","629":"\\"","630":"6","631":"7","632":"\\"","633":":","634":"\\"","635":"8","636":"\\"","637":",","638":"\\"","639":"6","640":"8","641":"\\"","642":":","643":"\\"","644":"\\\\","645":"\\"","646":"\\"","647":",","648":"\\"","649":"6","650":"9","651":"\\"","652":":","653":"\\"","654":":","655":"\\"","656":",","657":"\\"","658":"7","659":"0","660":"\\"","661":":","662":"\\"","663":"\\\\","664":"\\"","665":"\\"","666":",","667":"\\"","668":"7","669":"1","670":"\\"","671":":","672":"\\"","673":"k","674":"\\"","675":",","676":"\\"","677":"7","678":"2","679":"\\"","680":":","681":"\\"","682":"\\\\","683":"\\"","684":"\\"","685":",","686":"\\"","687":"7","688":"3","689":"\\"","690":":","691":"\\"","692":",","693":"\\"","694":",","695":"\\"","696":"7","697":"4","698":"\\"","699":":","700":"\\"","701":"\\\\","702":"\\"","703":"\\"","704":",","705":"\\"","706":"7","707":"5","708":"\\"","709":":","710":"\\"","711":"9","712":"\\"","713":",","714":"\\"","715":"7","716":"6","717":"\\"","718":":","719":"\\"","720":"\\\\","721":"\\"","722":"\\"","723":",","724":"\\"","725":"7","726":"7","727":"\\"","728":":","729":"\\"","730":":","731":"\\"","732":",","733":"\\"","734":"7","735":"8","736":"\\"","737":":","738":"\\"","739":"\\\\","740":"\\"","741":"\\"","742":",","743":"\\"","744":"7","745":"9","746":"\\"","747":":","748":"\\"","749":"S","750":"\\"","751":",","752":"\\"","753":"8","754":"0","755":"\\"","756":":","757":"\\"","758":"\\\\","759":"\\"","760":"\\"","761":",","762":"\\"","763":"8","764":"1","765":"\\"","766":":","767":"\\"","768":",","769":"\\"","770":",","771":"\\"","772":"8","773":"2","774":"\\"","775":":","776":"\\"","777":"\\\\","778":"\\"","779":"\\"","780":",","781":"\\"","782":"8","783":"3","784":"\\"","785":":","786":"\\"","787":"1","788":"\\"","789":",","790":"\\"","791":"8","792":"4","793":"\\"","794":":","795":"\\"","796":"0","797":"\\"","798":",","799":"\\"","800":"8","801":"5","802":"\\"","803":":","804":"\\"","805":"\\\\","806":"\\"","807":"\\"","808":",","809":"\\"","810":"8","811":"6","812":"\\"","813":":","814":"\\"","815":":","816":"\\"","817":",","818":"\\"","819":"8","820":"7","821":"\\"","822":":","823":"\\"","824":"\\\\","825":"\\"","826":"\\"","827":",","828":"\\"","829":"8","830":"8","831":"\\"","832":":","833":"\\"","834":"e","835":"\\"","836":",","837":"\\"","838":"8","839":"9","840":"\\"","841":":","842":"\\"","843":"\\\\","844":"\\"","845":"\\"","846":",","847":"\\"","848":"9","849":"0","850":"\\"","851":":","852":"\\"","853":",","854":"\\"","855":",","856":"\\"","857":"9","858":"1","859":"\\"","860":":","861":"\\"","862":"\\\\","863":"\\"","864":"\\"","865":",","866":"\\"","867":"9","868":"2","869":"\\"","870":":","871":"\\"","872":"1","873":"\\"","874":",","875":"\\"","876":"9","877":"3","878":"\\"","879":":","880":"\\"","881":"1","882":"\\"","883":",","884":"\\"","885":"9","886":"4","887":"\\"","888":":","889":"\\"","890":"\\\\","891":"\\"","892":"\\"","893":",","894":"\\"","895":"9","896":"5","897":"\\"","898":":","899":"\\"","900":":","901":"\\"","902":",","903":"\\"","904":"9","905":"6","906":"\\"","907":":","908":"\\"","909":"\\\\","910":"\\"","911":"\\"","912":",","913":"\\"","914":"9","915":"7","916":"\\"","917":":","918":"\\"","919":"c","920":"\\"","921":",","922":"\\"","923":"9","924":"8","925":"\\"","926":":","927":"\\"","928":"\\\\","929":"\\"","930":"\\"","931":",","932":"\\"","933":"9","934":"9","935":"\\"","936":":","937":"\\"","938":",","939":"\\"","940":",","941":"\\"","942":"1","943":"0","944":"0","945":"\\"","946":":","947":"\\"","948":"\\\\","949":"\\"","950":"\\"","951":",","952":"\\"","953":"1","954":"0","955":"1","956":"\\"","957":":","958":"\\"","959":"1","960":"\\"","961":",","962":"\\"","963":"1","964":"0","965":"2","966":"\\"","967":":","968":"\\"","969":"2","970":"\\"","971":",","972":"\\"","973":"1","974":"0","975":"3","976":"\\"","977":":","978":"\\"","979":"\\\\","980":"\\"","981":"\\"","982":",","983":"\\"","984":"1","985":"0","986":"4","987":"\\"","988":":","989":"\\"","990":":","991":"\\"","992":",","993":"\\"","994":"1","995":"0","996":"5","997":"\\"","998":":","999":"\\"","1000":"\\\\","1001":"\\"","1002":"\\"","1003":",","1004":"\\"","1005":"1","1006":"0","1007":"6","1008":"\\"","1009":":","1010":"\\"","1011":"r","1012":"\\"","1013":",","1014":"\\"","1015":"1","1016":"0","1017":"7","1018":"\\"","1019":":","1020":"\\"","1021":"\\\\","1022":"\\"","1023":"\\"","1024":",","1025":"\\"","1026":"1","1027":"0","1028":"8","1029":"\\"","1030":":","1031":"\\"","1032":",","1033":"\\"","1034":",","1035":"\\"","1036":"1","1037":"0","1038":"9","1039":"\\"","1040":":","1041":"\\"","1042":"\\\\","1043":"\\"","1044":"\\"","1045":",","1046":"\\"","1047":"1","1048":"1","1049":"0","1050":"\\"","1051":":","1052":"\\"","1053":"1","1054":"\\"","1055":",","1056":"\\"","1057":"1","1058":"1","1059":"1","1060":"\\"","1061":":","1062":"\\"","1063":"3","1064":"\\"","1065":",","1066":"\\"","1067":"1","1068":"1","1069":"2","1070":"\\"","1071":":","1072":"\\"","1073":"\\\\","1074":"\\"","1075":"\\"","1076":",","1077":"\\"","1078":"1","1079":"1","1080":"3","1081":"\\"","1082":":","1083":"\\"","1084":":","1085":"\\"","1086":",","1087":"\\"","1088":"1","1089":"1","1090":"4","1091":"\\"","1092":":","1093":"\\"","1094":"\\\\","1095":"\\"","1096":"\\"","1097":",","1098":"\\"","1099":"1","1100":"1","1101":"5","1102":"\\"","1103":":","1104":"\\"","1105":"e","1106":"\\"","1107":",","1108":"\\"","1109":"1","1110":"1","1111":"6","1112":"\\"","1113":":","1114":"\\"","1115":"\\\\","1116":"\\"","1117":"\\"","1118":",","1119":"\\"","1120":"1","1121":"1","1122":"7","1123":"\\"","1124":":","1125":"\\"","1126":",","1127":"\\"","1128":",","1129":"\\"","1130":"1","1131":"1","1132":"8","1133":"\\"","1134":":","1135":"\\"","1136":"\\\\","1137":"\\"","1138":"\\"","1139":",","1140":"\\"","1141":"1","1142":"1","1143":"9","1144":"\\"","1145":":","1146":"\\"","1147":"1","1148":"\\"","1149":",","1150":"\\"","1151":"1","1152":"2","1153":"0","1154":"\\"","1155":":","1156":"\\"","1157":"4","1158":"\\"","1159":",","1160":"\\"","1161":"1","1162":"2","1163":"1","1164":"\\"","1165":":","1166":"\\"","1167":"\\\\","1168":"\\"","1169":"\\"","1170":",","1171":"\\"","1172":"1","1173":"2","1174":"2","1175":"\\"","1176":":","1177":"\\"","1178":":","1179":"\\"","1180":",","1181":"\\"","1182":"1","1183":"2","1184":"3","1185":"\\"","1186":":","1187":"\\"","1188":"\\\\","1189":"\\"","1190":"\\"","1191":",","1192":"\\"","1193":"1","1194":"2","1195":"4","1196":"\\"","1197":":","1198":"\\"","1199":"t","1200":"\\"","1201":",","1202":"\\"","1203":"1","1204":"2","1205":"5","1206":"\\"","1207":":","1208":"\\"","1209":"\\\\","1210":"\\"","1211":"\\"","1212":",","1213":"\\"","1214":"1","1215":"2","1216":"6","1217":"\\"","1218":":","1219":"\\"","1220":",","1221":"\\"","1222":",","1223":"\\"","1224":"1","1225":"2","1226":"7","1227":"\\"","1228":":","1229":"\\"","1230":"\\\\","1231":"\\"","1232":"\\"","1233":",","1234":"\\"","1235":"1","1236":"2","1237":"8","1238":"\\"","1239":":","1240":"\\"","1241":"1","1242":"\\"","1243":",","1244":"\\"","1245":"1","1246":"2","1247":"9","1248":"\\"","1249":":","1250":"\\"","1251":"5","1252":"\\"","1253":",","1254":"\\"","1255":"1","1256":"3","1257":"0","1258":"\\"","1259":":","1260":"\\"","1261":"\\\\","1262":"\\"","1263":"\\"","1264":",","1265":"\\"","1266":"1","1267":"3","1268":"1","1269":"\\"","1270":":","1271":"\\"","1272":":","1273":"\\"","1274":",","1275":"\\"","1276":"1","1277":"3","1278":"2","1279":"\\"","1280":":","1281":"\\"","1282":"\\\\","1283":"\\"","1284":"\\"","1285":",","1286":"\\"","1287":"1","1288":"3","1289":"3","1290":"\\"","1291":":","1292":"\\"","1293":"\\\\","1294":"\\\\","1295":"\\"","1296":",","1297":"\\"","1298":"1","1299":"3","1300":"4","1301":"\\"","1302":":","1303":"\\"","1304":"\\\\","1305":"\\"","1306":"\\"","1307":",","1308":"\\"","1309":"1","1310":"3","1311":"5","1312":"\\"","1313":":","1314":"\\"","1315":"\\\\","1316":"\\"","1317":"\\"","1318":",","1319":"\\"","1320":"1","1321":"3","1322":"6","1323":"\\"","1324":":","1325":"\\"","1326":",","1327":"\\"","1328":",","1329":"\\"","1330":"1","1331":"3","1332":"7","1333":"\\"","1334":":","1335":"\\"","1336":"\\\\","1337":"\\"","1338":"\\"","1339":",","1340":"\\"","1341":"1","1342":"3","1343":"8","1344":"\\"","1345":":","1346":"\\"","1347":"1","1348":"\\"","1349":",","1350":"\\"","1351":"1","1352":"3","1353":"9","1354":"\\"","1355":":","1356":"\\"","1357":"6","1358":"\\"","1359":",","1360":"\\"","1361":"1","1362":"4","1363":"0","1364":"\\"","1365":":","1366":"\\"","1367":"\\\\","1368":"\\"","1369":"\\"","1370":",","1371":"\\"","1372":"1","1373":"4","1374":"1","1375":"\\"","1376":":","1377":"\\"","1378":":","1379":"\\"","1380":",","1381":"\\"","1382":"1","1383":"4","1384":"2","1385":"\\"","1386":":","1387":"\\"","1388":"\\\\","1389":"\\"","1390":"\\"","1391":",","1392":"\\"","1393":"1","1394":"4","1395":"3","1396":"\\"","1397":":","1398":"\\"","1399":":","1400":"\\"","1401":",","1402":"\\"","1403":"1","1404":"4","1405":"4","1406":"\\"","1407":":","1408":"\\"","1409":"\\\\","1410":"\\"","1411":"\\"","1412":",","1413":"\\"","1414":"1","1415":"4","1416":"5","1417":"\\"","1418":":","1419":"\\"","1420":",","1421":"\\"","1422":",","1423":"\\"","1424":"1","1425":"4","1426":"6","1427":"\\"","1428":":","1429":"\\"","1430":"\\\\","1431":"\\"","1432":"\\"","1433":",","1434":"\\"","1435":"1","1436":"4","1437":"7","1438":"\\"","1439":":","1440":"\\"","1441":"1","1442":"\\"","1443":",","1444":"\\"","1445":"1","1446":"4","1447":"8","1448":"\\"","1449":":","1450":"\\"","1451":"7","1452":"\\"","1453":",","1454":"\\"","1455":"1","1456":"4","1457":"9","1458":"\\"","1459":":","1460":"\\"","1461":"\\\\","1462":"\\"","1463":"\\"","1464":",","1465":"\\"","1466":"1","1467":"5","1468":"0","1469":"\\"","1470":":","1471":"\\"","1472":":","1473":"\\"","1474":",","1475":"\\"","1476":"1","1477":"5","1478":"1","1479":"\\"","1480":":","1481":"\\"","1482":"\\\\","1483":"\\"","1484":"\\"","1485":",","1486":"\\"","1487":"1","1488":"5","1489":"2","1490":"\\"","1491":":","1492":"\\"","1493":"\\\\","1494":"\\\\","1495":"\\"","1496":",","1497":"\\"","1498":"1","1499":"5","1500":"3","1501":"\\"","1502":":","1503":"\\"","1504":"\\\\","1505":"\\"","1506":"\\"","1507":",","1508":"\\"","1509":"1","1510":"5","1511":"4","1512":"\\"","1513":":","1514":"\\"","1515":"\\\\","1516":"\\"","1517":"\\"","1518":",","1519":"\\"","1520":"1","1521":"5","1522":"5","1523":"\\"","1524":":","1525":"\\"","1526":",","1527":"\\"","1528":",","1529":"\\"","1530":"1","1531":"5","1532":"6","1533":"\\"","1534":":","1535":"\\"","1536":"\\\\","1537":"\\"","1538":"\\"","1539":",","1540":"\\"","1541":"1","1542":"5","1543":"7","1544":"\\"","1545":":","1546":"\\"","1547":"1","1548":"\\"","1549":",","1550":"\\"","1551":"1","1552":"5","1553":"8","1554":"\\"","1555":":","1556":"\\"","1557":"8","1558":"\\"","1559":",","1560":"\\"","1561":"1","1562":"5","1563":"9","1564":"\\"","1565":":","1566":"\\"","1567":"\\\\","1568":"\\"","1569":"\\"","1570":",","1571":"\\"","1572":"1","1573":"6","1574":"0","1575":"\\"","1576":":","1577":"\\"","1578":":","1579":"\\"","1580":",","1581":"\\"","1582":"1","1583":"6","1584":"1","1585":"\\"","1586":":","1587":"\\"","1588":"\\\\","1589":"\\"","1590":"\\"","1591":",","1592":"\\"","1593":"1","1594":"6","1595":"2","1596":"\\"","1597":":","1598":"\\"","1599":"d","1600":"\\"","1601":",","1602":"\\"","1603":"1","1604":"6","1605":"3","1606":"\\"","1607":":","1608":"\\"","1609":"\\\\","1610":"\\"","1611":"\\"","1612":",","1613":"\\"","1614":"1","1615":"6","1616":"4","1617":"\\"","1618":":","1619":"\\"","1620":",","1621":"\\"","1622":",","1623":"\\"","1624":"1","1625":"6","1626":"5","1627":"\\"","1628":":","1629":"\\"","1630":"\\\\","1631":"\\"","1632":"\\"","1633":",","1634":"\\"","1635":"1","1636":"6","1637":"6","1638":"\\"","1639":":","1640":"\\"","1641":"1","1642":"\\"","1643":",","1644":"\\"","1645":"1","1646":"6","1647":"7","1648":"\\"","1649":":","1650":"\\"","1651":"9","1652":"\\"","1653":",","1654":"\\"","1655":"1","1656":"6","1657":"8","1658":"\\"","1659":":","1660":"\\"","1661":"\\\\","1662":"\\"","1663":"\\"","1664":",","1665":"\\"","1666":"1","1667":"6","1668":"9","1669":"\\"","1670":":","1671":"\\"","1672":":","1673":"\\"","1674":",","1675":"\\"","1676":"1","1677":"7","1678":"0","1679":"\\"","1680":":","1681":"\\"","1682":"\\\\","1683":"\\"","1684":"\\"","1685":",","1686":"\\"","1687":"1","1688":"7","1689":"1","1690":"\\"","1691":":","1692":"\\"","1693":"3","1694":"\\"","1695":",","1696":"\\"","1697":"1","1698":"7","1699":"2","1700":"\\"","1701":":","1702":"\\"","1703":"\\\\","1704":"\\"","1705":"\\"","1706":",","1707":"\\"","1708":"1","1709":"7","1710":"3","1711":"\\"","1712":":","1713":"\\"","1714":",","1715":"\\"","1716":",","1717":"\\"","1718":"1","1719":"7","1720":"4","1721":"\\"","1722":":","1723":"\\"","1724":"\\\\","1725":"\\"","1726":"\\"","1727":",","1728":"\\"","1729":"1","1730":"7","1731":"5","1732":"\\"","1733":":","1734":"\\"","1735":"2","1736":"\\"","1737":",","1738":"\\"","1739":"1","1740":"7","1741":"6","1742":"\\"","1743":":","1744":"\\"","1745":"0","1746":"\\"","1747":",","1748":"\\"","1749":"1","1750":"7","1751":"7","1752":"\\"","1753":":","1754":"\\"","1755":"\\\\","1756":"\\"","1757":"\\"","1758":",","1759":"\\"","1760":"1","1761":"7","1762":"8","1763":"\\"","1764":":","1765":"\\"","1766":":","1767":"\\"","1768":",","1769":"\\"","1770":"1","1771":"7","1772":"9","1773":"\\"","1774":":","1775":"\\"","1776":"\\\\","1777":"\\"","1778":"\\"","1779":",","1780":"\\"","1781":"1","1782":"8","1783":"0","1784":"\\"","1785":":","1786":"\\"","1787":"8","1788":"\\"","1789":",","1790":"\\"","1791":"1","1792":"8","1793":"1","1794":"\\"","1795":":","1796":"\\"","1797":"\\\\","1798":"\\"","1799":"\\"","1800":",","1801":"\\"","1802":"1","1803":"8","1804":"2","1805":"\\"","1806":":","1807":"\\"","1808":",","1809":"\\"","1810":",","1811":"\\"","1812":"1","1813":"8","1814":"3","1815":"\\"","1816":":","1817":"\\"","1818":"\\\\","1819":"\\"","1820":"\\"","1821":",","1822":"\\"","1823":"1","1824":"8","1825":"4","1826":"\\"","1827":":","1828":"\\"","1829":"2","1830":"\\"","1831":",","1832":"\\"","1833":"1","1834":"8","1835":"5","1836":"\\"","1837":":","1838":"\\"","1839":"1","1840":"\\"","1841":",","1842":"\\"","1843":"1","1844":"8","1845":"6","1846":"\\"","1847":":","1848":"\\"","1849":"\\\\","1850":"\\"","1851":"\\"","1852":",","1853":"\\"","1854":"1","1855":"8","1856":"7","1857":"\\"","1858":":","1859":"\\"","1860":":","1861":"\\"","1862":",","1863":"\\"","1864":"1","1865":"8","1866":"8","1867":"\\"","1868":":","1869":"\\"","1870":"\\\\","1871":"\\"","1872":"\\"","1873":",","1874":"\\"","1875":"1","1876":"8","1877":"9","1878":"\\"","1879":":","1880":"\\"","1881":"3","1882":"\\"","1883":",","1884":"\\"","1885":"1","1886":"9","1887":"0","1888":"\\"","1889":":","1890":"\\"","1891":"\\\\","1892":"\\"","1893":"\\"","1894":",","1895":"\\"","1896":"1","1897":"9","1898":"1","1899":"\\"","1900":":","1901":"\\"","1902":",","1903":"\\"","1904":",","1905":"\\"","1906":"1","1907":"9","1908":"2","1909":"\\"","1910":":","1911":"\\"","1912":"\\\\","1913":"\\"","1914":"\\"","1915":",","1916":"\\"","1917":"1","1918":"9","1919":"3","1920":"\\"","1921":":","1922":"\\"","1923":"2","1924":"\\"","1925":",","1926":"\\"","1927":"1","1928":"9","1929":"4","1930":"\\"","1931":":","1932":"\\"","1933":"2","1934":"\\"","1935":",","1936":"\\"","1937":"1","1938":"9","1939":"5","1940":"\\"","1941":":","1942":"\\"","1943":"\\\\","1944":"\\"","1945":"\\"","1946":",","1947":"\\"","1948":"1","1949":"9","1950":"6","1951":"\\"","1952":":","1953":"\\"","1954":":","1955":"\\"","1956":",","1957":"\\"","1958":"1","1959":"9","1960":"7","1961":"\\"","1962":":","1963":"\\"","1964":"\\\\","1965":"\\"","1966":"\\"","1967":",","1968":"\\"","1969":"1","1970":"9","1971":"8","1972":"\\"","1973":":","1974":"\\"","1975":"4","1976":"\\"","1977":",","1978":"\\"","1979":"1","1980":"9","1981":"9","1982":"\\"","1983":":","1984":"\\"","1985":"\\\\","1986":"\\"","1987":"\\"","1988":",","1989":"\\"","1990":"2","1991":"0","1992":"0","1993":"\\"","1994":":","1995":"\\"","1996":",","1997":"\\"","1998":",","1999":"\\"","2000":"2","2001":"0","2002":"1","2003":"\\"","2004":":","2005":"\\"","2006":"\\\\","2007":"\\"","2008":"\\"","2009":",","2010":"\\"","2011":"2","2012":"0","2013":"2","2014":"\\"","2015":":","2016":"\\"","2017":"2","2018":"\\"","2019":",","2020":"\\"","2021":"2","2022":"0","2023":"3","2024":"\\"","2025":":","2026":"\\"","2027":"3","2028":"\\"","2029":",","2030":"\\"","2031":"2","2032":"0","2033":"4","2034":"\\"","2035":":","2036":"\\"","2037":"\\\\","2038":"\\"","2039":"\\"","2040":",","2041":"\\"","2042":"2","2043":"0","2044":"5","2045":"\\"","2046":":","2047":"\\"","2048":":","2049":"\\"","2050":",","2051":"\\"","2052":"2","2053":"0","2054":"6","2055":"\\"","2056":":","2057":"\\"","2058":"\\\\","2059":"\\"","2060":"\\"","2061":",","2062":"\\"","2063":"2","2064":"0","2065":"7","2066":"\\"","2067":":","2068":"\\"","2069":"4","2070":"\\"","2071":",","2072":"\\"","2073":"2","2074":"0","2075":"8","2076":"\\"","2077":":","2078":"\\"","2079":"\\\\","2080":"\\"","2081":"\\"","2082":",","2083":"\\"","2084":"2","2085":"0","2086":"9","2087":"\\"","2088":":","2089":"\\"","2090":",","2091":"\\"","2092":",","2093":"\\"","2094":"2","2095":"1","2096":"0","2097":"\\"","2098":":","2099":"\\"","2100":"\\\\","2101":"\\"","2102":"\\"","2103":",","2104":"\\"","2105":"2","2106":"1","2107":"1","2108":"\\"","2109":":","2110":"\\"","2111":"2","2112":"\\"","2113":",","2114":"\\"","2115":"2","2116":"1","2117":"2","2118":"\\"","2119":":","2120":"\\"","2121":"4","2122":"\\"","2123":",","2124":"\\"","2125":"2","2126":"1","2127":"3","2128":"\\"","2129":":","2130":"\\"","2131":"\\\\","2132":"\\"","2133":"\\"","2134":",","2135":"\\"","2136":"2","2137":"1","2138":"4","2139":"\\"","2140":":","2141":"\\"","2142":":","2143":"\\"","2144":",","2145":"\\"","2146":"2","2147":"1","2148":"5","2149":"\\"","2150":":","2151":"\\"","2152":"\\\\","2153":"\\"","2154":"\\"","2155":",","2156":"\\"","2157":"2","2158":"1","2159":"6","2160":"\\"","2161":":","2162":"\\"","2163":"8","2164":"\\"","2165":",","2166":"\\"","2167":"2","2168":"1","2169":"7","2170":"\\"","2171":":","2172":"\\"","2173":"\\\\","2174":"\\"","2175":"\\"","2176":",","2177":"\\"","2178":"2","2179":"1","2180":"8","2181":"\\"","2182":":","2183":"\\"","2184":",","2185":"\\"","2186":",","2187":"\\"","2188":"2","2189":"1","2190":"9","2191":"\\"","2192":":","2193":"\\"","2194":"\\\\","2195":"\\"","2196":"\\"","2197":",","2198":"\\"","2199":"2","2200":"2","2201":"0","2202":"\\"","2203":":","2204":"\\"","2205":"2","2206":"\\"","2207":",","2208":"\\"","2209":"2","2210":"2","2211":"1","2212":"\\"","2213":":","2214":"\\"","2215":"5","2216":"\\"","2217":",","2218":"\\"","2219":"2","2220":"2","2221":"2","2222":"\\"","2223":":","2224":"\\"","2225":"\\\\","2226":"\\"","2227":"\\"","2228":",","2229":"\\"","2230":"2","2231":"2","2232":"3","2233":"\\"","2234":":","2235":"\\"","2236":":","2237":"\\"","2238":",","2239":"\\"","2240":"2","2241":"2","2242":"4","2243":"\\"","2244":":","2245":"\\"","2246":"\\\\","2247":"\\"","2248":"\\"","2249":",","2250":"\\"","2251":"2","2252":"2","2253":"5","2254":"\\"","2255":":","2256":"\\"","2257":"8","2258":"\\"","2259":",","2260":"\\"","2261":"2","2262":"2","2263":"6","2264":"\\"","2265":":","2266":"\\"","2267":"\\\\","2268":"\\"","2269":"\\"","2270":",","2271":"\\"","2272":"2","2273":"2","2274":"7","2275":"\\"","2276":":","2277":"\\"","2278":",","2279":"\\"","2280":",","2281":"\\"","2282":"2","2283":"2","2284":"8","2285":"\\"","2286":":","2287":"\\"","2288":"\\\\","2289":"\\"","2290":"\\"","2291":",","2292":"\\"","2293":"2","2294":"2","2295":"9","2296":"\\"","2297":":","2298":"\\"","2299":"2","2300":"\\"","2301":",","2302":"\\"","2303":"2","2304":"3","2305":"0","2306":"\\"","2307":":","2308":"\\"","2309":"6","2310":"\\"","2311":",","2312":"\\"","2313":"2","2314":"3","2315":"1","2316":"\\"","2317":":","2318":"\\"","2319":"\\\\","2320":"\\"","2321":"\\"","2322":",","2323":"\\"","2324":"2","2325":"3","2326":"2","2327":"\\"","2328":":","2329":"\\"","2330":":","2331":"\\"","2332":",","2333":"\\"","2334":"2","2335":"3","2336":"3","2337":"\\"","2338":":","2339":"\\"","2340":"\\\\","2341":"\\"","2342":"\\"","2343":",","2344":"\\"","2345":"2","2346":"3","2347":"4","2348":"\\"","2349":":","2350":"\\"","2351":"2","2352":"\\"","2353":",","2354":"\\"","2355":"2","2356":"3","2357":"5","2358":"\\"","2359":":","2360":"\\"","2361":"\\\\","2362":"\\"","2363":"\\"","2364":",","2365":"\\"","2366":"2","2367":"3","2368":"6","2369":"\\"","2370":":","2371":"\\"","2372":",","2373":"\\"","2374":",","2375":"\\"","2376":"2","2377":"3","2378":"7","2379":"\\"","2380":":","2381":"\\"","2382":"\\\\","2383":"\\"","2384":"\\"","2385":",","2386":"\\"","2387":"2","2388":"3","2389":"8","2390":"\\"","2391":":","2392":"\\"","2393":"2","2394":"\\"","2395":",","2396":"\\"","2397":"2","2398":"3","2399":"9","2400":"\\"","2401":":","2402":"\\"","2403":"7","2404":"\\"","2405":",","2406":"\\"","2407":"2","2408":"4","2409":"0","2410":"\\"","2411":":","2412":"\\"","2413":"\\\\","2414":"\\"","2415":"\\"","2416":",","2417":"\\"","2418":"2","2419":"4","2420":"1","2421":"\\"","2422":":","2423":"\\"","2424":":","2425":"\\"","2426":",","2427":"\\"","2428":"2","2429":"4","2430":"2","2431":"\\"","2432":":","2433":"\\"","2434":"\\\\","2435":"\\"","2436":"\\"","2437":",","2438":"\\"","2439":"2","2440":"4","2441":"3","2442":"\\"","2443":":","2444":"\\"","2445":"a","2446":"\\"","2447":",","2448":"\\"","2449":"2","2450":"4","2451":"4","2452":"\\"","2453":":","2454":"\\"","2455":"\\\\","2456":"\\"","2457":"\\"","2458":",","2459":"\\"","2460":"2","2461":"4","2462":"5","2463":"\\"","2464":":","2465":"\\"","2466":",","2467":"\\"","2468":",","2469":"\\"","2470":"2","2471":"4","2472":"6","2473":"\\"","2474":":","2475":"\\"","2476":"\\\\","2477":"\\"","2478":"\\"","2479":",","2480":"\\"","2481":"2","2482":"4","2483":"7","2484":"\\"","2485":":","2486":"\\"","2487":"2","2488":"\\"","2489":",","2490":"\\"","2491":"2","2492":"4","2493":"8","2494":"\\"","2495":":","2496":"\\"","2497":"8","2498":"\\"","2499":",","2500":"\\"","2501":"2","2502":"4","2503":"9","2504":"\\"","2505":":","2506":"\\"","2507":"\\\\","2508":"\\"","2509":"\\"","2510":",","2511":"\\"","2512":"2","2513":"5","2514":"0","2515":"\\"","2516":":","2517":"\\"","2518":":","2519":"\\"","2520":",","2521":"\\"","2522":"2","2523":"5","2524":"1","2525":"\\"","2526":":","2527":"\\"","2528":"\\\\","2529":"\\"","2530":"\\"","2531":",","2532":"\\"","2533":"2","2534":"5","2535":"2","2536":"\\"","2537":":","2538":"\\"","2539":"0","2540":"\\"","2541":",","2542":"\\"","2543":"2","2544":"5","2545":"3","2546":"\\"","2547":":","2548":"\\"","2549":"\\\\","2550":"\\"","2551":"\\"","2552":",","2553":"\\"","2554":"2","2555":"5","2556":"4","2557":"\\"","2558":":","2559":"\\"","2560":",","2561":"\\"","2562":",","2563":"\\"","2564":"2","2565":"5","2566":"5","2567":"\\"","2568":":","2569":"\\"","2570":"\\\\","2571":"\\"","2572":"\\"","2573":",","2574":"\\"","2575":"2","2576":"5","2577":"6","2578":"\\"","2579":":","2580":"\\"","2581":"2","2582":"\\"","2583":",","2584":"\\"","2585":"2","2586":"5","2587":"7","2588":"\\"","2589":":","2590":"\\"","2591":"9","2592":"\\"","2593":",","2594":"\\"","2595":"2","2596":"5","2597":"8","2598":"\\"","2599":":","2600":"\\"","2601":"\\\\","2602":"\\"","2603":"\\"","2604":",","2605":"\\"","2606":"2","2607":"5","2608":"9","2609":"\\"","2610":":","2611":"\\"","2612":":","2613":"\\"","2614":",","2615":"\\"","2616":"2","2617":"6","2618":"0","2619":"\\"","2620":":","2621":"\\"","2622":"\\\\","2623":"\\"","2624":"\\"","2625":",","2626":"\\"","2627":"2","2628":"6","2629":"1","2630":"\\"","2631":":","2632":"\\"","2633":"a","2634":"\\"","2635":",","2636":"\\"","2637":"2","2638":"6","2639":"2","2640":"\\"","2641":":","2642":"\\"","2643":"\\\\","2644":"\\"","2645":"\\"","2646":",","2647":"\\"","2648":"2","2649":"6","2650":"3","2651":"\\"","2652":":","2653":"\\"","2654":",","2655":"\\"","2656":",","2657":"\\"","2658":"2","2659":"6","2660":"4","2661":"\\"","2662":":","2663":"\\"","2664":"\\\\","2665":"\\"","2666":"\\"","2667":",","2668":"\\"","2669":"2","2670":"6","2671":"5","2672":"\\"","2673":":","2674":"\\"","2675":"3","2676":"\\"","2677":",","2678":"\\"","2679":"2","2680":"6","2681":"6","2682":"\\"","2683":":","2684":"\\"","2685":"0","2686":"\\"","2687":",","2688":"\\"","2689":"2","2690":"6","2691":"7","2692":"\\"","2693":":","2694":"\\"","2695":"\\\\","2696":"\\"","2697":"\\"","2698":",","2699":"\\"","2700":"2","2701":"6","2702":"8","2703":"\\"","2704":":","2705":"\\"","2706":":","2707":"\\"","2708":",","2709":"\\"","2710":"2","2711":"6","2712":"9","2713":"\\"","2714":":","2715":"\\"","2716":"\\\\","2717":"\\"","2718":"\\"","2719":",","2720":"\\"","2721":"2","2722":"7","2723":"0","2724":"\\"","2725":":","2726":"\\"","2727":"0","2728":"\\"","2729":",","2730":"\\"","2731":"2","2732":"7","2733":"1","2734":"\\"","2735":":","2736":"\\"","2737":"\\\\","2738":"\\"","2739":"\\"","2740":",","2741":"\\"","2742":"2","2743":"7","2744":"2","2745":"\\"","2746":":","2747":"\\"","2748":",","2749":"\\"","2750":",","2751":"\\"","2752":"2","2753":"7","2754":"3","2755":"\\"","2756":":","2757":"\\"","2758":"\\\\","2759":"\\"","2760":"\\"","2761":",","2762":"\\"","2763":"2","2764":"7","2765":"4","2766":"\\"","2767":":","2768":"\\"","2769":"3","2770":"\\"","2771":",","2772":"\\"","2773":"2","2774":"7","2775":"5","2776":"\\"","2777":":","2778":"\\"","2779":"1","2780":"\\"","2781":",","2782":"\\"","2783":"2","2784":"7","2785":"6","2786":"\\"","2787":":","2788":"\\"","2789":"\\\\","2790":"\\"","2791":"\\"","2792":",","2793":"\\"","2794":"2","2795":"7","2796":"7","2797":"\\"","2798":":","2799":"\\"","2800":":","2801":"\\"","2802":",","2803":"\\"","2804":"2","2805":"7","2806":"8","2807":"\\"","2808":":","2809":"\\"","2810":"\\\\","2811":"\\"","2812":"\\"","2813":",","2814":"\\"","2815":"2","2816":"7","2817":"9","2818":"\\"","2819":":","2820":"\\"","2821":"9","2822":"\\"","2823":",","2824":"\\"","2825":"2","2826":"8","2827":"0","2828":"\\"","2829":":","2830":"\\"","2831":"\\\\","2832":"\\"","2833":"\\"","2834":",","2835":"\\"","2836":"2","2837":"8","2838":"1","2839":"\\"","2840":":","2841":"\\"","2842":",","2843":"\\"","2844":",","2845":"\\"","2846":"2","2847":"8","2848":"2","2849":"\\"","2850":":","2851":"\\"","2852":"\\\\","2853":"\\"","2854":"\\"","2855":",","2856":"\\"","2857":"2","2858":"8","2859":"3","2860":"\\"","2861":":","2862":"\\"","2863":"3","2864":"\\"","2865":",","2866":"\\"","2867":"2","2868":"8","2869":"4","2870":"\\"","2871":":","2872":"\\"","2873":"2","2874":"\\"","2875":",","2876":"\\"","2877":"2","2878":"8","2879":"5","2880":"\\"","2881":":","2882":"\\"","2883":"\\\\","2884":"\\"","2885":"\\"","2886":",","2887":"\\"","2888":"2","2889":"8","2890":"6","2891":"\\"","2892":":","2893":"\\"","2894":":","2895":"\\"","2896":",","2897":"\\"","2898":"2","2899":"8","2900":"7","2901":"\\"","2902":":","2903":"\\"","2904":"\\\\","2905":"\\"","2906":"\\"","2907":",","2908":"\\"","2909":"2","2910":"8","2911":"8","2912":"\\"","2913":":","2914":"\\"","2915":"0","2916":"\\"","2917":",","2918":"\\"","2919":"2","2920":"8","2921":"9","2922":"\\"","2923":":","2924":"\\"","2925":"\\\\","2926":"\\"","2927":"\\"","2928":",","2929":"\\"","2930":"2","2931":"9","2932":"0","2933":"\\"","2934":":","2935":"\\"","2936":",","2937":"\\"","2938":",","2939":"\\"","2940":"2","2941":"9","2942":"1","2943":"\\"","2944":":","2945":"\\"","2946":"\\\\","2947":"\\"","2948":"\\"","2949":",","2950":"\\"","2951":"2","2952":"9","2953":"2","2954":"\\"","2955":":","2956":"\\"","2957":"3","2958":"\\"","2959":",","2960":"\\"","2961":"2","2962":"9","2963":"3","2964":"\\"","2965":":","2966":"\\"","2967":"3","2968":"\\"","2969":",","2970":"\\"","2971":"2","2972":"9","2973":"4","2974":"\\"","2975":":","2976":"\\"","2977":"\\\\","2978":"\\"","2979":"\\"","2980":",","2981":"\\"","2982":"2","2983":"9","2984":"5","2985":"\\"","2986":":","2987":"\\"","2988":":","2989":"\\"","2990":",","2991":"\\"","2992":"2","2993":"9","2994":"6","2995":"\\"","2996":":","2997":"\\"","2998":"\\\\","2999":"\\"","3000":"\\"","3001":",","3002":"\\"","3003":"2","3004":"9","3005":"7","3006":"\\"","3007":":","3008":"\\"","3009":"a","3010":"\\"","3011":",","3012":"\\"","3013":"2","3014":"9","3015":"8","3016":"\\"","3017":":","3018":"\\"","3019":"\\\\","3020":"\\"","3021":"\\"","3022":",","3023":"\\"","3024":"2","3025":"9","3026":"9","3027":"\\"","3028":":","3029":"\\"","3030":",","3031":"\\"","3032":",","3033":"\\"","3034":"3","3035":"0","3036":"0","3037":"\\"","3038":":","3039":"\\"","3040":"\\\\","3041":"\\"","3042":"\\"","3043":",","3044":"\\"","3045":"3","3046":"0","3047":"1","3048":"\\"","3049":":","3050":"\\"","3051":"3","3052":"\\"","3053":",","3054":"\\"","3055":"3","3056":"0","3057":"2","3058":"\\"","3059":":","3060":"\\"","3061":"4","3062":"\\"","3063":",","3064":"\\"","3065":"3","3066":"0","3067":"3","3068":"\\"","3069":":","3070":"\\"","3071":"\\\\","3072":"\\"","3073":"\\"","3074":",","3075":"\\"","3076":"3","3077":"0","3078":"4","3079":"\\"","3080":":","3081":"\\"","3082":":","3083":"\\"","3084":",","3085":"\\"","3086":"3","3087":"0","3088":"5","3089":"\\"","3090":":","3091":"\\"","3092":"\\\\","3093":"\\"","3094":"\\"","3095":",","3096":"\\"","3097":"3","3098":"0","3099":"6","3100":"\\"","3101":":","3102":"\\"","3103":"1","3104":"\\"","3105":",","3106":"\\"","3107":"3","3108":"0","3109":"7","3110":"\\"","3111":":","3112":"\\"","3113":"\\\\","3114":"\\"","3115":"\\"","3116":",","3117":"\\"","3118":"3","3119":"0","3120":"8","3121":"\\"","3122":":","3123":"\\"","3124":",","3125":"\\"","3126":",","3127":"\\"","3128":"3","3129":"0","3130":"9","3131":"\\"","3132":":","3133":"\\"","3134":"\\\\","3135":"\\"","3136":"\\"","3137":",","3138":"\\"","3139":"3","3140":"1","3141":"0","3142":"\\"","3143":":","3144":"\\"","3145":"3","3146":"\\"","3147":",","3148":"\\"","3149":"3","3150":"1","3151":"1","3152":"\\"","3153":":","3154":"\\"","3155":"5","3156":"\\"","3157":",","3158":"\\"","3159":"3","3160":"1","3161":"2","3162":"\\"","3163":":","3164":"\\"","3165":"\\\\","3166":"\\"","3167":"\\"","3168":",","3169":"\\"","3170":"3","3171":"1","3172":"3","3173":"\\"","3174":":","3175":"\\"","3176":":","3177":"\\"","3178":",","3179":"\\"","3180":"3","3181":"1","3182":"4","3183":"\\"","3184":":","3185":"\\"","3186":"\\\\","3187":"\\"","3188":"\\"","3189":",","3190":"\\"","3191":"3","3192":"1","3193":"5","3194":"\\"","3195":":","3196":"\\"","3197":"f","3198":"\\"","3199":",","3200":"\\"","3201":"3","3202":"1","3203":"6","3204":"\\"","3205":":","3206":"\\"","3207":"\\\\","3208":"\\"","3209":"\\"","3210":",","3211":"\\"","3212":"3","3213":"1","3214":"7","3215":"\\"","3216":":","3217":"\\"","3218":",","3219":"\\"","3220":",","3221":"\\"","3222":"3","3223":"1","3224":"8","3225":"\\"","3226":":","3227":"\\"","3228":"\\\\","3229":"\\"","3230":"\\"","3231":",","3232":"\\"","3233":"3","3234":"1","3235":"9","3236":"\\"","3237":":","3238":"\\"","3239":"3","3240":"\\"","3241":",","3242":"\\"","3243":"3","3244":"2","3245":"0","3246":"\\"","3247":":","3248":"\\"","3249":"6","3250":"\\"","3251":",","3252":"\\"","3253":"3","3254":"2","3255":"1","3256":"\\"","3257":":","3258":"\\"","3259":"\\\\","3260":"\\"","3261":"\\"","3262":",","3263":"\\"","3264":"3","3265":"2","3266":"2","3267":"\\"","3268":":","3269":"\\"","3270":":","3271":"\\"","3272":",","3273":"\\"","3274":"3","3275":"2","3276":"3","3277":"\\"","3278":":","3279":"\\"","3280":"\\\\","3281":"\\"","3282":"\\"","3283":",","3284":"\\"","3285":"3","3286":"2","3287":"4","3288":"\\"","3289":":","3290":"\\"","3291":"7","3292":"\\"","3293":",","3294":"\\"","3295":"3","3296":"2","3297":"5","3298":"\\"","3299":":","3300":"\\"","3301":"\\\\","3302":"\\"","3303":"\\"","3304":",","3305":"\\"","3306":"3","3307":"2","3308":"6","3309":"\\"","3310":":","3311":"\\"","3312":",","3313":"\\"","3314":",","3315":"\\"","3316":"3","3317":"2","3318":"7","3319":"\\"","3320":":","3321":"\\"","3322":"\\\\","3323":"\\"","3324":"\\"","3325":",","3326":"\\"","3327":"3","3328":"2","3329":"8","3330":"\\"","3331":":","3332":"\\"","3333":"3","3334":"\\"","3335":",","3336":"\\"","3337":"3","3338":"2","3339":"9","3340":"\\"","3341":":","3342":"\\"","3343":"7","3344":"\\"","3345":",","3346":"\\"","3347":"3","3348":"3","3349":"0","3350":"\\"","3351":":","3352":"\\"","3353":"\\\\","3354":"\\"","3355":"\\"","3356":",","3357":"\\"","3358":"3","3359":"3","3360":"1","3361":"\\"","3362":":","3363":"\\"","3364":":","3365":"\\"","3366":",","3367":"\\"","3368":"3","3369":"3","3370":"2","3371":"\\"","3372":":","3373":"\\"","3374":"\\\\","3375":"\\"","3376":"\\"","3377":",","3378":"\\"","3379":"3","3380":"3","3381":"3","3382":"\\"","3383":":","3384":"\\"","3385":"1","3386":"\\"","3387":",","3388":"\\"","3389":"3","3390":"3","3391":"4","3392":"\\"","3393":":","3394":"\\"","3395":"\\\\","3396":"\\"","3397":"\\"","3398":",","3399":"\\"","3400":"3","3401":"3","3402":"5","3403":"\\"","3404":":","3405":"\\"","3406":",","3407":"\\"","3408":",","3409":"\\"","3410":"3","3411":"3","3412":"6","3413":"\\"","3414":":","3415":"\\"","3416":"\\\\","3417":"\\"","3418":"\\"","3419":",","3420":"\\"","3421":"3","3422":"3","3423":"7","3424":"\\"","3425":":","3426":"\\"","3427":"3","3428":"\\"","3429":",","3430":"\\"","3431":"3","3432":"3","3433":"8","3434":"\\"","3435":":","3436":"\\"","3437":"8","3438":"\\"","3439":",","3440":"\\"","3441":"3","3442":"3","3443":"9","3444":"\\"","3445":":","3446":"\\"","3447":"\\\\","3448":"\\"","3449":"\\"","3450":",","3451":"\\"","3452":"3","3453":"4","3454":"0","3455":"\\"","3456":":","3457":"\\"","3458":":","3459":"\\"","3460":",","3461":"\\"","3462":"3","3463":"4","3464":"1","3465":"\\"","3466":":","3467":"\\"","3468":"\\\\","3469":"\\"","3470":"\\"","3471":",","3472":"\\"","3473":"3","3474":"4","3475":"2","3476":"\\"","3477":":","3478":"\\"","3479":"6","3480":"\\"","3481":",","3482":"\\"","3483":"3","3484":"4","3485":"3","3486":"\\"","3487":":","3488":"\\"","3489":"\\\\","3490":"\\"","3491":"\\"","3492":",","3493":"\\"","3494":"3","3495":"4","3496":"4","3497":"\\"","3498":":","3499":"\\"","3500":",","3501":"\\"","3502":",","3503":"\\"","3504":"3","3505":"4","3506":"5","3507":"\\"","3508":":","3509":"\\"","3510":"\\\\","3511":"\\"","3512":"\\"","3513":",","3514":"\\"","3515":"3","3516":"4","3517":"6","3518":"\\"","3519":":","3520":"\\"","3521":"3","3522":"\\"","3523":",","3524":"\\"","3525":"3","3526":"4","3527":"7","3528":"\\"","3529":":","3530":"\\"","3531":"9","3532":"\\"","3533":",","3534":"\\"","3535":"3","3536":"4","3537":"8","3538":"\\"","3539":":","3540":"\\"","3541":"\\\\","3542":"\\"","3543":"\\"","3544":",","3545":"\\"","3546":"3","3547":"4","3548":"9","3549":"\\"","3550":":","3551":"\\"","3552":":","3553":"\\"","3554":",","3555":"\\"","3556":"3","3557":"5","3558":"0","3559":"\\"","3560":":","3561":"\\"","3562":"\\\\","3563":"\\"","3564":"\\"","3565":",","3566":"\\"","3567":"3","3568":"5","3569":"1","3570":"\\"","3571":":","3572":"\\"","3573":"2","3574":"\\"","3575":",","3576":"\\"","3577":"3","3578":"5","3579":"2","3580":"\\"","3581":":","3582":"\\"","3583":"\\\\","3584":"\\"","3585":"\\"","3586":",","3587":"\\"","3588":"3","3589":"5","3590":"3","3591":"\\"","3592":":","3593":"\\"","3594":",","3595":"\\"","3596":",","3597":"\\"","3598":"3","3599":"5","3600":"4","3601":"\\"","3602":":","3603":"\\"","3604":"\\\\","3605":"\\"","3606":"\\"","3607":",","3608":"\\"","3609":"3","3610":"5","3611":"5","3612":"\\"","3613":":","3614":"\\"","3615":"4","3616":"\\"","3617":",","3618":"\\"","3619":"3","3620":"5","3621":"6","3622":"\\"","3623":":","3624":"\\"","3625":"0","3626":"\\"","3627":",","3628":"\\"","3629":"3","3630":"5","3631":"7","3632":"\\"","3633":":","3634":"\\"","3635":"\\\\","3636":"\\"","3637":"\\"","3638":",","3639":"\\"","3640":"3","3641":"5","3642":"8","3643":"\\"","3644":":","3645":"\\"","3646":":","3647":"\\"","3648":",","3649":"\\"","3650":"3","3651":"5","3652":"9","3653":"\\"","3654":":","3655":"\\"","3656":"\\\\","3657":"\\"","3658":"\\"","3659":",","3660":"\\"","3661":"3","3662":"6","3663":"0","3664":"\\"","3665":":","3666":"\\"","3667":"c","3668":"\\"","3669":",","3670":"\\"","3671":"3","3672":"6","3673":"1","3674":"\\"","3675":":","3676":"\\"","3677":"\\\\","3678":"\\"","3679":"\\"","3680":",","3681":"\\"","3682":"3","3683":"6","3684":"2","3685":"\\"","3686":":","3687":"\\"","3688":",","3689":"\\"","3690":",","3691":"\\"","3692":"3","3693":"6","3694":"3","3695":"\\"","3696":":","3697":"\\"","3698":"\\\\","3699":"\\"","3700":"\\"","3701":",","3702":"\\"","3703":"3","3704":"6","3705":"4","3706":"\\"","3707":":","3708":"\\"","3709":"4","3710":"\\"","3711":",","3712":"\\"","3713":"3","3714":"6","3715":"5","3716":"\\"","3717":":","3718":"\\"","3719":"1","3720":"\\"","3721":",","3722":"\\"","3723":"3","3724":"6","3725":"6","3726":"\\"","3727":":","3728":"\\"","3729":"\\\\","3730":"\\"","3731":"\\"","3732":",","3733":"\\"","3734":"3","3735":"6","3736":"7","3737":"\\"","3738":":","3739":"\\"","3740":":","3741":"\\"","3742":",","3743":"\\"","3744":"3","3745":"6","3746":"8","3747":"\\"","3748":":","3749":"\\"","3750":"\\\\","3751":"\\"","3752":"\\"","3753":",","3754":"\\"","3755":"3","3756":"6","3757":"9","3758":"\\"","3759":":","3760":"\\"","3761":"7","3762":"\\"","3763":",","3764":"\\"","3765":"3","3766":"7","3767":"0","3768":"\\"","3769":":","3770":"\\"","3771":"\\\\","3772":"\\"","3773":"\\"","3774":",","3775":"\\"","3776":"3","3777":"7","3778":"1","3779":"\\"","3780":":","3781":"\\"","3782":",","3783":"\\"","3784":",","3785":"\\"","3786":"3","3787":"7","3788":"2","3789":"\\"","3790":":","3791":"\\"","3792":"\\\\","3793":"\\"","3794":"\\"","3795":",","3796":"\\"","3797":"3","3798":"7","3799":"3","3800":"\\"","3801":":","3802":"\\"","3803":"4","3804":"\\"","3805":",","3806":"\\"","3807":"3","3808":"7","3809":"4","3810":"\\"","3811":":","3812":"\\"","3813":"2","3814":"\\"","3815":",","3816":"\\"","3817":"3","3818":"7","3819":"5","3820":"\\"","3821":":","3822":"\\"","3823":"\\\\","3824":"\\"","3825":"\\"","3826":",","3827":"\\"","3828":"3","3829":"7","3830":"6","3831":"\\"","3832":":","3833":"\\"","3834":":","3835":"\\"","3836":",","3837":"\\"","3838":"3","3839":"7","3840":"7","3841":"\\"","3842":":","3843":"\\"","3844":"\\\\","3845":"\\"","3846":"\\"","3847":",","3848":"\\"","3849":"3","3850":"7","3851":"8","3852":"\\"","3853":":","3854":"\\"","3855":"6","3856":"\\"","3857":",","3858":"\\"","3859":"3","3860":"7","3861":"9","3862":"\\"","3863":":","3864":"\\"","3865":"\\\\","3866":"\\"","3867":"\\"","3868":",","3869":"\\"","3870":"3","3871":"8","3872":"0","3873":"\\"","3874":":","3875":"\\"","3876":",","3877":"\\"","3878":",","3879":"\\"","3880":"3","3881":"8","3882":"1","3883":"\\"","3884":":","3885":"\\"","3886":"\\\\","3887":"\\"","3888":"\\"","3889":",","3890":"\\"","3891":"3","3892":"8","3893":"2","3894":"\\"","3895":":","3896":"\\"","3897":"4","3898":"\\"","3899":",","3900":"\\"","3901":"3","3902":"8","3903":"3","3904":"\\"","3905":":","3906":"\\"","3907":"3","3908":"\\"","3909":",","3910":"\\"","3911":"3","3912":"8","3913":"4","3914":"\\"","3915":":","3916":"\\"","3917":"\\\\","3918":"\\"","3919":"\\"","3920":",","3921":"\\"","3922":"3","3923":"8","3924":"5","3925":"\\"","3926":":","3927":"\\"","3928":":","3929":"\\"","3930":",","3931":"\\"","3932":"3","3933":"8","3934":"6","3935":"\\"","3936":":","3937":"\\"","3938":"\\\\","3939":"\\"","3940":"\\"","3941":",","3942":"\\"","3943":"3","3944":"8","3945":"7","3946":"\\"","3947":":","3948":"\\"","3949":"8","3950":"\\"","3951":",","3952":"\\"","3953":"3","3954":"8","3955":"8","3956":"\\"","3957":":","3958":"\\"","3959":"\\\\","3960":"\\"","3961":"\\"","3962":",","3963":"\\"","3964":"3","3965":"8","3966":"9","3967":"\\"","3968":":","3969":"\\"","3970":",","3971":"\\"","3972":",","3973":"\\"","3974":"3","3975":"9","3976":"0","3977":"\\"","3978":":","3979":"\\"","3980":"\\\\","3981":"\\"","3982":"\\"","3983":",","3984":"\\"","3985":"3","3986":"9","3987":"1","3988":"\\"","3989":":","3990":"\\"","3991":"4","3992":"\\"","3993":",","3994":"\\"","3995":"3","3996":"9","3997":"2","3998":"\\"","3999":":","4000":"\\"","4001":"4","4002":"\\"","4003":",","4004":"\\"","4005":"3","4006":"9","4007":"3","4008":"\\"","4009":":","4010":"\\"","4011":"\\\\","4012":"\\"","4013":"\\"","4014":",","4015":"\\"","4016":"3","4017":"9","4018":"4","4019":"\\"","4020":":","4021":"\\"","4022":":","4023":"\\"","4024":",","4025":"\\"","4026":"3","4027":"9","4028":"5","4029":"\\"","4030":":","4031":"\\"","4032":"\\\\","4033":"\\"","4034":"\\"","4035":",","4036":"\\"","4037":"3","4038":"9","4039":"6","4040":"\\"","4041":":","4042":"\\"","4043":"2","4044":"\\"","4045":",","4046":"\\"","4047":"3","4048":"9","4049":"7","4050":"\\"","4051":":","4052":"\\"","4053":"\\\\","4054":"\\"","4055":"\\"","4056":",","4057":"\\"","4058":"3","4059":"9","4060":"8","4061":"\\"","4062":":","4063":"\\"","4064":",","4065":"\\"","4066":",","4067":"\\"","4068":"3","4069":"9","4070":"9","4071":"\\"","4072":":","4073":"\\"","4074":"\\\\","4075":"\\"","4076":"\\"","4077":",","4078":"\\"","4079":"4","4080":"0","4081":"0","4082":"\\"","4083":":","4084":"\\"","4085":"4","4086":"\\"","4087":",","4088":"\\"","4089":"4","4090":"0","4091":"1","4092":"\\"","4093":":","4094":"\\"","4095":"5","4096":"\\"","4097":",","4098":"\\"","4099":"4","4100":"0","4101":"2","4102":"\\"","4103":":","4104":"\\"","4105":"\\\\","4106":"\\"","4107":"\\"","4108":",","4109":"\\"","4110":"4","4111":"0","4112":"3","4113":"\\"","4114":":","4115":"\\"","4116":":","4117":"\\"","4118":",","4119":"\\"","4120":"4","4121":"0","4122":"4","4123":"\\"","4124":":","4125":"\\"","4126":"\\\\","4127":"\\"","4128":"\\"","4129":",","4130":"\\"","4131":"4","4132":"0","4133":"5","4134":"\\"","4135":":","4136":"\\"","4137":"4","4138":"\\"","4139":",","4140":"\\"","4141":"4","4142":"0","4143":"6","4144":"\\"","4145":":","4146":"\\"","4147":"\\\\","4148":"\\"","4149":"\\"","4150":",","4151":"\\"","4152":"4","4153":"0","4154":"7","4155":"\\"","4156":":","4157":"\\"","4158":",","4159":"\\"","4160":",","4161":"\\"","4162":"4","4163":"0","4164":"8","4165":"\\"","4166":":","4167":"\\"","4168":"\\\\","4169":"\\"","4170":"\\"","4171":",","4172":"\\"","4173":"4","4174":"0","4175":"9","4176":"\\"","4177":":","4178":"\\"","4179":"4","4180":"\\"","4181":",","4182":"\\"","4183":"4","4184":"1","4185":"0","4186":"\\"","4187":":","4188":"\\"","4189":"6","4190":"\\"","4191":",","4192":"\\"","4193":"4","4194":"1","4195":"1","4196":"\\"","4197":":","4198":"\\"","4199":"\\\\","4200":"\\"","4201":"\\"","4202":",","4203":"\\"","4204":"4","4205":"1","4206":"2","4207":"\\"","4208":":","4209":"\\"","4210":":","4211":"\\"","4212":",","4213":"\\"","4214":"4","4215":"1","4216":"3","4217":"\\"","4218":":","4219":"\\"","4220":"\\\\","4221":"\\"","4222":"\\"","4223":",","4224":"\\"","4225":"4","4226":"1","4227":"4","4228":"\\"","4229":":","4230":"\\"","4231":"2","4232":"\\"","4233":",","4234":"\\"","4235":"4","4236":"1","4237":"5","4238":"\\"","4239":":","4240":"\\"","4241":"\\\\","4242":"\\"","4243":"\\"","4244":",","4245":"\\"","4246":"4","4247":"1","4248":"6","4249":"\\"","4250":":","4251":"\\"","4252":",","4253":"\\"","4254":",","4255":"\\"","4256":"4","4257":"1","4258":"7","4259":"\\"","4260":":","4261":"\\"","4262":"\\\\","4263":"\\"","4264":"\\"","4265":",","4266":"\\"","4267":"4","4268":"1","4269":"8","4270":"\\"","4271":":","4272":"\\"","4273":"4","4274":"\\"","4275":",","4276":"\\"","4277":"4","4278":"1","4279":"9","4280":"\\"","4281":":","4282":"\\"","4283":"7","4284":"\\"","4285":",","4286":"\\"","4287":"4","4288":"2","4289":"0","4290":"\\"","4291":":","4292":"\\"","4293":"\\\\","4294":"\\"","4295":"\\"","4296":",","4297":"\\"","4298":"4","4299":"2","4300":"1","4301":"\\"","4302":":","4303":"\\"","4304":":","4305":"\\"","4306":",","4307":"\\"","4308":"4","4309":"2","4310":"2","4311":"\\"","4312":":","4313":"\\"","4314":"\\\\","4315":"\\"","4316":"\\"","4317":",","4318":"\\"","4319":"4","4320":"2","4321":"3","4322":"\\"","4323":":","4324":"\\"","4325":"d","4326":"\\"","4327":",","4328":"\\"","4329":"4","4330":"2","4331":"4","4332":"\\"","4333":":","4334":"\\"","4335":"\\\\","4336":"\\"","4337":"\\"","4338":",","4339":"\\"","4340":"4","4341":"2","4342":"5","4343":"\\"","4344":":","4345":"\\"","4346":",","4347":"\\"","4348":",","4349":"\\"","4350":"4","4351":"2","4352":"6","4353":"\\"","4354":":","4355":"\\"","4356":"\\\\","4357":"\\"","4358":"\\"","4359":",","4360":"\\"","4361":"4","4362":"2","4363":"7","4364":"\\"","4365":":","4366":"\\"","4367":"4","4368":"\\"","4369":",","4370":"\\"","4371":"4","4372":"2","4373":"8","4374":"\\"","4375":":","4376":"\\"","4377":"8","4378":"\\"","4379":",","4380":"\\"","4381":"4","4382":"2","4383":"9","4384":"\\"","4385":":","4386":"\\"","4387":"\\\\","4388":"\\"","4389":"\\"","4390":",","4391":"\\"","4392":"4","4393":"3","4394":"0","4395":"\\"","4396":":","4397":"\\"","4398":":","4399":"\\"","4400":",","4401":"\\"","4402":"4","4403":"3","4404":"1","4405":"\\"","4406":":","4407":"\\"","4408":"\\\\","4409":"\\"","4410":"\\"","4411":",","4412":"\\"","4413":"4","4414":"3","4415":"2","4416":"\\"","4417":":","4418":"\\"","4419":"5","4420":"\\"","4421":",","4422":"\\"","4423":"4","4424":"3","4425":"3","4426":"\\"","4427":":","4428":"\\"","4429":"\\\\","4430":"\\"","4431":"\\"","4432":",","4433":"\\"","4434":"4","4435":"3","4436":"4","4437":"\\"","4438":":","4439":"\\"","4440":",","4441":"\\"","4442":",","4443":"\\"","4444":"4","4445":"3","4446":"5","4447":"\\"","4448":":","4449":"\\"","4450":"\\\\","4451":"\\"","4452":"\\"","4453":",","4454":"\\"","4455":"4","4456":"3","4457":"6","4458":"\\"","4459":":","4460":"\\"","4461":"4","4462":"\\"","4463":",","4464":"\\"","4465":"4","4466":"3","4467":"7","4468":"\\"","4469":":","4470":"\\"","4471":"9","4472":"\\"","4473":",","4474":"\\"","4475":"4","4476":"3","4477":"8","4478":"\\"","4479":":","4480":"\\"","4481":"\\\\","4482":"\\"","4483":"\\"","4484":",","4485":"\\"","4486":"4","4487":"3","4488":"9","4489":"\\"","4490":":","4491":"\\"","4492":":","4493":"\\"","4494":",","4495":"\\"","4496":"4","4497":"4","4498":"0","4499":"\\"","4500":":","4501":"\\"","4502":"\\\\","4503":"\\"","4504":"\\"","4505":",","4506":"\\"","4507":"4","4508":"4","4509":"1","4510":"\\"","4511":":","4512":"\\"","4513":"e","4514":"\\"","4515":",","4516":"\\"","4517":"4","4518":"4","4519":"2","4520":"\\"","4521":":","4522":"\\"","4523":"\\\\","4524":"\\"","4525":"\\"","4526":",","4527":"\\"","4528":"4","4529":"4","4530":"3","4531":"\\"","4532":":","4533":"\\"","4534":",","4535":"\\"","4536":",","4537":"\\"","4538":"4","4539":"4","4540":"4","4541":"\\"","4542":":","4543":"\\"","4544":"\\\\","4545":"\\"","4546":"\\"","4547":",","4548":"\\"","4549":"4","4550":"4","4551":"5","4552":"\\"","4553":":","4554":"\\"","4555":"5","4556":"\\"","4557":",","4558":"\\"","4559":"4","4560":"4","4561":"6","4562":"\\"","4563":":","4564":"\\"","4565":"0","4566":"\\"","4567":",","4568":"\\"","4569":"4","4570":"4","4571":"7","4572":"\\"","4573":":","4574":"\\"","4575":"\\\\","4576":"\\"","4577":"\\"","4578":",","4579":"\\"","4580":"4","4581":"4","4582":"8","4583":"\\"","4584":":","4585":"\\"","4586":":","4587":"\\"","4588":",","4589":"\\"","4590":"4","4591":"4","4592":"9","4593":"\\"","4594":":","4595":"\\"","4596":"\\\\","4597":"\\"","4598":"\\"","4599":",","4600":"\\"","4601":"4","4602":"5","4603":"0","4604":"\\"","4605":":","4606":"\\"","4607":"\\\\","4608":"\\\\","4609":"\\"","4610":",","4611":"\\"","4612":"4","4613":"5","4614":"1","4615":"\\"","4616":":","4617":"\\"","4618":"\\\\","4619":"\\"","4620":"\\"","4621":",","4622":"\\"","4623":"4","4624":"5","4625":"2","4626":"\\"","4627":":","4628":"\\"","4629":"\\\\","4630":"\\"","4631":"\\"","4632":",","4633":"\\"","4634":"4","4635":"5","4636":"3","4637":"\\"","4638":":","4639":"\\"","4640":",","4641":"\\"","4642":",","4643":"\\"","4644":"4","4645":"5","4646":"4","4647":"\\"","4648":":","4649":"\\"","4650":"\\\\","4651":"\\"","4652":"\\"","4653":",","4654":"\\"","4655":"4","4656":"5","4657":"5","4658":"\\"","4659":":","4660":"\\"","4661":"5","4662":"\\"","4663":",","4664":"\\"","4665":"4","4666":"5","4667":"6","4668":"\\"","4669":":","4670":"\\"","4671":"1","4672":"\\"","4673":",","4674":"\\"","4675":"4","4676":"5","4677":"7","4678":"\\"","4679":":","4680":"\\"","4681":"\\\\","4682":"\\"","4683":"\\"","4684":",","4685":"\\"","4686":"4","4687":"5","4688":"8","4689":"\\"","4690":":","4691":"\\"","4692":":","4693":"\\"","4694":",","4695":"\\"","4696":"4","4697":"5","4698":"9","4699":"\\"","4700":":","4701":"\\"","4702":"\\\\","4703":"\\"","4704":"\\"","4705":",","4706":"\\"","4707":"4","4708":"6","4709":"0","4710":"\\"","4711":":","4712":"\\"","4713":"}","4714":"\\"","4715":",","4716":"\\"","4717":"4","4718":"6","4719":"1","4720":"\\"","4721":":","4722":"\\"","4723":"\\\\","4724":"\\"","4725":"\\"","4726":",","4727":"\\"","4728":"4","4729":"6","4730":"2","4731":"\\"","4732":":","4733":"\\"","4734":",","4735":"\\"","4736":",","4737":"\\"","4738":"4","4739":"6","4740":"3","4741":"\\"","4742":":","4743":"\\"","4744":"\\\\","4745":"\\"","4746":"\\"","4747":",","4748":"\\"","4749":"4","4750":"6","4751":"4","4752":"\\"","4753":":","4754":"\\"","4755":"w","4756":"\\"","4757":",","4758":"\\"","4759":"4","4760":"6","4761":"5","4762":"\\"","4763":":","4764":"\\"","4765":"e","4766":"\\"","4767":",","4768":"\\"","4769":"4","4770":"6","4771":"6","4772":"\\"","4773":":","4774":"\\"","4775":"b","4776":"\\"","4777":",","4778":"\\"","4779":"4","4780":"6","4781":"7","4782":"\\"","4783":":","4784":"\\"","4785":"h","4786":"\\"","4787":",","4788":"\\"","4789":"4","4790":"6","4791":"8","4792":"\\"","4793":":","4794":"\\"","4795":"o","4796":"\\"","4797":",","4798":"\\"","4799":"4","4800":"6","4801":"9","4802":"\\"","4803":":","4804":"\\"","4805":"o","4806":"\\"","4807":",","4808":"\\"","4809":"4","4810":"7","4811":"0","4812":"\\"","4813":":","4814":"\\"","4815":"k","4816":"\\"","4817":",","4818":"\\"","4819":"4","4820":"7","4821":"1","4822":"\\"","4823":":","4824":"\\"","4825":"S","4826":"\\"","4827":",","4828":"\\"","4829":"4","4830":"7","4831":"2","4832":"\\"","4833":":","4834":"\\"","4835":"e","4836":"\\"","4837":",","4838":"\\"","4839":"4","4840":"7","4841":"3","4842":"\\"","4843":":","4844":"\\"","4845":"c","4846":"\\"","4847":",","4848":"\\"","4849":"4","4850":"7","4851":"4","4852":"\\"","4853":":","4854":"\\"","4855":"r","4856":"\\"","4857":",","4858":"\\"","4859":"4","4860":"7","4861":"5","4862":"\\"","4863":":","4864":"\\"","4865":"e","4866":"\\"","4867":",","4868":"\\"","4869":"4","4870":"7","4871":"6","4872":"\\"","4873":":","4874":"\\"","4875":"t","4876":"\\"","4877":",","4878":"\\"","4879":"4","4880":"7","4881":"7","4882":"\\"","4883":":","4884":"\\"","4885":"\\\\","4886":"\\"","4887":"\\"","4888":",","4889":"\\"","4890":"4","4891":"7","4892":"8","4893":"\\"","4894":":","4895":"\\"","4896":":","4897":"\\"","4898":",","4899":"\\"","4900":"4","4901":"7","4902":"9","4903":"\\"","4904":":","4905":"\\"","4906":"\\\\","4907":"\\"","4908":"\\"","4909":",","4910":"\\"","4911":"4","4912":"8","4913":"0","4914":"\\"","4915":":","4916":"\\"","4917":"f","4918":"\\"","4919":",","4920":"\\"","4921":"4","4922":"8","4923":"1","4924":"\\"","4925":":","4926":"\\"","4927":"5","4928":"\\"","4929":",","4930":"\\"","4931":"4","4932":"8","4933":"2","4934":"\\"","4935":":","4936":"\\"","4937":"4","4938":"\\"","4939":",","4940":"\\"","4941":"4","4942":"8","4943":"3","4944":"\\"","4945":":","4946":"\\"","4947":"5","4948":"\\"","4949":",","4950":"\\"","4951":"4","4952":"8","4953":"4","4954":"\\"","4955":":","4956":"\\"","4957":"5","4958":"\\"","4959":",","4960":"\\"","4961":"4","4962":"8","4963":"5","4964":"\\"","4965":":","4966":"\\"","4967":"2","4968":"\\"","4969":",","4970":"\\"","4971":"4","4972":"8","4973":"6","4974":"\\"","4975":":","4976":"\\"","4977":"4","4978":"\\"","4979":",","4980":"\\"","4981":"4","4982":"8","4983":"7","4984":"\\"","4985":":","4986":"\\"","4987":"4","4988":"\\"","4989":",","4990":"\\"","4991":"4","4992":"8","4993":"8","4994":"\\"","4995":":","4996":"\\"","4997":"d","4998":"\\"","4999":",","5000":"\\"","5001":"4","5002":"8","5003":"9","5004":"\\"","5005":":","5006":"\\"","5007":"9","5008":"\\"","5009":",","5010":"\\"","5011":"4","5012":"9","5013":"0","5014":"\\"","5015":":","5016":"\\"","5017":"1","5018":"\\"","5019":",","5020":"\\"","5021":"4","5022":"9","5023":"1","5024":"\\"","5025":":","5026":"\\"","5027":"5","5028":"\\"","5029":",","5030":"\\"","5031":"4","5032":"9","5033":"2","5034":"\\"","5035":":","5036":"\\"","5037":"c","5038":"\\"","5039":",","5040":"\\"","5041":"4","5042":"9","5043":"3","5044":"\\"","5045":":","5046":"\\"","5047":"f","5048":"\\"","5049":",","5050":"\\"","5051":"4","5052":"9","5053":"4","5054":"\\"","5055":":","5056":"\\"","5057":"4","5058":"\\"","5059":",","5060":"\\"","5061":"4","5062":"9","5063":"5","5064":"\\"","5065":":","5066":"\\"","5067":"c","5068":"\\"","5069":",","5070":"\\"","5071":"4","5072":"9","5073":"6","5074":"\\"","5075":":","5076":"\\"","5077":"9","5078":"\\"","5079":",","5080":"\\"","5081":"4","5082":"9","5083":"7","5084":"\\"","5085":":","5086":"\\"","5087":"6","5088":"\\"","5089":",","5090":"\\"","5091":"4","5092":"9","5093":"8","5094":"\\"","5095":":","5096":"\\"","5097":"b","5098":"\\"","5099":",","5100":"\\"","5101":"4","5102":"9","5103":"9","5104":"\\"","5105":":","5106":"\\"","5107":"b","5108":"\\"","5109":",","5110":"\\"","5111":"5","5112":"0","5113":"0","5114":"\\"","5115":":","5116":"\\"","5117":"e","5118":"\\"","5119":",","5120":"\\"","5121":"5","5122":"0","5123":"1","5124":"\\"","5125":":","5126":"\\"","5127":"0","5128":"\\"","5129":",","5130":"\\"","5131":"5","5132":"0","5133":"2","5134":"\\"","5135":":","5136":"\\"","5137":"b","5138":"\\"","5139":",","5140":"\\"","5141":"5","5142":"0","5143":"3","5144":"\\"","5145":":","5146":"\\"","5147":"0","5148":"\\"","5149":",","5150":"\\"","5151":"5","5152":"0","5153":"4","5154":"\\"","5155":":","5156":"\\"","5157":"5","5158":"\\"","5159":",","5160":"\\"","5161":"5","5162":"0","5163":"5","5164":"\\"","5165":":","5166":"\\"","5167":"0","5168":"\\"","5169":",","5170":"\\"","5171":"5","5172":"0","5173":"6","5174":"\\"","5175":":","5176":"\\"","5177":"f","5178":"\\"","5179":",","5180":"\\"","5181":"5","5182":"0","5183":"7","5184":"\\"","5185":":","5186":"\\"","5187":"e","5188":"\\"","5189":",","5190":"\\"","5191":"5","5192":"0","5193":"8","5194":"\\"","5195":":","5196":"\\"","5197":"a","5198":"\\"","5199":",","5200":"\\"","5201":"5","5202":"0","5203":"9","5204":"\\"","5205":":","5206":"\\"","5207":"9","5208":"\\"","5209":",","5210":"\\"","5211":"5","5212":"1","5213":"0","5214":"\\"","5215":":","5216":"\\"","5217":"4","5218":"\\"","5219":",","5220":"\\"","5221":"5","5222":"1","5223":"1","5224":"\\"","5225":":","5226":"\\"","5227":"c","5228":"\\"","5229":",","5230":"\\"","5231":"5","5232":"1","5233":"2","5234":"\\"","5235":":","5236":"\\"","5237":"3","5238":"\\"","5239":",","5240":"\\"","5241":"5","5242":"1","5243":"3","5244":"\\"","5245":":","5246":"\\"","5247":"a","5248":"\\"","5249":",","5250":"\\"","5251":"5","5252":"1","5253":"4","5254":"\\"","5255":":","5256":"\\"","5257":"0","5258":"\\"","5259":",","5260":"\\"","5261":"5","5262":"1","5263":"5","5264":"\\"","5265":":","5266":"\\"","5267":"d","5268":"\\"","5269":",","5270":"\\"","5271":"5","5272":"1","5273":"6","5274":"\\"","5275":":","5276":"\\"","5277":"5","5278":"\\"","5279":",","5280":"\\"","5281":"5","5282":"1","5283":"7","5284":"\\"","5285":":","5286":"\\"","5287":"2","5288":"\\"","5289":",","5290":"\\"","5291":"5","5292":"1","5293":"8","5294":"\\"","5295":":","5296":"\\"","5297":"d","5298":"\\"","5299":",","5300":"\\"","5301":"5","5302":"1","5303":"9","5304":"\\"","5305":":","5306":"\\"","5307":"f","5308":"\\"","5309":",","5310":"\\"","5311":"5","5312":"2","5313":"0","5314":"\\"","5315":":","5316":"\\"","5317":"f","5318":"\\"","5319":",","5320":"\\"","5321":"5","5322":"2","5323":"1","5324":"\\"","5325":":","5326":"\\"","5327":"3","5328":"\\"","5329":",","5330":"\\"","5331":"5","5332":"2","5333":"2","5334":"\\"","5335":":","5336":"\\"","5337":"3","5338":"\\"","5339":",","5340":"\\"","5341":"5","5342":"2","5343":"3","5344":"\\"","5345":":","5346":"\\"","5347":"8","5348":"\\"","5349":",","5350":"\\"","5351":"5","5352":"2","5353":"4","5354":"\\"","5355":":","5356":"\\"","5357":"d","5358":"\\"","5359":",","5360":"\\"","5361":"5","5362":"2","5363":"5","5364":"\\"","5365":":","5366":"\\"","5367":"f","5368":"\\"","5369":",","5370":"\\"","5371":"5","5372":"2","5373":"6","5374":"\\"","5375":":","5376":"\\"","5377":"0","5378":"\\"","5379":",","5380":"\\"","5381":"5","5382":"2","5383":"7","5384":"\\"","5385":":","5386":"\\"","5387":"8","5388":"\\"","5389":",","5390":"\\"","5391":"5","5392":"2","5393":"8","5394":"\\"","5395":":","5396":"\\"","5397":"\\\\","5398":"\\"","5399":"\\"","5400":",","5401":"\\"","5402":"5","5403":"2","5404":"9","5405":"\\"","5406":":","5407":"\\"","5408":"}","5409":"\\"","5410":",","5411":"\\"","5412":"w","5413":"e","5414":"b","5415":"h","5416":"o","5417":"o","5418":"k","5419":"S","5420":"e","5421":"c","5422":"r","5423":"e","5424":"t","5425":"\\"","5426":":","5427":"\\"","5428":"8","5429":"1","5430":"0","5431":"c","5432":"7","5433":"3","5434":"1","5435":"5","5436":"0","5437":"4","5438":"d","5439":"e","5440":"a","5441":"7","5442":"1","5443":"9","5444":"d","5445":"e","5446":"6","5447":"4","5448":"d","5449":"9","5450":"2","5451":"9","5452":"5","5453":"1","5454":"5","5455":"d","5456":"7","5457":"8","5458":"f","5459":"b","5460":"b","5461":"b","5462":"5","5463":"c","5464":"8","5465":"3","5466":"1","5467":"d","5468":"d","5469":"0","5470":"f","5471":"4","5472":"7","5473":"c","5474":"d","5475":"8","5476":"\\"","5477":"}","webhookSecret":"e322a7f1ccf9b27b3652eb46ac423495987cad918af0506d"}	eyJib3RUb2tlbiI6Ijg5NTQwMDg2OTA6QUFHRnRRV3c2SHN0SVFnNTNzUllWX3pIaGFWaUJzaEZCeDAifQ==	Omnitech_bot	\N	\N	\N	\N	2026-06-16 21:50:46.289756	2026-06-16 21:53:16.436
\.


--
-- Data for Name: org_invitations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_invitations (id, org_id, invited_by, email, role, token, expires_at, accepted_at, created_at) FROM stdin;
\.


--
-- Data for Name: org_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_members (id, org_id, user_id, role, joined_at, is_suspended) FROM stdin;
8	10	4	owner	2026-06-15 12:56:10.80667	f
9	10	6	owner	2026-06-15 12:56:10.80667	f
10	20	4	owner	2026-06-15 12:57:10.271339	f
11	20	6	owner	2026-06-15 12:57:10.271339	f
12	8	7	owner	2026-06-15 14:41:25.087887	f
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (id, name, slug, plan, logo_url, created_at, status) FROM stdin;
10	OmniTech Demo	omnitech-demo	professional	\N	2026-03-17 12:56:10.80667	active
20	Piloto Clientes	piloto-clientes	starter	\N	2026-06-15 12:57:10.271339	active
8	Demos	demos-0v5w7	free	\N	2026-06-15 14:41:24.97295	active
\.


--
-- Data for Name: platform_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_roles (id, clerk_user_id, role, display_name, email, granted_by, is_active, notes, created_at, updated_at) FROM stdin;
1	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	SUPER_ADMIN	A3 Servicio	a3servicio@gmail.com	system	t	\N	2026-06-14 03:00:29.723995	2026-06-14 03:00:29.723995
2	user_3F2in1cpKPN0a8yR8iRfeK9YZOd	SUPER_ADMIN	OmniTech Core	omnitechcore01@gmail.com	system	t	\N	2026-06-14 03:00:29.723995	2026-06-14 03:00:29.723995
\.


--
-- Data for Name: quote_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quote_items (id, quote_id, description, quantity, unit_price, total, order_index) FROM stdin;
30	15	Hosting servidor VPS dedicado	12	29.99	359.88	0
31	15	Mantenimiento y actualizaciones mensuales	12	45	540	0
32	15	Soporte técnico prioritario (4h/mes)	12	8.34	100.08	0
33	16	Gestión SEO mensual	3	450	1350	0
34	16	Gestión SEM (Google Ads)	3	380	1140	0
35	16	Community management RRSS	3	134.19	402.56	0
36	17	Análisis y diseño arquitectura	1	1200	1200	0
37	17	Desarrollo frontend + backend	1	3800	3800	0
38	17	Integración ERP Sage 50	1	1611.57	1611.57	0
39	18	Diseño logotipo (3 propuestas)	1	250	250	0
40	18	Manual de identidad corporativa	1	180	180	0
41	18	Papelería corporativa (tarjeta, hoja membrete)	1	107.19	107.19	0
42	19	Sesión análisis de procesos (4h)	1	480	480	0
43	19	Configuración y parametrización CRM	1	650	650	0
44	19	Formación equipo comercial (2 sesiones)	2	344.09	688.18	0
45	20	Configuración inicial de la plataforma de automatización de WhatsApp	1	800	800	0
46	20	Desarrollo de flujos de conversación personalizados para seguimiento de leads	1	900	900	1
47	20	Integración con CRM para gestión de leads	1	600	600	2
48	20	Capacitación al equipo sobre el uso de la herramienta	1	200	200	3
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotes (id, org_id, client_id, title, status, currency, subtotal, tax_rate, tax_amount, total, notes, valid_until, created_at, updated_at) FROM stdin;
15	10	202	Mantenimiento Web Corporativa — Plan Anual	sent	EUR	1000	21	210	1210	Incluye hosting, actualizaciones y soporte técnico mensual.	2026-06-30 12:58:18.48976	2026-06-10 12:58:18.48976	2026-06-15 12:58:18.48976
16	10	203	Campaña Marketing Digital — Q3 2026	accepted	EUR	2892.56	21	607.44	3500	SEO, SEM y gestión de redes sociales. Duración 3 meses.	2026-07-15 12:58:18.48976	2026-05-26 12:58:18.48976	2026-06-15 12:58:18.48976
17	10	202	Desarrollo e-Commerce B2B con Integración ERP	draft	EUR	6611.57	21	1388.43	8000	Portal de pedidos para clientes industriales. Integración con Sage 50.	2026-07-30 12:58:18.48976	2026-06-13 12:58:18.48976	2026-06-15 12:58:18.48976
18	10	205	Diseño de Identidad Corporativa Completa	sent	EUR	537.19	21	112.81	650	Logo, manual de marca, tarjetas y papelería corporativa.	2026-06-25 12:58:18.48976	2026-06-07 12:58:18.48976	2026-06-15 12:58:18.48976
19	10	209	Consultoría Estratégica CRM — Plan de Implantación	accepted	EUR	1818.18	21	381.82	2200	Análisis, configuración y formación. 4 sesiones presenciales.	2026-07-05 12:58:18.48976	2026-05-31 12:58:18.48976	2026-06-15 12:58:18.48976
20	8	229	Propuesta de Automatización de WhatsApp para Cliente 20	draft	EUR	2500	21	525	3025	Condiciones de pago: 50% al inicio y 50% a la entrega.\nAlcance del servicio: Incluye configuración, desarrollo, integración y capacitación.\nExclusiones: No incluye costos de licencias de software ni mantenimiento posterior.\nValidez de la propuesta: 30 días desde la fecha de emisión.	2026-07-15 14:46:00.21	2026-06-15 14:47:08.275174	2026-06-15 14:47:08.275174
\.


--
-- Data for Name: role_catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_catalog (role, scope, description, priority, created_at) FROM stdin;
SUPER_ADMIN	platform	Acceso total a la plataforma OmniTech	100	2026-06-14 03:34:25.28287
STAFF_OMNITECH	platform	Personal interno de OmniTech	90	2026-06-14 03:34:25.28287
owner	org	Propietario de la organización	80	2026-06-14 03:34:25.28287
admin	org	Administrador de la organización	70	2026-06-14 03:34:25.28287
member	org	Miembro estándar de la organización	60	2026-06-14 03:34:25.28287
read_only	org	Acceso de solo lectura	50	2026-06-14 03:34:25.28287
CLIENT	client	Usuario cliente externo (sin acceso al CRM)	10	2026-06-14 03:34:25.28287
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, clerk_id, email, name, avatar_url, created_at, status, suspended_reason, suspended_at) FROM stdin;
7	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	Javilisto123 123	https://img.clerk.com/eyJ0eXBlIjoicHJveHkiLCJzcmMiOiJodHRwczovL2ltYWdlcy5jbGVyay5kZXYvb2F1dGhfZ29vZ2xlL2ltZ18zRjBRWFZ0VkIwUWkwekZadzVFREhyQUdXVHEifQ	2026-06-15 14:37:20.230219	active	\N	\N
6	user_3F2in1cpKPN0a8yR8iRfeK9YZOd	omnitechcore01@gmail.com	\N	https://img.clerk.com/eyJ0eXBlIjoiZGVmYXVsdCIsImlpZCI6Imluc18zRXpoclBzWWNmN3E5RmhYMWE2c1QzR0VOakkiLCJyaWQiOiJ1c2VyXzNGMmluMWNwS1BOMGE4eVI4aVJmZUs5WVpPZCJ9	2026-06-12 15:55:29.920529	active	\N	\N
4	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	a3servicios servicios	https://img.clerk.com/eyJ0eXBlIjoicHJveHkiLCJzcmMiOiJodHRwczovL2ltYWdlcy5jbGVyay5kZXYvb2F1dGhfZ29vZ2xlL2ltZ18zRjBRUTZldjNoN1hidDc0ajVLeDBuVWlJUWgifQ	2026-06-11 20:24:48.772775	active	\N	\N
\.


--
-- Name: activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_id_seq', 122, true);


--
-- Name: agent_memory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agent_memory_id_seq', 57, true);


--
-- Name: ai_budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_budgets_id_seq', 2, true);


--
-- Name: ai_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_messages_id_seq', 244, true);


--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_usage_logs_id_seq', 9, true);


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_id_seq', 40, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 45, true);


--
-- Name: backup_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_jobs_id_seq', 47, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_id_seq', 240, true);


--
-- Name: import_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.import_jobs_id_seq', 6, true);


--
-- Name: integration_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.integration_events_id_seq', 53, true);


--
-- Name: integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.integrations_id_seq', 507, true);


--
-- Name: knowledge_base_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knowledge_base_id_seq', 1, false);


--
-- Name: license_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.license_plans_id_seq', 3, true);


--
-- Name: memory_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.memory_history_id_seq', 7, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 35, true);


--
-- Name: module_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.module_configs_id_seq', 12, true);


--
-- Name: org_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_integrations_id_seq', 7, true);


--
-- Name: org_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_invitations_id_seq', 3, true);


--
-- Name: org_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_members_id_seq', 12, true);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_id_seq', 8, true);


--
-- Name: platform_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.platform_roles_id_seq', 2, true);


--
-- Name: quote_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quote_items_id_seq', 48, true);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotes_id_seq', 20, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: activity activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id);


--
-- Name: agent_memory agent_memory_org_id_agent_slug_memory_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_org_id_agent_slug_memory_key_unique UNIQUE (org_id, agent_slug, memory_key);


--
-- Name: agent_memory agent_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_pkey PRIMARY KEY (id);


--
-- Name: ai_budgets ai_budgets_org_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_org_id_key UNIQUE (org_id);


--
-- Name: ai_budgets ai_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_pkey PRIMARY KEY (id);


--
-- Name: ai_messages ai_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_sessions ai_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: import_jobs import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_pkey PRIMARY KEY (id);


--
-- Name: integration_events integration_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events
    ADD CONSTRAINT integration_events_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_slug_unique UNIQUE (slug);


--
-- Name: knowledge_base knowledge_base_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_pkey PRIMARY KEY (id);


--
-- Name: license_plans license_plans_org_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_org_id_key UNIQUE (org_id);


--
-- Name: license_plans license_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_pkey PRIMARY KEY (id);


--
-- Name: memory_history memory_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history
    ADD CONSTRAINT memory_history_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: module_configs module_configs_org_id_module_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_org_id_module_slug_key UNIQUE (org_id, module_slug);


--
-- Name: module_configs module_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_pkey PRIMARY KEY (id);


--
-- Name: org_integrations org_integrations_org_id_integration_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_org_id_integration_slug_unique UNIQUE (org_id, integration_slug);


--
-- Name: org_integrations org_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_pkey PRIMARY KEY (id);


--
-- Name: org_invitations org_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_pkey PRIMARY KEY (id);


--
-- Name: org_invitations org_invitations_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_token_unique UNIQUE (token);


--
-- Name: org_members org_members_org_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_user_id_unique UNIQUE (org_id, user_id);


--
-- Name: org_members org_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_slug_unique UNIQUE (slug);


--
-- Name: platform_roles platform_roles_clerk_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles
    ADD CONSTRAINT platform_roles_clerk_user_id_key UNIQUE (clerk_user_id);


--
-- Name: platform_roles platform_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles
    ADD CONSTRAINT platform_roles_pkey PRIMARY KEY (id);


--
-- Name: quote_items quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: role_catalog role_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_catalog
    ADD CONSTRAINT role_catalog_pkey PRIMARY KEY (role);


--
-- Name: users users_clerk_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_clerk_id_unique UNIQUE (clerk_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_usage_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_usage_created ON public.ai_usage_logs USING btree (created_at DESC);


--
-- Name: idx_ai_usage_org_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_usage_org_created ON public.ai_usage_logs USING btree (org_id, created_at DESC);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_actor ON public.audit_logs USING btree (actor_clerk_id);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_org ON public.audit_logs USING btree (org_id);


--
-- Name: idx_import_jobs_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_import_jobs_org ON public.import_jobs USING btree (org_id, created_at DESC);


--
-- Name: knowledge_base_org_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX knowledge_base_org_idx ON public.knowledge_base USING btree (org_id);


--
-- Name: activity activity_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: agent_memory agent_memory_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_budgets ai_budgets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_messages ai_messages_session_id_ai_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_session_id_ai_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.ai_sessions(id) ON DELETE CASCADE;


--
-- Name: ai_sessions ai_sessions_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_sessions ai_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: clients clients_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: import_jobs import_jobs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: integration_events integration_events_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events
    ADD CONSTRAINT integration_events_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: knowledge_base knowledge_base_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: license_plans license_plans_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: memory_history memory_history_memory_id_agent_memory_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history
    ADD CONSTRAINT memory_history_memory_id_agent_memory_id_fk FOREIGN KEY (memory_id) REFERENCES public.agent_memory(id) ON DELETE CASCADE;


--
-- Name: messages messages_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: messages messages_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: module_configs module_configs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_integrations org_integrations_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_invitations org_invitations_invited_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_invited_by_users_id_fk FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: org_invitations org_invitations_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quote_items quote_items_quote_id_quotes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_quote_id_quotes_id_fk FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict iCWwGulIsalvBax5cpoJ5sURpVuZTc6cW1xgE9S44gOjKYdC4VCY7cmzL23J5Nt

