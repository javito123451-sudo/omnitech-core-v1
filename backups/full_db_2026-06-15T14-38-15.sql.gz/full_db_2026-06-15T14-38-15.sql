--
-- PostgreSQL database dump
--

\restrict wOl0Fm1yH94P9QXadvjmVL3qFjydmwD5XlbJF61PVQe3P1OPiPjIOc61a5s8svv

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity (
    id integer NOT NULL,
    type text NOT NULL,
    description text NOT NULL,
    client_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL,
    user_id integer
);


ALTER TABLE public.activity OWNER TO postgres;

--
-- Name: activity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_id_seq OWNER TO postgres;

--
-- Name: activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_id_seq OWNED BY public.activity.id;


--
-- Name: agent_memory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_memory (
    id integer NOT NULL,
    org_id integer NOT NULL,
    agent_slug text NOT NULL,
    memory_key text NOT NULL,
    memory_val text NOT NULL,
    source text DEFAULT 'user_input'::text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    title text,
    category text,
    tags text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.agent_memory OWNER TO postgres;

--
-- Name: agent_memory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agent_memory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_memory_id_seq OWNER TO postgres;

--
-- Name: agent_memory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agent_memory_id_seq OWNED BY public.agent_memory.id;


--
-- Name: ai_budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_budgets (
    id integer NOT NULL,
    org_id integer NOT NULL,
    monthly_budget_usd numeric(10,2) DEFAULT 10.00,
    alert_80 boolean DEFAULT true,
    alert_90 boolean DEFAULT true,
    block_at_100 boolean DEFAULT true,
    is_blocked boolean DEFAULT false,
    block_reason text,
    updated_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_budgets OWNER TO postgres;

--
-- Name: ai_budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_budgets_id_seq OWNER TO postgres;

--
-- Name: ai_budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_budgets_id_seq OWNED BY public.ai_budgets.id;


--
-- Name: ai_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_messages (
    id integer NOT NULL,
    session_id uuid NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    tokens_used integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_messages OWNER TO postgres;

--
-- Name: ai_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_messages_id_seq OWNER TO postgres;

--
-- Name: ai_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_messages_id_seq OWNED BY public.ai_messages.id;


--
-- Name: ai_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id integer NOT NULL,
    user_id integer NOT NULL,
    agent_slug text DEFAULT 'operator'::text NOT NULL,
    title text,
    client_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_sessions OWNER TO postgres;

--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_usage_logs (
    id integer NOT NULL,
    org_id integer,
    user_clerk_id text,
    function_name text NOT NULL,
    model text NOT NULL,
    tokens_input integer DEFAULT 0,
    tokens_output integer DEFAULT 0,
    tokens_total integer DEFAULT 0,
    cost_usd numeric(10,6) DEFAULT 0,
    duration_ms integer,
    status text DEFAULT 'ok'::text,
    error_msg text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_usage_logs OWNER TO postgres;

--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_usage_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_usage_logs_id_seq OWNER TO postgres;

--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_usage_logs_id_seq OWNED BY public.ai_usage_logs.id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    client_id integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    type text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    reminder boolean DEFAULT false NOT NULL,
    tags text,
    location text,
    org_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    actor_clerk_id text,
    actor_email text,
    action text NOT NULL,
    resource text,
    resource_id text,
    org_id integer,
    ip_address text,
    user_agent text,
    details jsonb,
    severity text DEFAULT 'info'::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_jobs (
    id integer NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    org_id integer,
    file_path text,
    file_name text,
    size_bytes bigint,
    checksum text,
    row_count integer,
    error text,
    triggered_by text,
    metadata jsonb,
    started_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    expires_at timestamp without time zone
);


ALTER TABLE public.backup_jobs OWNER TO postgres;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_jobs_id_seq OWNER TO postgres;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_jobs_id_seq OWNED BY public.backup_jobs.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    company text,
    status text DEFAULT 'lead'::text NOT NULL,
    tags text,
    notes text,
    value real,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL,
    telegram_chat_id text
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_id_seq OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: import_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.import_jobs (
    id integer NOT NULL,
    org_id integer,
    user_clerk_id text,
    status text DEFAULT 'completed'::text,
    file_name text,
    file_type text,
    detected_type text,
    confidence_pct integer DEFAULT 0,
    raw_text text,
    extracted_data jsonb,
    suggested_dest text,
    duplicates_found jsonb,
    records_created integer DEFAULT 0,
    errors text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.import_jobs OWNER TO postgres;

--
-- Name: import_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.import_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.import_jobs_id_seq OWNER TO postgres;

--
-- Name: import_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.import_jobs_id_seq OWNED BY public.import_jobs.id;


--
-- Name: integration_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_events (
    id integer NOT NULL,
    org_id integer NOT NULL,
    integration_slug text NOT NULL,
    direction text DEFAULT 'inbound'::text NOT NULL,
    event_type text NOT NULL,
    status text DEFAULT 'processed'::text NOT NULL,
    summary text,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    payload_json text
);


ALTER TABLE public.integration_events OWNER TO postgres;

--
-- Name: integration_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.integration_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.integration_events_id_seq OWNER TO postgres;

--
-- Name: integration_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.integration_events_id_seq OWNED BY public.integration_events.id;


--
-- Name: integrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrations (
    id integer NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    auth_type text NOT NULL,
    description text,
    icon_slug text,
    plan_required text DEFAULT 'free'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.integrations OWNER TO postgres;

--
-- Name: integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.integrations_id_seq OWNER TO postgres;

--
-- Name: integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.integrations_id_seq OWNED BY public.integrations.id;


--
-- Name: license_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.license_plans (
    id integer NOT NULL,
    org_id integer NOT NULL,
    plan text DEFAULT 'starter'::text NOT NULL,
    seats integer DEFAULT 5,
    valid_from timestamp without time zone DEFAULT now(),
    valid_until timestamp without time zone,
    is_active boolean DEFAULT true,
    billing_cycle text DEFAULT 'monthly'::text,
    notes text,
    assigned_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.license_plans OWNER TO postgres;

--
-- Name: license_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.license_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.license_plans_id_seq OWNER TO postgres;

--
-- Name: license_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.license_plans_id_seq OWNED BY public.license_plans.id;


--
-- Name: memory_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.memory_history (
    id integer NOT NULL,
    memory_id integer NOT NULL,
    org_id integer NOT NULL,
    action text NOT NULL,
    prev_title text,
    new_title text,
    prev_val text,
    new_val text,
    source text,
    changed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.memory_history OWNER TO postgres;

--
-- Name: memory_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.memory_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.memory_history_id_seq OWNER TO postgres;

--
-- Name: memory_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.memory_history_id_seq OWNED BY public.memory_history.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    client_id integer NOT NULL,
    content text NOT NULL,
    direction text DEFAULT 'outbound'::text NOT NULL,
    is_ai boolean DEFAULT false,
    status text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: module_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.module_configs (
    id integer NOT NULL,
    org_id integer NOT NULL,
    module_slug text NOT NULL,
    is_enabled boolean DEFAULT true,
    config jsonb DEFAULT '{}'::jsonb,
    updated_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.module_configs OWNER TO postgres;

--
-- Name: module_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.module_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.module_configs_id_seq OWNER TO postgres;

--
-- Name: module_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.module_configs_id_seq OWNED BY public.module_configs.id;


--
-- Name: org_integrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_integrations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    integration_slug text NOT NULL,
    status text DEFAULT 'inactive'::text NOT NULL,
    config text,
    credentials_enc text,
    display_name text,
    external_id text,
    last_synced_at timestamp without time zone,
    expires_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.org_integrations OWNER TO postgres;

--
-- Name: org_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_integrations_id_seq OWNER TO postgres;

--
-- Name: org_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_integrations_id_seq OWNED BY public.org_integrations.id;


--
-- Name: org_invitations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_invitations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    invited_by integer NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    accepted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.org_invitations OWNER TO postgres;

--
-- Name: org_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_invitations_id_seq OWNER TO postgres;

--
-- Name: org_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_invitations_id_seq OWNED BY public.org_invitations.id;


--
-- Name: org_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_members (
    id integer NOT NULL,
    org_id integer NOT NULL,
    user_id integer NOT NULL,
    role text DEFAULT 'owner'::text NOT NULL,
    joined_at timestamp without time zone DEFAULT now() NOT NULL,
    is_suspended boolean DEFAULT false
);


ALTER TABLE public.org_members OWNER TO postgres;

--
-- Name: org_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_members_id_seq OWNER TO postgres;

--
-- Name: org_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_members_id_seq OWNED BY public.org_members.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    plan text DEFAULT 'free'::text NOT NULL,
    logo_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'active'::text NOT NULL
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizations_id_seq OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: platform_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_roles (
    id integer NOT NULL,
    clerk_user_id text NOT NULL,
    role text DEFAULT 'STAFF_OMNITECH'::text NOT NULL,
    display_name text,
    email text,
    granted_by text,
    is_active boolean DEFAULT true,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.platform_roles OWNER TO postgres;

--
-- Name: platform_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.platform_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.platform_roles_id_seq OWNER TO postgres;

--
-- Name: platform_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.platform_roles_id_seq OWNED BY public.platform_roles.id;


--
-- Name: quote_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quote_items (
    id integer NOT NULL,
    quote_id integer NOT NULL,
    description text NOT NULL,
    quantity real DEFAULT 1 NOT NULL,
    unit_price real DEFAULT 0 NOT NULL,
    total real DEFAULT 0 NOT NULL,
    order_index integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.quote_items OWNER TO postgres;

--
-- Name: quote_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quote_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quote_items_id_seq OWNER TO postgres;

--
-- Name: quote_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quote_items_id_seq OWNED BY public.quote_items.id;


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotes (
    id integer NOT NULL,
    org_id integer NOT NULL,
    client_id integer NOT NULL,
    title text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    subtotal real DEFAULT 0 NOT NULL,
    tax_rate real DEFAULT 21 NOT NULL,
    tax_amount real DEFAULT 0 NOT NULL,
    total real DEFAULT 0 NOT NULL,
    notes text,
    valid_until timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quotes OWNER TO postgres;

--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotes_id_seq OWNER TO postgres;

--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- Name: role_catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_catalog (
    role text NOT NULL,
    scope text NOT NULL,
    description text,
    priority integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.role_catalog OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    clerk_id text NOT NULL,
    email text NOT NULL,
    name text,
    avatar_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    suspended_reason text,
    suspended_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity ALTER COLUMN id SET DEFAULT nextval('public.activity_id_seq'::regclass);


--
-- Name: agent_memory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory ALTER COLUMN id SET DEFAULT nextval('public.agent_memory_id_seq'::regclass);


--
-- Name: ai_budgets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets ALTER COLUMN id SET DEFAULT nextval('public.ai_budgets_id_seq'::regclass);


--
-- Name: ai_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages ALTER COLUMN id SET DEFAULT nextval('public.ai_messages_id_seq'::regclass);


--
-- Name: ai_usage_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_usage_logs_id_seq'::regclass);


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backup_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_jobs ALTER COLUMN id SET DEFAULT nextval('public.backup_jobs_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: import_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs ALTER COLUMN id SET DEFAULT nextval('public.import_jobs_id_seq'::regclass);


--
-- Name: integration_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events ALTER COLUMN id SET DEFAULT nextval('public.integration_events_id_seq'::regclass);


--
-- Name: integrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations ALTER COLUMN id SET DEFAULT nextval('public.integrations_id_seq'::regclass);


--
-- Name: license_plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans ALTER COLUMN id SET DEFAULT nextval('public.license_plans_id_seq'::regclass);


--
-- Name: memory_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history ALTER COLUMN id SET DEFAULT nextval('public.memory_history_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: module_configs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs ALTER COLUMN id SET DEFAULT nextval('public.module_configs_id_seq'::regclass);


--
-- Name: org_integrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations ALTER COLUMN id SET DEFAULT nextval('public.org_integrations_id_seq'::regclass);


--
-- Name: org_invitations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations ALTER COLUMN id SET DEFAULT nextval('public.org_invitations_id_seq'::regclass);


--
-- Name: org_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members ALTER COLUMN id SET DEFAULT nextval('public.org_members_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: platform_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles ALTER COLUMN id SET DEFAULT nextval('public.platform_roles_id_seq'::regclass);


--
-- Name: quote_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items ALTER COLUMN id SET DEFAULT nextval('public.quote_items_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity (id, type, description, client_name, created_at, org_id, user_id) FROM stdin;
93	quote_accepted	Presupuesto aceptado: Campaña Marketing Digital Q3 2026	Clínica Dental Peñalver	2026-05-26 12:58:18.48976	10	\N
94	quote_accepted	Presupuesto aceptado: Consultoría Estratégica CRM	Inmobiliaria Costa Blanca	2026-05-31 12:58:18.48976	10	\N
95	client_created	Nuevo lead registrado desde WhatsApp	Fontanería García e Hijos	2026-06-08 12:58:18.48976	10	\N
96	message_received	Mensaje recibido: consulta sobre CRM para hostelería	Restaurante El Rincón de Pepe	2026-06-08 12:58:18.48976	10	\N
97	appointment_set	Cita agendada: Demo CRM para restaurante	Restaurante El Rincón de Pepe	2026-06-14 12:58:18.48976	10	\N
98	client_created	Nuevo lead: interés en módulo de citas online	Peluquería Estilo Moderno	2026-06-10 12:58:18.48976	10	\N
99	quote_sent	Presupuesto enviado: Mantenimiento Web Plan Anual	Construcciones Martínez S.L.	2026-06-10 12:58:18.48976	10	\N
100	appointment_set	Reunión de seguimiento confirmada — mañana 10h	Construcciones Martínez S.L.	2026-06-12 12:58:18.48976	10	\N
\.


--
-- Data for Name: agent_memory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_memory (id, org_id, agent_slug, memory_key, memory_val, source, updated_at, title, category, tags, created_at) FROM stdin;
\.


--
-- Data for Name: ai_budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_budgets (id, org_id, monthly_budget_usd, alert_80, alert_90, block_at_100, is_blocked, block_reason, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_messages (id, session_id, role, content, tokens_used, created_at) FROM stdin;
\.


--
-- Data for Name: ai_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_sessions (id, org_id, user_id, agent_slug, title, client_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_usage_logs (id, org_id, user_clerk_id, function_name, model, tokens_input, tokens_output, tokens_total, cost_usd, duration_ms, status, error_msg, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (id, title, description, start_time, end_time, client_id, status, type, created_at, reminder, tags, location, org_id) FROM stdin;
33	Seguimiento proyecto e-Commerce	Revisión avance módulos y planificación siguiente sprint.	2026-06-16 22:58:18.48976	2026-06-16 23:58:18.48976	202	confirmed	meeting	2026-06-12 12:58:18.48976	t	\N	Av. del Puerto 32, Valencia	10
34	Resultados campaña marketing Q2	Dashboard de métricas y propuesta Q3.	2026-06-18 04:58:18.48976	2026-06-18 05:58:18.48976	203	confirmed	call	2026-06-10 12:58:18.48976	t	\N	Videollamada Google Meet	10
35	Consultoría CRM: Análisis de procesos	Mapeo de flujos comerciales actuales y pain points.	2026-06-18 21:58:18.48976	2026-06-18 23:58:18.48976	209	confirmed	meeting	2026-06-13 12:58:18.48976	t	\N	Calle Mayor 15, Madrid	10
36	Entrega identidad corporativa	Presentación propuestas de logo. Cliente revisa y aprueba.	2026-06-20 00:58:18.48976	2026-06-20 01:58:18.48976	205	pending	call	2026-06-14 12:58:18.48976	f	\N	Videollamada Zoom	10
37	Demo OmniTech CRM — Restaurante	Demostración módulo gestión de clientes y reservas.	2026-06-20 23:58:18.48976	2026-06-21 00:58:18.48976	204	pending	demo	2026-06-15 12:58:18.48976	f	\N	Plaza Mayor 7, Sevilla	10
38	Propuesta gestión citas peluquería	Explicación módulo calendario y reservas online.	2026-06-22 22:58:18.48976	2026-06-22 23:28:18.48976	206	pending	call	2026-06-15 12:58:18.48976	f	\N	Videollamada WhatsApp	10
39	Consultoría CRM: Configuración inicial	Configuración CRM, importación de datos y flujos automatizados.	2026-06-25 21:58:18.48976	2026-06-25 23:58:18.48976	209	confirmed	meeting	2026-06-14 12:58:18.48976	t	\N	Calle Mayor 15, Madrid	10
40	Kick-off campaña Q3 — Planning	Calendario editorial y distribución presupuesto Ads.	2026-06-28 03:58:18.48976	2026-06-28 04:58:18.48976	203	pending	meeting	2026-06-15 12:58:18.48976	f	\N	Videollamada Google Meet	10
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, actor_clerk_id, actor_email, action, resource, resource_id, org_id, ip_address, user_agent, details, severity, created_at) FROM stdin;
18	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	7	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "Omnitech venta", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-15 11:42:55.740574
19	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	7	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "Omnitech venta", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-15 11:42:55.741882
20	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_login	session	\N	7	192.168.1.10	\N	{"result": "success", "userName": "Juan García"}	info	2026-06-15 12:25:33.153457
21	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_logout	session	\N	7	192.168.1.10	\N	{"result": "success", "userName": "Juan García"}	info	2026-06-15 12:25:33.153457
22	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_created	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "email": "info@modelo.es", "result": "success", "status": "lead"}	info	2026-06-15 12:25:33.153457
23	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_updated	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "result": "success", "changes": ["phone", "status"]}	info	2026-06-15 12:25:33.153457
24	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_deleted	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "email": "info@modelo.es", "result": "success"}	warning	2026-06-15 12:25:33.153457
25	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	import_completed	import	\N	7	192.168.1.10	\N	{"errors": 0, "result": "success", "created": 47, "updated": 3, "fileName": "clientes_mayo.xlsx"}	info	2026-06-15 12:25:33.153457
26	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	integration_connected	integration	whatsapp	7	192.168.1.10	\N	{"slug": "whatsapp", "result": "success"}	info	2026-06-15 12:25:33.153457
27	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	integration_disconnected	integration	whatsapp	7	192.168.1.10	\N	{"slug": "whatsapp", "result": "success"}	warning	2026-06-15 12:25:33.153457
28	system:whatsapp:7	\N	whatsapp_message_received	whatsapp_message	wamid.test001	7	\N	\N	{"text": "Acepto el presupuesto", "phone": "611234567", "result": "success", "clientName": "Pedro López"}	info	2026-06-15 12:25:33.153457
29	system:whatsapp:7	\N	whatsapp_quote_accepted	quote	15	7	\N	\N	{"result": "accepted", "clientName": "Pedro López", "quoteTitle": "Mantenimiento Anual"}	info	2026-06-15 12:25:33.153457
30	system:whatsapp:7	\N	whatsapp_quote_rejected	quote	16	7	\N	\N	{"result": "rejected", "clientName": "Ana Martínez", "quoteTitle": "Instalación Premium"}	info	2026-06-15 12:25:33.153457
31	user_3ExXLGMKxDArT1bBizVRyyNkH9N	admin@omnitech.com	workspace_suspended	workspace	5	\N	10.0.0.1	\N	{"reason": "Pago pendiente", "result": "success"}	warning	2026-06-15 12:25:33.153457
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_jobs (id, type, status, org_id, file_path, file_name, size_bytes, checksum, row_count, error, triggered_by, metadata, started_at, completed_at, expires_at) FROM stdin;
5	workspace	completed	7	/home/runner/workspace/backups/workspace_7_2026-06-15T12-40-10.json	workspace_7_2026-06-15T12-40-10.json	1205	c3d508a9cc90b7d8cd274596d7b84eb9056a5c786fd6ba0053c44374aedc10f6	4	\N	test:manual	{"orgId": 7}	2026-06-15 12:42:42.229026	2026-06-15 12:42:42.229026	2026-07-15 12:42:42.229026
6	config	completed	\N	/home/runner/workspace/backups/config_platform_2026-06-15T12-40-14.json	config_platform_2026-06-15T12-40-14.json	2672	a6c53f51ebab5c39b6c2c00e30b4244cc62e504e6a14035167d9fdb496a23e6d	12	\N	test:manual	{}	2026-06-15 12:42:44.326804	2026-06-15 12:42:44.326804	2026-07-15 12:42:44.326804
7	audit	completed	\N	/home/runner/workspace/backups/audit_platform_2026-06-15T12-40-34.json	audit_platform_2026-06-15T12-40-34.json	5510	67c35082b40bf169c703ca1d497727b4650ca0fde1377150977581237fd0a4f3	14	\N	test:manual	{"totalLogs": 14}	2026-06-15 12:42:45.081958	2026-06-15 12:42:45.081958	2026-07-15 12:42:45.081958
11	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-15T12-41-15.sql.gz	full_db_2026-06-15T12-41-15.sql.gz	9597	132088dfdb2ea80cdb811265fa281b0212731371b6c85c7183c01fa10795eae0	\N	\N	test:manual	{"lines": 2228, "tables": 26}	2026-06-15 12:43:34.332691	2026-06-15 12:43:34.332691	2026-07-15 12:43:34.332691
12	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-15T12-45-35.sql.gz	full_db_2026-06-15T12-45-35.sql.gz	10056	81858cd91083e8472850c3b9448e6580d7f68739d5ee1044416106d68ace30f1	\N	\N	auto:scheduler	\N	2026-06-15 12:45:35.206557	2026-06-15 12:45:36.274	2026-07-15 12:45:35.163
13	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-15 12:45:36.344582	2026-06-15 12:45:36.42	2026-07-15 12:45:36.343
14	full_db	completed	\N	/home/runner/workspace/backups/pre_launch_backup_2026-06-15T12-54-21.sql.gz	pre_launch_backup_2026-06-15T12-54-21.sql.gz	10184	3e650f5ce78cba09f14239e72e21bc275551b512fa2f1b0f51e751f3b5ff63a6	\N	\N	system:pre_launch	{"reason": "pre-launch cleanup backup"}	2026-06-15 12:54:22.530745	2026-06-15 12:54:22.530745	2026-09-13 12:54:22.530745
15	full_db	running	\N	\N	\N	\N	\N	\N	\N	auto:scheduler	\N	2026-06-15 14:38:15.604663	\N	2026-07-15 14:38:15.602
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, name, email, phone, company, status, tags, notes, value, created_at, org_id, telegram_chat_id) FROM stdin;
202	Construcciones Martínez S.L.	info@construccionesmartinez.es	963 412 870	Construcciones Martínez S.L.	active	empresa,construcción,alto-valor	Cliente recurrente. Obras en Valencia y Alicante.	24500	2026-04-01 12:56:10.80667	10	\N
203	Clínica Dental Peñalver	admin@clinicapenalver.com	91 554 2301	Clínica Dental Peñalver	active	salud,clínica,profesional	Interesados en módulo de citas y recordatorios.	8900	2026-04-16 12:56:10.80667	10	\N
204	Restaurante El Rincón de Pepe	pepe@elrincondepepe.es	955 234 100	El Rincón de Pepe	lead	hostelería,restaurante,local	Primer contacto por WhatsApp. Pendiente propuesta.	3200	2026-06-01 12:56:10.80667	10	\N
205	Academia de Idiomas Berlín	direccion@academiaberlín.com	93 667 4412	Academia Berlín S.L.	active	educación,idiomas,academia	Contrato anual renovado. Muy satisfechos.	6400	2026-05-01 12:56:10.80667	10	\N
206	Fontanería García e Hijos	fontaneria.garcia@gmail.com	687 334 921	García Fontanería	lead	fontanería,autónomo,local	Referido por Construcciones Martínez. Llamar esta semana.	1800	2026-06-08 12:56:10.80667	10	\N
207	Peluquería Estilo Moderno	hola@estilomoderno.es	671 008 445	Estilo Moderno	lead	belleza,peluquería,local	Quiere presupuesto para gestión de citas online.	2100	2026-06-10 12:56:10.80667	10	\N
208	Transportes Rápidos Valencia	operaciones@transportesrv.com	961 885 320	Transportes Rápidos Valencia	inactive	logística,transporte,empresa	Contrato pausado. Retomar contacto en septiembre.	15000	2026-02-15 12:56:10.80667	10	\N
209	Inmobiliaria Costa Blanca	ventas@costablancainmuebles.com	966 734 210	Costa Blanca Inmuebles S.L.	active	inmobiliaria,empresa,alto-valor	CRM para gestión de leads de compra/venta.	19200	2026-05-16 12:56:10.80667	10	\N
\.


--
-- Data for Name: import_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.import_jobs (id, org_id, user_clerk_id, status, file_name, file_type, detected_type, confidence_pct, raw_text, extracted_data, suggested_dest, duplicates_found, records_created, errors, created_at) FROM stdin;
\.


--
-- Data for Name: integration_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_events (id, org_id, integration_slug, direction, event_type, status, summary, error_message, created_at, payload_json) FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integrations (id, slug, name, category, auth_type, description, icon_slug, plan_required, is_active, sort_order) FROM stdin;
1	whatsapp	WhatsApp Business	communication	api_key	Recibe y envía mensajes automáticamente. Activa la aceptación de presupuestos vía WhatsApp.	MessageCircle	free	t	0
2	stripe	Stripe	payments	api_key	Procesa pagos y rastrea cobros automáticamente cuando se aceptan presupuestos.	CreditCard	pro	t	1
3	webhook_outbound	Webhooks Salientes	automation	webhook	Envía eventos del CRM a cualquier URL. Conecta con Zapier, Make o tu sistema propio.	Globe	free	t	2
4	gmail	Gmail	communication	oauth2	Envía emails directamente desde el CRM usando tu cuenta de Gmail.	Mail	pro	t	3
5	google_calendar	Google Calendar	calendar	oauth2	Sincroniza citas del CRM con tu Google Calendar en tiempo real.	CalendarDays	pro	t	4
6	slack	Slack	automation	oauth2	Recibe notificaciones cuando se aceptan presupuestos o se añaden nuevos clientes.	Hash	pro	t	5
31	telegram	Telegram Bot	communication	api_key	Envía notificaciones y mensajes a clientes vía Telegram usando tu propio bot.	Send	free	t	6
\.


--
-- Data for Name: license_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.license_plans (id, org_id, plan, seats, valid_from, valid_until, is_active, billing_cycle, notes, assigned_by, created_at, updated_at) FROM stdin;
2	10	professional	10	2026-03-17 12:56:10.80667	\N	t	monthly	Plan demo para presentaciones comerciales	system	2026-06-15 12:56:10.80667	2026-06-15 12:56:10.80667
3	20	starter	5	2026-06-15 12:57:10.271339	\N	t	monthly	Workspace limpio para primeros clientes reales	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
\.


--
-- Data for Name: memory_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.memory_history (id, memory_id, org_id, action, prev_title, new_title, prev_val, new_val, source, changed_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, client_id, content, direction, is_ai, status, created_at, org_id) FROM stdin;
30	204	Hola! Vi vuestra web y me interesa saber más sobre el CRM para mi restaurante. Tengo 3 locales.	inbound	f	read	2026-06-07 22:36:18.48976	10
31	204	¡Hola Pepe! Encantados. Tenemos un módulo específico para hostelería. ¿Cuándo tienes 30 minutos para una demo?	outbound	f	sent	2026-06-07 21:53:18.48976	10
32	204	Perfecto! El viernes que viene a las 11h me va bien.	inbound	f	read	2026-06-07 21:13:18.48976	10
33	202	Buenos días. ¿Ya está lista la propuesta del e-Commerce? Tenemos presión del equipo comercial.	inbound	f	read	2026-06-13 03:48:18.48976	10
34	202	Buenos días Roberto! Sí, el presupuesto ya está. Te lo enviamos hoy por la tarde. ¿Prefieres que lo repasemos juntos en llamada?	outbound	f	sent	2026-06-13 03:23:18.48976	10
35	206	Hola! Soy de Peluquería Estilo Moderno. Me pasaron vuestro contacto. Necesitamos sistema para que los clientes reserven cita online.	inbound	f	read	2026-06-10 01:58:18.48976	10
\.


--
-- Data for Name: module_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.module_configs (id, org_id, module_slug, is_enabled, config, updated_by, created_at, updated_at) FROM stdin;
1	20	crm	t	{"maxClients": 100}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
2	20	quotes	t	{"taxRate": 21, "currency": "EUR"}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
3	20	calendar	t	{"reminderHours": 24}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
4	20	whatsapp	f	{"demoMode": false}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
5	20	ai_chat	t	{"model": "gpt-4o-mini"}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
6	20	import_ai	t	{}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
7	10	crm	t	{"maxClients": 500}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
8	10	quotes	t	{"taxRate": 21, "currency": "EUR"}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
9	10	calendar	t	{"reminderHours": 24}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
10	10	whatsapp	t	{"demoMode": true}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
11	10	ai_chat	t	{"model": "gpt-4o-mini"}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
12	10	import_ai	t	{}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
\.


--
-- Data for Name: org_integrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_integrations (id, org_id, integration_slug, status, config, credentials_enc, display_name, external_id, last_synced_at, expires_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: org_invitations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_invitations (id, org_id, invited_by, email, role, token, expires_at, accepted_at, created_at) FROM stdin;
\.


--
-- Data for Name: org_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_members (id, org_id, user_id, role, joined_at, is_suspended) FROM stdin;
8	10	4	owner	2026-06-15 12:56:10.80667	f
9	10	6	owner	2026-06-15 12:56:10.80667	f
10	20	4	owner	2026-06-15 12:57:10.271339	f
11	20	6	owner	2026-06-15 12:57:10.271339	f
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (id, name, slug, plan, logo_url, created_at, status) FROM stdin;
10	OmniTech Demo	omnitech-demo	professional	\N	2026-03-17 12:56:10.80667	active
20	Piloto Clientes	piloto-clientes	starter	\N	2026-06-15 12:57:10.271339	active
\.


--
-- Data for Name: platform_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_roles (id, clerk_user_id, role, display_name, email, granted_by, is_active, notes, created_at, updated_at) FROM stdin;
1	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	SUPER_ADMIN	A3 Servicio	a3servicio@gmail.com	system	t	\N	2026-06-14 03:00:29.723995	2026-06-14 03:00:29.723995
2	user_3F2in1cpKPN0a8yR8iRfeK9YZOd	SUPER_ADMIN	OmniTech Core	omnitechcore01@gmail.com	system	t	\N	2026-06-14 03:00:29.723995	2026-06-14 03:00:29.723995
\.


--
-- Data for Name: quote_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quote_items (id, quote_id, description, quantity, unit_price, total, order_index) FROM stdin;
30	15	Hosting servidor VPS dedicado	12	29.99	359.88	0
31	15	Mantenimiento y actualizaciones mensuales	12	45	540	0
32	15	Soporte técnico prioritario (4h/mes)	12	8.34	100.08	0
33	16	Gestión SEO mensual	3	450	1350	0
34	16	Gestión SEM (Google Ads)	3	380	1140	0
35	16	Community management RRSS	3	134.19	402.56	0
36	17	Análisis y diseño arquitectura	1	1200	1200	0
37	17	Desarrollo frontend + backend	1	3800	3800	0
38	17	Integración ERP Sage 50	1	1611.57	1611.57	0
39	18	Diseño logotipo (3 propuestas)	1	250	250	0
40	18	Manual de identidad corporativa	1	180	180	0
41	18	Papelería corporativa (tarjeta, hoja membrete)	1	107.19	107.19	0
42	19	Sesión análisis de procesos (4h)	1	480	480	0
43	19	Configuración y parametrización CRM	1	650	650	0
44	19	Formación equipo comercial (2 sesiones)	2	344.09	688.18	0
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotes (id, org_id, client_id, title, status, currency, subtotal, tax_rate, tax_amount, total, notes, valid_until, created_at, updated_at) FROM stdin;
15	10	202	Mantenimiento Web Corporativa — Plan Anual	sent	EUR	1000	21	210	1210	Incluye hosting, actualizaciones y soporte técnico mensual.	2026-06-30 12:58:18.48976	2026-06-10 12:58:18.48976	2026-06-15 12:58:18.48976
16	10	203	Campaña Marketing Digital — Q3 2026	accepted	EUR	2892.56	21	607.44	3500	SEO, SEM y gestión de redes sociales. Duración 3 meses.	2026-07-15 12:58:18.48976	2026-05-26 12:58:18.48976	2026-06-15 12:58:18.48976
17	10	202	Desarrollo e-Commerce B2B con Integración ERP	draft	EUR	6611.57	21	1388.43	8000	Portal de pedidos para clientes industriales. Integración con Sage 50.	2026-07-30 12:58:18.48976	2026-06-13 12:58:18.48976	2026-06-15 12:58:18.48976
18	10	205	Diseño de Identidad Corporativa Completa	sent	EUR	537.19	21	112.81	650	Logo, manual de marca, tarjetas y papelería corporativa.	2026-06-25 12:58:18.48976	2026-06-07 12:58:18.48976	2026-06-15 12:58:18.48976
19	10	209	Consultoría Estratégica CRM — Plan de Implantación	accepted	EUR	1818.18	21	381.82	2200	Análisis, configuración y formación. 4 sesiones presenciales.	2026-07-05 12:58:18.48976	2026-05-31 12:58:18.48976	2026-06-15 12:58:18.48976
\.


--
-- Data for Name: role_catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_catalog (role, scope, description, priority, created_at) FROM stdin;
SUPER_ADMIN	platform	Acceso total a la plataforma OmniTech	100	2026-06-14 03:34:25.28287
STAFF_OMNITECH	platform	Personal interno de OmniTech	90	2026-06-14 03:34:25.28287
owner	org	Propietario de la organización	80	2026-06-14 03:34:25.28287
admin	org	Administrador de la organización	70	2026-06-14 03:34:25.28287
member	org	Miembro estándar de la organización	60	2026-06-14 03:34:25.28287
read_only	org	Acceso de solo lectura	50	2026-06-14 03:34:25.28287
CLIENT	client	Usuario cliente externo (sin acceso al CRM)	10	2026-06-14 03:34:25.28287
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, clerk_id, email, name, avatar_url, created_at, status, suspended_reason, suspended_at) FROM stdin;
6	user_3F2in1cpKPN0a8yR8iRfeK9YZOd	omnitechcore01@gmail.com	\N	https://img.clerk.com/eyJ0eXBlIjoiZGVmYXVsdCIsImlpZCI6Imluc18zRXpoclBzWWNmN3E5RmhYMWE2c1QzR0VOakkiLCJyaWQiOiJ1c2VyXzNGMmluMWNwS1BOMGE4eVI4aVJmZUs5WVpPZCJ9	2026-06-12 15:55:29.920529	active	\N	\N
7	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	Javilisto123 123	https://img.clerk.com/eyJ0eXBlIjoicHJveHkiLCJzcmMiOiJodHRwczovL2ltYWdlcy5jbGVyay5kZXYvb2F1dGhfZ29vZ2xlL2ltZ18zRjBRWFZ0VkIwUWkwekZadzVFREhyQUdXVHEifQ	2026-06-15 14:37:20.230219	active	\N	\N
4	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	a3servicios servicios	https://img.clerk.com/eyJ0eXBlIjoicHJveHkiLCJzcmMiOiJodHRwczovL2ltYWdlcy5jbGVyay5kZXYvb2F1dGhfZ29vZ2xlL2ltZ18zRjBRUTZldjNoN1hidDc0ajVLeDBuVWlJUWgifQ	2026-06-11 20:24:48.772775	active	\N	\N
\.


--
-- Name: activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_id_seq', 100, true);


--
-- Name: agent_memory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agent_memory_id_seq', 57, true);


--
-- Name: ai_budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_budgets_id_seq', 2, true);


--
-- Name: ai_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_messages_id_seq', 244, true);


--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_usage_logs_id_seq', 6, true);


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_id_seq', 40, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 31, true);


--
-- Name: backup_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_jobs_id_seq', 15, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_id_seq', 209, true);


--
-- Name: import_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.import_jobs_id_seq', 4, true);


--
-- Name: integration_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.integration_events_id_seq', 25, true);


--
-- Name: integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.integrations_id_seq', 388, true);


--
-- Name: license_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.license_plans_id_seq', 3, true);


--
-- Name: memory_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.memory_history_id_seq', 7, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 35, true);


--
-- Name: module_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.module_configs_id_seq', 12, true);


--
-- Name: org_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_integrations_id_seq', 4, true);


--
-- Name: org_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_invitations_id_seq', 3, true);


--
-- Name: org_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_members_id_seq', 11, true);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_id_seq', 7, true);


--
-- Name: platform_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.platform_roles_id_seq', 2, true);


--
-- Name: quote_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quote_items_id_seq', 44, true);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotes_id_seq', 19, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: activity activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id);


--
-- Name: agent_memory agent_memory_org_id_agent_slug_memory_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_org_id_agent_slug_memory_key_unique UNIQUE (org_id, agent_slug, memory_key);


--
-- Name: agent_memory agent_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_pkey PRIMARY KEY (id);


--
-- Name: ai_budgets ai_budgets_org_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_org_id_key UNIQUE (org_id);


--
-- Name: ai_budgets ai_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_pkey PRIMARY KEY (id);


--
-- Name: ai_messages ai_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_sessions ai_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: import_jobs import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_pkey PRIMARY KEY (id);


--
-- Name: integration_events integration_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events
    ADD CONSTRAINT integration_events_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_slug_unique UNIQUE (slug);


--
-- Name: license_plans license_plans_org_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_org_id_key UNIQUE (org_id);


--
-- Name: license_plans license_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_pkey PRIMARY KEY (id);


--
-- Name: memory_history memory_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history
    ADD CONSTRAINT memory_history_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: module_configs module_configs_org_id_module_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_org_id_module_slug_key UNIQUE (org_id, module_slug);


--
-- Name: module_configs module_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_pkey PRIMARY KEY (id);


--
-- Name: org_integrations org_integrations_org_id_integration_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_org_id_integration_slug_unique UNIQUE (org_id, integration_slug);


--
-- Name: org_integrations org_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_pkey PRIMARY KEY (id);


--
-- Name: org_invitations org_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_pkey PRIMARY KEY (id);


--
-- Name: org_invitations org_invitations_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_token_unique UNIQUE (token);


--
-- Name: org_members org_members_org_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_user_id_unique UNIQUE (org_id, user_id);


--
-- Name: org_members org_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_slug_unique UNIQUE (slug);


--
-- Name: platform_roles platform_roles_clerk_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles
    ADD CONSTRAINT platform_roles_clerk_user_id_key UNIQUE (clerk_user_id);


--
-- Name: platform_roles platform_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles
    ADD CONSTRAINT platform_roles_pkey PRIMARY KEY (id);


--
-- Name: quote_items quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: role_catalog role_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_catalog
    ADD CONSTRAINT role_catalog_pkey PRIMARY KEY (role);


--
-- Name: users users_clerk_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_clerk_id_unique UNIQUE (clerk_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_usage_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_usage_created ON public.ai_usage_logs USING btree (created_at DESC);


--
-- Name: idx_ai_usage_org_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_usage_org_created ON public.ai_usage_logs USING btree (org_id, created_at DESC);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_actor ON public.audit_logs USING btree (actor_clerk_id);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_org ON public.audit_logs USING btree (org_id);


--
-- Name: idx_import_jobs_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_import_jobs_org ON public.import_jobs USING btree (org_id, created_at DESC);


--
-- Name: activity activity_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: agent_memory agent_memory_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_budgets ai_budgets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_messages ai_messages_session_id_ai_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_session_id_ai_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.ai_sessions(id) ON DELETE CASCADE;


--
-- Name: ai_sessions ai_sessions_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_sessions ai_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: clients clients_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: import_jobs import_jobs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: integration_events integration_events_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events
    ADD CONSTRAINT integration_events_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: license_plans license_plans_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: memory_history memory_history_memory_id_agent_memory_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history
    ADD CONSTRAINT memory_history_memory_id_agent_memory_id_fk FOREIGN KEY (memory_id) REFERENCES public.agent_memory(id) ON DELETE CASCADE;


--
-- Name: messages messages_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: messages messages_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: module_configs module_configs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_integrations org_integrations_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_invitations org_invitations_invited_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_invited_by_users_id_fk FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: org_invitations org_invitations_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quote_items quote_items_quote_id_quotes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_quote_id_quotes_id_fk FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict wOl0Fm1yH94P9QXadvjmVL3qFjydmwD5XlbJF61PVQe3P1OPiPjIOc61a5s8svv

