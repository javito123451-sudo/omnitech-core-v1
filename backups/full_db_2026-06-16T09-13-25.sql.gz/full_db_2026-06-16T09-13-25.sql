--
-- PostgreSQL database dump
--

\restrict eFWmchPtLYXyckRoLb0Hz9dlJ3HuzqjJNeTx1xYogYBrHt9xZCWR0oXRV6EljBJ

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity (
    id integer NOT NULL,
    type text NOT NULL,
    description text NOT NULL,
    client_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL,
    user_id integer
);


ALTER TABLE public.activity OWNER TO postgres;

--
-- Name: activity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_id_seq OWNER TO postgres;

--
-- Name: activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_id_seq OWNED BY public.activity.id;


--
-- Name: agent_memory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_memory (
    id integer NOT NULL,
    org_id integer NOT NULL,
    agent_slug text NOT NULL,
    memory_key text NOT NULL,
    memory_val text NOT NULL,
    source text DEFAULT 'user_input'::text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    title text,
    category text,
    tags text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.agent_memory OWNER TO postgres;

--
-- Name: agent_memory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agent_memory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_memory_id_seq OWNER TO postgres;

--
-- Name: agent_memory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agent_memory_id_seq OWNED BY public.agent_memory.id;


--
-- Name: ai_budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_budgets (
    id integer NOT NULL,
    org_id integer NOT NULL,
    monthly_budget_usd numeric(10,2) DEFAULT 10.00,
    alert_80 boolean DEFAULT true,
    alert_90 boolean DEFAULT true,
    block_at_100 boolean DEFAULT true,
    is_blocked boolean DEFAULT false,
    block_reason text,
    updated_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_budgets OWNER TO postgres;

--
-- Name: ai_budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_budgets_id_seq OWNER TO postgres;

--
-- Name: ai_budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_budgets_id_seq OWNED BY public.ai_budgets.id;


--
-- Name: ai_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_messages (
    id integer NOT NULL,
    session_id uuid NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    tokens_used integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_messages OWNER TO postgres;

--
-- Name: ai_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_messages_id_seq OWNER TO postgres;

--
-- Name: ai_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_messages_id_seq OWNED BY public.ai_messages.id;


--
-- Name: ai_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id integer NOT NULL,
    user_id integer NOT NULL,
    agent_slug text DEFAULT 'operator'::text NOT NULL,
    title text,
    client_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_sessions OWNER TO postgres;

--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_usage_logs (
    id integer NOT NULL,
    org_id integer,
    user_clerk_id text,
    function_name text NOT NULL,
    model text NOT NULL,
    tokens_input integer DEFAULT 0,
    tokens_output integer DEFAULT 0,
    tokens_total integer DEFAULT 0,
    cost_usd numeric(10,6) DEFAULT 0,
    duration_ms integer,
    status text DEFAULT 'ok'::text,
    error_msg text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_usage_logs OWNER TO postgres;

--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_usage_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_usage_logs_id_seq OWNER TO postgres;

--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_usage_logs_id_seq OWNED BY public.ai_usage_logs.id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    client_id integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    type text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    reminder boolean DEFAULT false NOT NULL,
    tags text,
    location text,
    org_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    actor_clerk_id text,
    actor_email text,
    action text NOT NULL,
    resource text,
    resource_id text,
    org_id integer,
    ip_address text,
    user_agent text,
    details jsonb,
    severity text DEFAULT 'info'::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_jobs (
    id integer NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    org_id integer,
    file_path text,
    file_name text,
    size_bytes bigint,
    checksum text,
    row_count integer,
    error text,
    triggered_by text,
    metadata jsonb,
    started_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    expires_at timestamp without time zone
);


ALTER TABLE public.backup_jobs OWNER TO postgres;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backup_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_jobs_id_seq OWNER TO postgres;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backup_jobs_id_seq OWNED BY public.backup_jobs.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    company text,
    status text DEFAULT 'lead'::text NOT NULL,
    tags text,
    notes text,
    value real,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL,
    telegram_chat_id text
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_id_seq OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: import_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.import_jobs (
    id integer NOT NULL,
    org_id integer,
    user_clerk_id text,
    status text DEFAULT 'completed'::text,
    file_name text,
    file_type text,
    detected_type text,
    confidence_pct integer DEFAULT 0,
    raw_text text,
    extracted_data jsonb,
    suggested_dest text,
    duplicates_found jsonb,
    records_created integer DEFAULT 0,
    errors text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.import_jobs OWNER TO postgres;

--
-- Name: import_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.import_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.import_jobs_id_seq OWNER TO postgres;

--
-- Name: import_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.import_jobs_id_seq OWNED BY public.import_jobs.id;


--
-- Name: integration_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_events (
    id integer NOT NULL,
    org_id integer NOT NULL,
    integration_slug text NOT NULL,
    direction text DEFAULT 'inbound'::text NOT NULL,
    event_type text NOT NULL,
    status text DEFAULT 'processed'::text NOT NULL,
    summary text,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    payload_json text
);


ALTER TABLE public.integration_events OWNER TO postgres;

--
-- Name: integration_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.integration_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.integration_events_id_seq OWNER TO postgres;

--
-- Name: integration_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.integration_events_id_seq OWNED BY public.integration_events.id;


--
-- Name: integrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrations (
    id integer NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    auth_type text NOT NULL,
    description text,
    icon_slug text,
    plan_required text DEFAULT 'free'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.integrations OWNER TO postgres;

--
-- Name: integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.integrations_id_seq OWNER TO postgres;

--
-- Name: integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.integrations_id_seq OWNED BY public.integrations.id;


--
-- Name: license_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.license_plans (
    id integer NOT NULL,
    org_id integer NOT NULL,
    plan text DEFAULT 'starter'::text NOT NULL,
    seats integer DEFAULT 5,
    valid_from timestamp without time zone DEFAULT now(),
    valid_until timestamp without time zone,
    is_active boolean DEFAULT true,
    billing_cycle text DEFAULT 'monthly'::text,
    notes text,
    assigned_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.license_plans OWNER TO postgres;

--
-- Name: license_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.license_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.license_plans_id_seq OWNER TO postgres;

--
-- Name: license_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.license_plans_id_seq OWNED BY public.license_plans.id;


--
-- Name: memory_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.memory_history (
    id integer NOT NULL,
    memory_id integer NOT NULL,
    org_id integer NOT NULL,
    action text NOT NULL,
    prev_title text,
    new_title text,
    prev_val text,
    new_val text,
    source text,
    changed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.memory_history OWNER TO postgres;

--
-- Name: memory_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.memory_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.memory_history_id_seq OWNER TO postgres;

--
-- Name: memory_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.memory_history_id_seq OWNED BY public.memory_history.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    client_id integer NOT NULL,
    content text NOT NULL,
    direction text DEFAULT 'outbound'::text NOT NULL,
    is_ai boolean DEFAULT false,
    status text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    org_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: module_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.module_configs (
    id integer NOT NULL,
    org_id integer NOT NULL,
    module_slug text NOT NULL,
    is_enabled boolean DEFAULT true,
    config jsonb DEFAULT '{}'::jsonb,
    updated_by text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.module_configs OWNER TO postgres;

--
-- Name: module_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.module_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.module_configs_id_seq OWNER TO postgres;

--
-- Name: module_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.module_configs_id_seq OWNED BY public.module_configs.id;


--
-- Name: org_integrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_integrations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    integration_slug text NOT NULL,
    status text DEFAULT 'inactive'::text NOT NULL,
    config text,
    credentials_enc text,
    display_name text,
    external_id text,
    last_synced_at timestamp without time zone,
    expires_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.org_integrations OWNER TO postgres;

--
-- Name: org_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_integrations_id_seq OWNER TO postgres;

--
-- Name: org_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_integrations_id_seq OWNED BY public.org_integrations.id;


--
-- Name: org_invitations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_invitations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    invited_by integer NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    accepted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.org_invitations OWNER TO postgres;

--
-- Name: org_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_invitations_id_seq OWNER TO postgres;

--
-- Name: org_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_invitations_id_seq OWNED BY public.org_invitations.id;


--
-- Name: org_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_members (
    id integer NOT NULL,
    org_id integer NOT NULL,
    user_id integer NOT NULL,
    role text DEFAULT 'owner'::text NOT NULL,
    joined_at timestamp without time zone DEFAULT now() NOT NULL,
    is_suspended boolean DEFAULT false
);


ALTER TABLE public.org_members OWNER TO postgres;

--
-- Name: org_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_members_id_seq OWNER TO postgres;

--
-- Name: org_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_members_id_seq OWNED BY public.org_members.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    plan text DEFAULT 'free'::text NOT NULL,
    logo_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'active'::text NOT NULL
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizations_id_seq OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: platform_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_roles (
    id integer NOT NULL,
    clerk_user_id text NOT NULL,
    role text DEFAULT 'STAFF_OMNITECH'::text NOT NULL,
    display_name text,
    email text,
    granted_by text,
    is_active boolean DEFAULT true,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.platform_roles OWNER TO postgres;

--
-- Name: platform_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.platform_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.platform_roles_id_seq OWNER TO postgres;

--
-- Name: platform_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.platform_roles_id_seq OWNED BY public.platform_roles.id;


--
-- Name: quote_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quote_items (
    id integer NOT NULL,
    quote_id integer NOT NULL,
    description text NOT NULL,
    quantity real DEFAULT 1 NOT NULL,
    unit_price real DEFAULT 0 NOT NULL,
    total real DEFAULT 0 NOT NULL,
    order_index integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.quote_items OWNER TO postgres;

--
-- Name: quote_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quote_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quote_items_id_seq OWNER TO postgres;

--
-- Name: quote_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quote_items_id_seq OWNED BY public.quote_items.id;


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotes (
    id integer NOT NULL,
    org_id integer NOT NULL,
    client_id integer NOT NULL,
    title text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    subtotal real DEFAULT 0 NOT NULL,
    tax_rate real DEFAULT 21 NOT NULL,
    tax_amount real DEFAULT 0 NOT NULL,
    total real DEFAULT 0 NOT NULL,
    notes text,
    valid_until timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quotes OWNER TO postgres;

--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotes_id_seq OWNER TO postgres;

--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- Name: role_catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_catalog (
    role text NOT NULL,
    scope text NOT NULL,
    description text,
    priority integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.role_catalog OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    clerk_id text NOT NULL,
    email text NOT NULL,
    name text,
    avatar_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    suspended_reason text,
    suspended_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity ALTER COLUMN id SET DEFAULT nextval('public.activity_id_seq'::regclass);


--
-- Name: agent_memory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory ALTER COLUMN id SET DEFAULT nextval('public.agent_memory_id_seq'::regclass);


--
-- Name: ai_budgets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets ALTER COLUMN id SET DEFAULT nextval('public.ai_budgets_id_seq'::regclass);


--
-- Name: ai_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages ALTER COLUMN id SET DEFAULT nextval('public.ai_messages_id_seq'::regclass);


--
-- Name: ai_usage_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_usage_logs_id_seq'::regclass);


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backup_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_jobs ALTER COLUMN id SET DEFAULT nextval('public.backup_jobs_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: import_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs ALTER COLUMN id SET DEFAULT nextval('public.import_jobs_id_seq'::regclass);


--
-- Name: integration_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events ALTER COLUMN id SET DEFAULT nextval('public.integration_events_id_seq'::regclass);


--
-- Name: integrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations ALTER COLUMN id SET DEFAULT nextval('public.integrations_id_seq'::regclass);


--
-- Name: license_plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans ALTER COLUMN id SET DEFAULT nextval('public.license_plans_id_seq'::regclass);


--
-- Name: memory_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history ALTER COLUMN id SET DEFAULT nextval('public.memory_history_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: module_configs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs ALTER COLUMN id SET DEFAULT nextval('public.module_configs_id_seq'::regclass);


--
-- Name: org_integrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations ALTER COLUMN id SET DEFAULT nextval('public.org_integrations_id_seq'::regclass);


--
-- Name: org_invitations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations ALTER COLUMN id SET DEFAULT nextval('public.org_invitations_id_seq'::regclass);


--
-- Name: org_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members ALTER COLUMN id SET DEFAULT nextval('public.org_members_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: platform_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles ALTER COLUMN id SET DEFAULT nextval('public.platform_roles_id_seq'::regclass);


--
-- Name: quote_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items ALTER COLUMN id SET DEFAULT nextval('public.quote_items_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity (id, type, description, client_name, created_at, org_id, user_id) FROM stdin;
93	quote_accepted	Presupuesto aceptado: Campaña Marketing Digital Q3 2026	Clínica Dental Peñalver	2026-05-26 12:58:18.48976	10	\N
94	quote_accepted	Presupuesto aceptado: Consultoría Estratégica CRM	Inmobiliaria Costa Blanca	2026-05-31 12:58:18.48976	10	\N
95	client_created	Nuevo lead registrado desde WhatsApp	Fontanería García e Hijos	2026-06-08 12:58:18.48976	10	\N
96	message_received	Mensaje recibido: consulta sobre CRM para hostelería	Restaurante El Rincón de Pepe	2026-06-08 12:58:18.48976	10	\N
97	appointment_set	Cita agendada: Demo CRM para restaurante	Restaurante El Rincón de Pepe	2026-06-14 12:58:18.48976	10	\N
98	client_created	Nuevo lead: interés en módulo de citas online	Peluquería Estilo Moderno	2026-06-10 12:58:18.48976	10	\N
99	quote_sent	Presupuesto enviado: Mantenimiento Web Plan Anual	Construcciones Martínez S.L.	2026-06-10 12:58:18.48976	10	\N
100	appointment_set	Reunión de seguimiento confirmada — mañana 10h	Construcciones Martínez S.L.	2026-06-12 12:58:18.48976	10	\N
101	client_added	[Omni Import AI] Cliente 1 (Empresa 1)	\N	2026-06-15 14:45:09.802158	8	\N
102	client_added	[Omni Import AI] Cliente 2 (Empresa 2)	\N	2026-06-15 14:45:09.841919	8	\N
103	client_added	[Omni Import AI] Cliente 3 (Empresa 3)	\N	2026-06-15 14:45:09.862771	8	\N
104	client_added	[Omni Import AI] Cliente 4 (Empresa 4)	\N	2026-06-15 14:45:09.920503	8	\N
105	client_added	[Omni Import AI] Cliente 5 (Empresa 5)	\N	2026-06-15 14:45:09.929981	8	\N
106	client_added	[Omni Import AI] Cliente 6 (Empresa 6)	\N	2026-06-15 14:45:09.947678	8	\N
107	client_added	[Omni Import AI] Cliente 7 (Empresa 7)	\N	2026-06-15 14:45:09.967857	8	\N
108	client_added	[Omni Import AI] Cliente 8 (Empresa 8)	\N	2026-06-15 14:45:10.001711	8	\N
109	client_added	[Omni Import AI] Cliente 9 (Empresa 9)	\N	2026-06-15 14:45:10.028063	8	\N
110	client_added	[Omni Import AI] Cliente 10 (Empresa 10)	\N	2026-06-15 14:45:10.055612	8	\N
111	client_added	[Omni Import AI] Cliente 11 (Empresa 11)	\N	2026-06-15 14:45:10.090005	8	\N
112	client_added	[Omni Import AI] Cliente 12 (Empresa 12)	\N	2026-06-15 14:45:10.145147	8	\N
113	client_added	[Omni Import AI] Cliente 13 (Empresa 13)	\N	2026-06-15 14:45:10.170714	8	\N
114	client_added	[Omni Import AI] Cliente 14 (Empresa 14)	\N	2026-06-15 14:45:10.212827	8	\N
115	client_added	[Omni Import AI] Cliente 15 (Empresa 15)	\N	2026-06-15 14:45:10.223899	8	\N
116	client_added	[Omni Import AI] Cliente 16 (Empresa 16)	\N	2026-06-15 14:45:10.241139	8	\N
117	client_added	[Omni Import AI] Cliente 17 (Empresa 17)	\N	2026-06-15 14:45:10.24849	8	\N
118	client_added	[Omni Import AI] Cliente 18 (Empresa 18)	\N	2026-06-15 14:45:10.27235	8	\N
119	client_added	[Omni Import AI] Cliente 19 (Empresa 19)	\N	2026-06-15 14:45:10.300192	8	\N
120	client_added	[Omni Import AI] Cliente 20 (Empresa 20)	\N	2026-06-15 14:45:10.339924	8	\N
121	quote_created	Presupuesto "Propuesta de Automatización de WhatsApp para Cliente 20" creado para Cliente 20 — 3025,00 €	Cliente 20	2026-06-15 14:47:08.603355	8	7
\.


--
-- Data for Name: agent_memory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_memory (id, org_id, agent_slug, memory_key, memory_val, source, updated_at, title, category, tags, created_at) FROM stdin;
\.


--
-- Data for Name: ai_budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_budgets (id, org_id, monthly_budget_usd, alert_80, alert_90, block_at_100, is_blocked, block_reason, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_messages (id, session_id, role, content, tokens_used, created_at) FROM stdin;
\.


--
-- Data for Name: ai_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_sessions (id, org_id, user_id, agent_slug, title, client_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_usage_logs (id, org_id, user_clerk_id, function_name, model, tokens_input, tokens_output, tokens_total, cost_usd, duration_ms, status, error_msg, metadata, created_at) FROM stdin;
7	8	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	import_ai_analysis	gpt-4o	1547	204	1751	0.010795	3425	ok	\N	\N	2026-06-15 14:42:10.237815
8	8	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	import_ai_analysis	gpt-4o	719	1921	2640	0.032410	13557	ok	\N	\N	2026-06-15 14:44:25.612386
9	8	\N	executive_ceo	gpt-4o-mini	878	477	1355	0.000418	\N	ok	\N	\N	2026-06-15 14:49:24.226377
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (id, title, description, start_time, end_time, client_id, status, type, created_at, reminder, tags, location, org_id) FROM stdin;
33	Seguimiento proyecto e-Commerce	Revisión avance módulos y planificación siguiente sprint.	2026-06-16 22:58:18.48976	2026-06-16 23:58:18.48976	202	confirmed	meeting	2026-06-12 12:58:18.48976	t	\N	Av. del Puerto 32, Valencia	10
34	Resultados campaña marketing Q2	Dashboard de métricas y propuesta Q3.	2026-06-18 04:58:18.48976	2026-06-18 05:58:18.48976	203	confirmed	call	2026-06-10 12:58:18.48976	t	\N	Videollamada Google Meet	10
35	Consultoría CRM: Análisis de procesos	Mapeo de flujos comerciales actuales y pain points.	2026-06-18 21:58:18.48976	2026-06-18 23:58:18.48976	209	confirmed	meeting	2026-06-13 12:58:18.48976	t	\N	Calle Mayor 15, Madrid	10
36	Entrega identidad corporativa	Presentación propuestas de logo. Cliente revisa y aprueba.	2026-06-20 00:58:18.48976	2026-06-20 01:58:18.48976	205	pending	call	2026-06-14 12:58:18.48976	f	\N	Videollamada Zoom	10
37	Demo OmniTech CRM — Restaurante	Demostración módulo gestión de clientes y reservas.	2026-06-20 23:58:18.48976	2026-06-21 00:58:18.48976	204	pending	demo	2026-06-15 12:58:18.48976	f	\N	Plaza Mayor 7, Sevilla	10
38	Propuesta gestión citas peluquería	Explicación módulo calendario y reservas online.	2026-06-22 22:58:18.48976	2026-06-22 23:28:18.48976	206	pending	call	2026-06-15 12:58:18.48976	f	\N	Videollamada WhatsApp	10
39	Consultoría CRM: Configuración inicial	Configuración CRM, importación de datos y flujos automatizados.	2026-06-25 21:58:18.48976	2026-06-25 23:58:18.48976	209	confirmed	meeting	2026-06-14 12:58:18.48976	t	\N	Calle Mayor 15, Madrid	10
40	Kick-off campaña Q3 — Planning	Calendario editorial y distribución presupuesto Ads.	2026-06-28 03:58:18.48976	2026-06-28 04:58:18.48976	203	pending	meeting	2026-06-15 12:58:18.48976	f	\N	Videollamada Google Meet	10
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, actor_clerk_id, actor_email, action, resource, resource_id, org_id, ip_address, user_agent, details, severity, created_at) FROM stdin;
18	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	7	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "Omnitech venta", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-15 11:42:55.740574
19	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	7	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "Omnitech venta", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-15 11:42:55.741882
20	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_login	session	\N	7	192.168.1.10	\N	{"result": "success", "userName": "Juan García"}	info	2026-06-15 12:25:33.153457
21	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_logout	session	\N	7	192.168.1.10	\N	{"result": "success", "userName": "Juan García"}	info	2026-06-15 12:25:33.153457
22	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_created	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "email": "info@modelo.es", "result": "success", "status": "lead"}	info	2026-06-15 12:25:33.153457
23	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_updated	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "result": "success", "changes": ["phone", "status"]}	info	2026-06-15 12:25:33.153457
24	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	client_deleted	client	42	7	192.168.1.10	\N	{"name": "Empresa Modelo S.L.", "email": "info@modelo.es", "result": "success"}	warning	2026-06-15 12:25:33.153457
25	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	import_completed	import	\N	7	192.168.1.10	\N	{"errors": 0, "result": "success", "created": 47, "updated": 3, "fileName": "clientes_mayo.xlsx"}	info	2026-06-15 12:25:33.153457
26	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	integration_connected	integration	whatsapp	7	192.168.1.10	\N	{"slug": "whatsapp", "result": "success"}	info	2026-06-15 12:25:33.153457
27	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	integration_disconnected	integration	whatsapp	7	192.168.1.10	\N	{"slug": "whatsapp", "result": "success"}	warning	2026-06-15 12:25:33.153457
28	system:whatsapp:7	\N	whatsapp_message_received	whatsapp_message	wamid.test001	7	\N	\N	{"text": "Acepto el presupuesto", "phone": "611234567", "result": "success", "clientName": "Pedro López"}	info	2026-06-15 12:25:33.153457
29	system:whatsapp:7	\N	whatsapp_quote_accepted	quote	15	7	\N	\N	{"result": "accepted", "clientName": "Pedro López", "quoteTitle": "Mantenimiento Anual"}	info	2026-06-15 12:25:33.153457
30	system:whatsapp:7	\N	whatsapp_quote_rejected	quote	16	7	\N	\N	{"result": "rejected", "clientName": "Ana Martínez", "quoteTitle": "Instalación Premium"}	info	2026-06-15 12:25:33.153457
31	user_3ExXLGMKxDArT1bBizVRyyNkH9N	admin@omnitech.com	workspace_suspended	workspace	5	\N	10.0.0.1	\N	{"reason": "Pago pendiente", "result": "success"}	warning	2026-06-15 12:25:33.153457
32	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	\N	import_completed	import	\N	8	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"total": 20, "errors": 0, "result": "success", "created": 20, "skipped": 0, "updated": 0}	info	2026-06-15 14:45:10.339917
33	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "userName": "a3servicios servicios"}	info	2026-06-15 14:57:45.343305
34	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_login	session	\N	8	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "Demos", "orgRole": "owner", "userName": "Javilisto123 123"}	info	2026-06-16 07:04:15.596168
35	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	user_login	session	\N	10	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "orgName": "OmniTech Demo", "orgRole": "owner", "userName": "a3servicios servicios"}	info	2026-06-16 07:04:34.156061
36	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	\N	integration_connected	integration	whatsapp	10	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"name": "WhatsApp Business", "slug": "whatsapp", "result": "success", "displayName": null, "hasCredentials": true}	info	2026-06-16 07:12:22.336582
37	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "userName": "Javilisto123 123"}	info	2026-06-16 09:07:11.131973
38	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	user_logout	session	\N	\N	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"result": "success", "userName": "Javilisto123 123"}	info	2026-06-16 09:07:40.77428
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_jobs (id, type, status, org_id, file_path, file_name, size_bytes, checksum, row_count, error, triggered_by, metadata, started_at, completed_at, expires_at) FROM stdin;
5	workspace	completed	7	/home/runner/workspace/backups/workspace_7_2026-06-15T12-40-10.json	workspace_7_2026-06-15T12-40-10.json	1205	c3d508a9cc90b7d8cd274596d7b84eb9056a5c786fd6ba0053c44374aedc10f6	4	\N	test:manual	{"orgId": 7}	2026-06-15 12:42:42.229026	2026-06-15 12:42:42.229026	2026-07-15 12:42:42.229026
6	config	completed	\N	/home/runner/workspace/backups/config_platform_2026-06-15T12-40-14.json	config_platform_2026-06-15T12-40-14.json	2672	a6c53f51ebab5c39b6c2c00e30b4244cc62e504e6a14035167d9fdb496a23e6d	12	\N	test:manual	{}	2026-06-15 12:42:44.326804	2026-06-15 12:42:44.326804	2026-07-15 12:42:44.326804
7	audit	completed	\N	/home/runner/workspace/backups/audit_platform_2026-06-15T12-40-34.json	audit_platform_2026-06-15T12-40-34.json	5510	67c35082b40bf169c703ca1d497727b4650ca0fde1377150977581237fd0a4f3	14	\N	test:manual	{"totalLogs": 14}	2026-06-15 12:42:45.081958	2026-06-15 12:42:45.081958	2026-07-15 12:42:45.081958
11	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-15T12-41-15.sql.gz	full_db_2026-06-15T12-41-15.sql.gz	9597	132088dfdb2ea80cdb811265fa281b0212731371b6c85c7183c01fa10795eae0	\N	\N	test:manual	{"lines": 2228, "tables": 26}	2026-06-15 12:43:34.332691	2026-06-15 12:43:34.332691	2026-07-15 12:43:34.332691
12	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-15T12-45-35.sql.gz	full_db_2026-06-15T12-45-35.sql.gz	10056	81858cd91083e8472850c3b9448e6580d7f68739d5ee1044416106d68ace30f1	\N	\N	auto:scheduler	\N	2026-06-15 12:45:35.206557	2026-06-15 12:45:36.274	2026-07-15 12:45:35.163
13	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-15 12:45:36.344582	2026-06-15 12:45:36.42	2026-07-15 12:45:36.343
14	full_db	completed	\N	/home/runner/workspace/backups/pre_launch_backup_2026-06-15T12-54-21.sql.gz	pre_launch_backup_2026-06-15T12-54-21.sql.gz	10184	3e650f5ce78cba09f14239e72e21bc275551b512fa2f1b0f51e751f3b5ff63a6	\N	\N	system:pre_launch	{"reason": "pre-launch cleanup backup"}	2026-06-15 12:54:22.530745	2026-06-15 12:54:22.530745	2026-09-13 12:54:22.530745
15	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-15T14-38-15.sql.gz	full_db_2026-06-15T14-38-15.sql.gz	12038	99c578e3d63a70afd1b450d792f4a4e7b32391693389eac27e8d3f5a723d5899	\N	\N	auto:scheduler	\N	2026-06-15 14:38:15.604663	2026-06-15 14:38:17.959	2026-07-15 14:38:15.602
16	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-15 14:38:18.06243	2026-06-15 14:38:18.25	2026-07-15 14:38:18.061
17	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T07-04-09.sql.gz	full_db_2026-06-16T07-04-09.sql.gz	18561	1ab21accaa49e79834964a4a237d52f51d24a8cffbb4a23cc305c03514aaa8fb	\N	\N	auto:scheduler	\N	2026-06-16 07:04:09.553833	2026-06-16 07:04:11.66	2026-07-16 07:04:09.437
18	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 07:04:11.698879	2026-06-16 07:04:11.932	2026-07-16 07:04:11.696
19	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T07-21-41.sql.gz	full_db_2026-06-16T07-21-41.sql.gz	18951	9388c23b46c309c4f6c248fafce39411497e65ec4a1123a3ffba74cbe7f3cc90	\N	\N	auto:scheduler	\N	2026-06-16 07:21:41.659997	2026-06-16 07:21:42.453	2026-07-16 07:21:41.447
20	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 07:21:42.461017	2026-06-16 07:21:42.498	2026-07-16 07:21:42.46
21	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T08-14-21.sql.gz	full_db_2026-06-16T08-14-21.sql.gz	19048	b3530459d25e223b2f34b971c91fc6b1e12060adf098c50bf8b9cf89eeb1dbd4	\N	\N	auto:scheduler	\N	2026-06-16 08:14:21.609585	2026-06-16 08:14:22.335	2026-07-16 08:14:21.44
22	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 08:14:22.343009	2026-06-16 08:14:22.39	2026-07-16 08:14:22.342
23	full_db	completed	\N	/home/runner/workspace/backups/full_db_2026-06-16T09-05-10.sql.gz	full_db_2026-06-16T09-05-10.sql.gz	19140	5312db359d3108a62a9f4cb3d08963ae9bdc1b2c6a24aa941aae9d4e3d6cb02a	\N	\N	auto:scheduler	\N	2026-06-16 09:05:10.247245	2026-06-16 09:05:11.375	2026-07-16 09:05:09.334
24	config	failed	\N	\N	\N	\N	\N	\N	Error: Failed query: SELECT id, org_id, integration_id, is_active, credentials_enc, created_at FROM org_integrations\nparams: 	auto:scheduler	\N	2026-06-16 09:05:11.403153	2026-06-16 09:05:11.437	2026-07-16 09:05:11.402
25	full_db	running	\N	\N	\N	\N	\N	\N	\N	auto:scheduler	\N	2026-06-16 09:13:25.697565	\N	2026-07-16 09:13:25.676
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, name, email, phone, company, status, tags, notes, value, created_at, org_id, telegram_chat_id) FROM stdin;
202	Construcciones Martínez S.L.	info@construccionesmartinez.es	963 412 870	Construcciones Martínez S.L.	active	empresa,construcción,alto-valor	Cliente recurrente. Obras en Valencia y Alicante.	24500	2026-04-01 12:56:10.80667	10	\N
203	Clínica Dental Peñalver	admin@clinicapenalver.com	91 554 2301	Clínica Dental Peñalver	active	salud,clínica,profesional	Interesados en módulo de citas y recordatorios.	8900	2026-04-16 12:56:10.80667	10	\N
204	Restaurante El Rincón de Pepe	pepe@elrincondepepe.es	955 234 100	El Rincón de Pepe	lead	hostelería,restaurante,local	Primer contacto por WhatsApp. Pendiente propuesta.	3200	2026-06-01 12:56:10.80667	10	\N
205	Academia de Idiomas Berlín	direccion@academiaberlín.com	93 667 4412	Academia Berlín S.L.	active	educación,idiomas,academia	Contrato anual renovado. Muy satisfechos.	6400	2026-05-01 12:56:10.80667	10	\N
206	Fontanería García e Hijos	fontaneria.garcia@gmail.com	687 334 921	García Fontanería	lead	fontanería,autónomo,local	Referido por Construcciones Martínez. Llamar esta semana.	1800	2026-06-08 12:56:10.80667	10	\N
207	Peluquería Estilo Moderno	hola@estilomoderno.es	671 008 445	Estilo Moderno	lead	belleza,peluquería,local	Quiere presupuesto para gestión de citas online.	2100	2026-06-10 12:56:10.80667	10	\N
208	Transportes Rápidos Valencia	operaciones@transportesrv.com	961 885 320	Transportes Rápidos Valencia	inactive	logística,transporte,empresa	Contrato pausado. Retomar contacto en septiembre.	15000	2026-02-15 12:56:10.80667	10	\N
209	Inmobiliaria Costa Blanca	ventas@costablancainmuebles.com	966 734 210	Costa Blanca Inmuebles S.L.	active	inmobiliaria,empresa,alto-valor	CRM para gestión de leads de compra/venta.	19200	2026-05-16 12:56:10.80667	10	\N
210	Cliente 1	cliente1@test.com	600111001	Empresa 1	client	\N	\N	600	2026-06-15 14:45:09.647975	8	\N
211	Cliente 2	cliente2@test.com	600111002	Empresa 2	client	\N	\N	700	2026-06-15 14:45:09.83069	8	\N
212	Cliente 3	cliente3@test.com	600111003	Empresa 3	prospect	\N	\N	800	2026-06-15 14:45:09.841458	8	\N
213	Cliente 4	cliente4@test.com	600111004	Empresa 4	client	\N	\N	900	2026-06-15 14:45:09.898903	8	\N
214	Cliente 5	cliente5@test.com	600111005	Empresa 5	client	\N	\N	1000	2026-06-15 14:45:09.920682	8	\N
215	Cliente 6	cliente6@test.com	600111006	Empresa 6	prospect	\N	\N	1100	2026-06-15 14:45:09.930901	8	\N
216	Cliente 7	cliente7@test.com	600111007	Empresa 7	client	\N	\N	1200	2026-06-15 14:45:09.947191	8	\N
217	Cliente 8	cliente8@test.com	600111008	Empresa 8	client	\N	\N	1300	2026-06-15 14:45:09.967138	8	\N
218	Cliente 9	cliente9@test.com	600111009	Empresa 9	prospect	\N	\N	1400	2026-06-15 14:45:10.001681	8	\N
219	Cliente 10	cliente10@test.com	600111010	Empresa 10	client	\N	\N	1500	2026-06-15 14:45:10.028046	8	\N
220	Cliente 11	cliente11@test.com	600111011	Empresa 11	client	\N	\N	1600	2026-06-15 14:45:10.054994	8	\N
221	Cliente 12	cliente12@test.com	600111012	Empresa 12	prospect	\N	\N	1700	2026-06-15 14:45:10.089701	8	\N
222	Cliente 13	cliente13@test.com	600111013	Empresa 13	client	\N	\N	1800	2026-06-15 14:45:10.142841	8	\N
223	Cliente 14	cliente14@test.com	600111014	Empresa 14	client	\N	\N	1900	2026-06-15 14:45:10.171837	8	\N
224	Cliente 15	cliente15@test.com	600111015	Empresa 15	prospect	\N	\N	2000	2026-06-15 14:45:10.211925	8	\N
225	Cliente 16	cliente16@test.com	600111016	Empresa 16	client	\N	\N	2100	2026-06-15 14:45:10.22344	8	\N
226	Cliente 17	cliente17@test.com	600111017	Empresa 17	client	\N	\N	2200	2026-06-15 14:45:10.241927	8	\N
227	Cliente 18	cliente18@test.com	600111018	Empresa 18	prospect	\N	\N	2300	2026-06-15 14:45:10.248395	8	\N
228	Cliente 19	cliente19@test.com	600111019	Empresa 19	client	\N	\N	2400	2026-06-15 14:45:10.272476	8	\N
229	Cliente 20	cliente20@test.com	600111020	Empresa 20	client	\N	\N	2500	2026-06-15 14:45:10.300742	8	\N
\.


--
-- Data for Name: import_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.import_jobs (id, org_id, user_clerk_id, status, file_name, file_type, detected_type, confidence_pct, raw_text, extracted_data, suggested_dest, duplicates_found, records_created, errors, created_at) FROM stdin;
5	8	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	completed	OmniTech_Import_100_Clientes.xlsx	xlsx	contact_list	95	[\n  {\n    "ID": 1,\n    "Nombre": "Elena Ortega",\n    "Empresa": "Empresa 1",\n    "Email": "cliente1@empresa.com",\n    "Telefono": "694770925",\n    "Direccion": "Calle 1, Nº 8",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28191",\n    "Estado": "Inactivo",\n    "Preferencia": "Llamada",\n    "Notas": "Cliente de prueba OmniTech"\n  },\n  {\n    "ID": 2,\n    "Nombre": "Laura López",\n    "Empresa": "Empresa 2",\n    "Email": "cliente2@empresa.com",\n    "Telefono": "614891780",\n    "Direccion": "Calle 2, Nº 27",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28922",\n    "Estado": "Activo",\n    "Preferencia": "WhatsApp",\n    "Notas": "Cliente de prueba OmniTech"\n  },\n  {\n    "ID": 3,\n    "Nombre": "Marta García",\n    "Empresa": "Empresa 3",\n    "Email": "cliente3@empresa.com",\n    "Telefono": "617216900",\n    "Direccion": "Calle 3, Nº 84",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28818",\n    "Estado": "Prospecto",\n    "Preferencia": "Email",\n    "Notas": "Cliente de prueba OmniTech"\n  },\n  {\n    "ID": 4,\n    "Nombre": "Luis Torres",\n    "Empresa": "Empresa 4",\n    "Email": "cliente4@empresa.com",\n    "Telefono": "641745314",\n    "Direccion": "Calle 4, Nº 61",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28250",\n    "Estado": "Prospecto",\n    "Preferencia": "WhatsApp",\n    "Notas": "Cliente de prueba OmniTech"\n  },\n  {\n    "ID": 5,\n    "Nombre": "David Ortega",\n    "Empresa": "Empresa 5",\n    "Email": "cliente5@empresa.com",\n    "Telefono": "676537919",\n    "Direccion": "Calle 5, Nº 7",\n    "Ciudad": "Madrid",\n    "Provincia": "Madrid",\n    "CP": "28560",\n    "Estado": "Activo",\n    "Preferencia": "Llamada",\n    "Notas": "Cliente de prueba OmniTech"\n  }\n]	{"records": [{"cif": null, "name": "Elena Ortega", "tags": null, "email": "cliente1@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "694770925", "value": null, "status": "prospect", "address": "Calle 1, Nº 8, Madrid, Madrid, 28191", "company": "Empresa 1", "website": null, "position": null}, {"cif": null, "name": "Laura López", "tags": null, "email": "cliente2@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "614891780", "value": null, "status": "client", "address": "Calle 2, Nº 27, Madrid, Madrid, 28922", "company": "Empresa 2", "website": null, "position": null}, {"cif": null, "name": "Marta García", "tags": null, "email": "cliente3@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "617216900", "value": null, "status": "prospect", "address": "Calle 3, Nº 84, Madrid, Madrid, 28818", "company": "Empresa 3", "website": null, "position": null}, {"cif": null, "name": "Luis Torres", "tags": null, "email": "cliente4@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "641745314", "value": null, "status": "prospect", "address": "Calle 4, Nº 61, Madrid, Madrid, 28250", "company": "Empresa 4", "website": null, "position": null}, {"cif": null, "name": "David Ortega", "tags": null, "email": "cliente5@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "676537919", "value": null, "status": "client", "address": "Calle 5, Nº 7, Madrid, Madrid, 28560", "company": "Empresa 5", "website": null, "position": null}, {"cif": null, "name": "Elena Martín", "tags": null, "email": "cliente6@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "677040185", "value": null, "status": "client", "address": "Calle 6, Nº 30, Madrid, Madrid, 28390", "company": "Empresa 6", "website": null, "position": null}, {"cif": null, "name": "Sara Martín", "tags": null, "email": "cliente7@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "652959920", "value": null, "status": "prospect", "address": "Calle 7, Nº 98, Madrid, Madrid, 28528", "company": "Empresa 7", "website": null, "position": null}, {"cif": null, "name": "Marta Romero", "tags": null, "email": "cliente8@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "610951633", "value": null, "status": "client", "address": "Calle 8, Nº 26, Madrid, Madrid, 28238", "company": "Empresa 8", "website": null, "position": null}, {"cif": null, "name": "Laura García", "tags": null, "email": "cliente9@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "688646441", "value": null, "status": "prospect", "address": "Calle 9, Nº 90, Madrid, Madrid, 28746", "company": "Empresa 9", "website": null, "position": null}, {"cif": null, "name": "Javier García", "tags": null, "email": "cliente10@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "659351597", "value": null, "status": "prospect", "address": "Calle 10, Nº 65, Madrid, Madrid, 28892", "company": "Empresa 10", "website": null, "position": null}, {"cif": null, "name": "Carlos Pérez", "tags": null, "email": "cliente11@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "672084505", "value": null, "status": "client", "address": "Calle 11, Nº 35, Madrid, Madrid, 28277", "company": "Empresa 11", "website": null, "position": null}, {"cif": null, "name": "Carlos García", "tags": null, "email": "cliente12@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "617083712", "value": null, "status": "client", "address": "Calle 12, Nº 18, Madrid, Madrid, 28904", "company": "Empresa 12", "website": null, "position": null}, {"cif": null, "name": "Carlos Sánchez", "tags": null, "email": "cliente13@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "639076468", "value": null, "status": "prospect", "address": "Calle 13, Nº 7, Madrid, Madrid, 28176", "company": "Empresa 13", "website": null, "position": null}, {"cif": null, "name": "Javier Torres", "tags": null, "email": "cliente14@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "679528055", "value": null, "status": "client", "address": "Calle 14, Nº 62, Madrid, Madrid, 28452", "company": "Empresa 14", "website": null, "position": null}, {"cif": null, "name": "Luis Pérez", "tags": null, "email": "cliente15@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "653661799", "value": null, "status": "client", "address": "Calle 15, Nº 13, Madrid, Madrid, 28406", "company": "Empresa 15", "website": null, "position": null}, {"cif": null, "name": "Javier García", "tags": null, "email": "cliente16@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "688276040", "value": null, "status": "prospect", "address": "Calle 16, Nº 1, Madrid, Madrid, 28685", "company": "Empresa 16", "website": null, "position": null}, {"cif": null, "name": "David Martín", "tags": null, "email": "cliente17@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "677444929", "value": null, "status": "prospect", "address": "Calle 17, Nº 79, Madrid, Madrid, 28604", "company": "Empresa 17", "website": null, "position": null}, {"cif": null, "name": "Sara Navarro", "tags": null, "email": "cliente18@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "652191563", "value": null, "status": "prospect", "address": "Calle 18, Nº 49, Madrid, Madrid, 28390", "company": "Empresa 18", "website": null, "position": null}, {"cif": null, "name": "Sara Sánchez", "tags": null, "email": "cliente19@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "628471045", "value": null, "status": "client", "address": "Calle 19, Nº 56, Madrid, Madrid, 28883", "company": "Empresa 19", "website": null, "position": null}, {"cif": null, "name": "Elena López", "tags": null, "email": "cliente20@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "613763262", "value": null, "status": "prospect", "address": "Calle 20, Nº 94, Madrid, Madrid, 28139", "company": "Empresa 20", "website": null, "position": null}, {"cif": null, "name": "Marta Romero", "tags": null, "email": "cliente21@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "632230875", "value": null, "status": "prospect", "address": "Calle 21, Nº 16, Madrid, Madrid, 28132", "company": "Empresa 21", "website": null, "position": null}, {"cif": null, "name": "Laura Martín", "tags": null, "email": "cliente22@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "671482392", "value": null, "status": "client", "address": "Calle 22, Nº 21, Madrid, Madrid, 28503", "company": "Empresa 22", "website": null, "position": null}, {"cif": null, "name": "Javier López", "tags": null, "email": "cliente23@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "618211430", "value": null, "status": "prospect", "address": "Calle 23, Nº 87, Madrid, Madrid, 28333", "company": "Empresa 23", "website": null, "position": null}, {"cif": null, "name": "Carlos Martín", "tags": null, "email": "cliente24@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "638270204", "value": null, "status": "prospect", "address": "Calle 24, Nº 34, Madrid, Madrid, 28735", "company": "Empresa 24", "website": null, "position": null}, {"cif": null, "name": "Marta López", "tags": null, "email": "cliente25@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "635030747", "value": null, "status": "prospect", "address": "Calle 25, Nº 47, Madrid, Madrid, 28370", "company": "Empresa 25", "website": null, "position": null}, {"cif": null, "name": "Laura López", "tags": null, "email": "cliente26@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "652450419", "value": null, "status": "prospect", "address": "Calle 26, Nº 69, Madrid, Madrid, 28477", "company": "Empresa 26", "website": null, "position": null}, {"cif": null, "name": "Miguel Sánchez", "tags": null, "email": "cliente27@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "618389320", "value": null, "status": "prospect", "address": "Calle 27, Nº 5, Madrid, Madrid, 28262", "company": "Empresa 27", "website": null, "position": null}, {"cif": null, "name": "Miguel Torres", "tags": null, "email": "cliente28@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "651479227", "value": null, "status": "prospect", "address": "Calle 28, Nº 78, Madrid, Madrid, 28890", "company": "Empresa 28", "website": null, "position": null}, {"cif": null, "name": "Javier Torres", "tags": null, "email": "cliente29@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "612859666", "value": null, "status": "prospect", "address": "Calle 29, Nº 14, Madrid, Madrid, 28422", "company": "Empresa 29", "website": null, "position": null}, {"cif": null, "name": "Sara López", "tags": null, "email": "cliente30@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "691990671", "value": null, "status": "prospect", "address": "Calle 30, Nº 52, Madrid, Madrid, 28529", "company": "Empresa 30", "website": null, "position": null}, {"cif": null, "name": "Miguel Martín", "tags": null, "email": "cliente31@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "639319372", "value": null, "status": "prospect", "address": "Calle 31, Nº 89, Madrid, Madrid, 28883", "company": "Empresa 31", "website": null, "position": null}, {"cif": null, "name": "Laura López", "tags": null, "email": "cliente32@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "675060389", "value": null, "status": "client", "address": "Calle 32, Nº 64, Madrid, Madrid, 28426", "company": "Empresa 32", "website": null, "position": null}, {"cif": null, "name": "Miguel Ortega", "tags": null, "email": "cliente33@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "624282297", "value": null, "status": "client", "address": "Calle 33, Nº 56, Madrid, Madrid, 28411", "company": "Empresa 33", "website": null, "position": null}, {"cif": null, "name": "David Navarro", "tags": null, "email": "cliente34@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "684793661", "value": null, "status": "prospect", "address": "Calle 34, Nº 39, Madrid, Madrid, 28198", "company": "Empresa 34", "website": null, "position": null}, {"cif": null, "name": "Ana Navarro", "tags": null, "email": "cliente35@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "623175151", "value": null, "status": "prospect", "address": "Calle 35, Nº 44, Madrid, Madrid, 28331", "company": "Empresa 35", "website": null, "position": null}, {"cif": null, "name": "Laura Martín", "tags": null, "email": "cliente36@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "630417898", "value": null, "status": "client", "address": "Calle 36, Nº 48, Madrid, Madrid, 28861", "company": "Empresa 36", "website": null, "position": null}, {"cif": null, "name": "Miguel Torres", "tags": null, "email": "cliente37@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "617225870", "value": null, "status": "client", "address": "Calle 37, Nº 23, Madrid, Madrid, 28422", "company": "Empresa 37", "website": null, "position": null}, {"cif": null, "name": "Elena Martín", "tags": null, "email": "cliente38@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "672603427", "value": null, "status": "client", "address": "Calle 38, Nº 9, Madrid, Madrid, 28868", "company": "Empresa 38", "website": null, "position": null}, {"cif": null, "name": "Luis Ruiz", "tags": null, "email": "cliente39@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "684209246", "value": null, "status": "prospect", "address": "Calle 39, Nº 93, Madrid, Madrid, 28512", "company": "Empresa 39", "website": null, "position": null}, {"cif": null, "name": "David García", "tags": null, "email": "cliente40@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "622565668", "value": null, "status": "prospect", "address": "Calle 40, Nº 70, Madrid, Madrid, 28589", "company": "Empresa 40", "website": null, "position": null}, {"cif": null, "name": "Elena Navarro", "tags": null, "email": "cliente41@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "646419371", "value": null, "status": "prospect", "address": "Calle 41, Nº 60, Madrid, Madrid, 28796", "company": "Empresa 41", "website": null, "position": null}, {"cif": null, "name": "Sara Ruiz", "tags": null, "email": "cliente42@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "657508317", "value": null, "status": "prospect", "address": "Calle 42, Nº 46, Madrid, Madrid, 28108", "company": "Empresa 42", "website": null, "position": null}, {"cif": null, "name": "Elena Romero", "tags": null, "email": "cliente43@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "673478683", "value": null, "status": "prospect", "address": "Calle 43, Nº 98, Madrid, Madrid, 28541", "company": "Empresa 43", "website": null, "position": null}, {"cif": null, "name": "Miguel García", "tags": null, "email": "cliente44@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "646395654", "value": null, "status": "client", "address": "Calle 44, Nº 6, Madrid, Madrid, 28949", "company": "Empresa 44", "website": null, "position": null}, {"cif": null, "name": "Carlos Sánchez", "tags": null, "email": "cliente45@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "627370608", "value": null, "status": "prospect", "address": "Calle 45, Nº 57, Madrid, Madrid, 28263", "company": "Empresa 45", "website": null, "position": null}, {"cif": null, "name": "Sara García", "tags": null, "email": "cliente46@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "643955381", "value": null, "status": "prospect", "address": "Calle 46, Nº 81, Madrid, Madrid, 28200", "company": "Empresa 46", "website": null, "position": null}, {"cif": null, "name": "David Ruiz", "tags": null, "email": "cliente47@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "670716911", "value": null, "status": "client", "address": "Calle 47, Nº 23, Madrid, Madrid, 28940", "company": "Empresa 47", "website": null, "position": null}, {"cif": null, "name": "Carlos Ruiz", "tags": null, "email": "cliente48@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "643315338", "value": null, "status": "prospect", "address": "Calle 48, Nº 15, Madrid, Madrid, 28589", "company": "Empresa 48", "website": null, "position": null}, {"cif": null, "name": "David López", "tags": null, "email": "cliente49@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "625904237", "value": null, "status": "client", "address": "Calle 49, Nº 49, Madrid, Madrid, 28316", "company": "Empresa 49", "website": null, "position": null}, {"cif": null, "name": "Sara García", "tags": null, "email": "cliente50@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "664230928", "value": null, "status": "prospect", "address": "Calle 50, Nº 18, Madrid, Madrid, 28543", "company": "Empresa 50", "website": null, "position": null}, {"cif": null, "name": "David Torres", "tags": null, "email": "cliente51@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "626872360", "value": null, "status": "prospect", "address": "Calle 51, Nº 72, Madrid, Madrid, 28659", "company": "Empresa 51", "website": null, "position": null}, {"cif": null, "name": "Laura Martín", "tags": null, "email": "cliente52@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "643496619", "value": null, "status": "client", "address": "Calle 52, Nº 46, Madrid, Madrid, 28905", "company": "Empresa 52", "website": null, "position": null}, {"cif": null, "name": "Laura Torres", "tags": null, "email": "cliente53@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "628053374", "value": null, "status": "prospect", "address": "Calle 53, Nº 45, Madrid, Madrid, 28932", "company": "Empresa 53", "website": null, "position": null}, {"cif": null, "name": "Marta Torres", "tags": null, "email": "cliente54@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "693848579", "value": null, "status": "prospect", "address": "Calle 54, Nº 85, Madrid, Madrid, 28779", "company": "Empresa 54", "website": null, "position": null}, {"cif": null, "name": "Carlos Pérez", "tags": null, "email": "cliente55@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "622193283", "value": null, "status": "prospect", "address": "Calle 55, Nº 23, Madrid, Madrid, 28525", "company": "Empresa 55", "website": null, "position": null}, {"cif": null, "name": "Carlos Navarro", "tags": null, "email": "cliente56@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "645142774", "value": null, "status": "prospect", "address": "Calle 56, Nº 9, Madrid, Madrid, 28862", "company": "Empresa 56", "website": null, "position": null}, {"cif": null, "name": "Javier García", "tags": null, "email": "cliente57@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "672235027", "value": null, "status": "prospect", "address": "Calle 57, Nº 22, Madrid, Madrid, 28723", "company": "Empresa 57", "website": null, "position": null}, {"cif": null, "name": "Ana Ruiz", "tags": null, "email": "cliente58@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "699343039", "value": null, "status": "prospect", "address": "Calle 58, Nº 6, Madrid, Madrid, 28793", "company": "Empresa 58", "website": null, "position": null}, {"cif": null, "name": "Elena Navarro", "tags": null, "email": "cliente59@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "662076422", "value": null, "status": "prospect", "address": "Calle 59, Nº 96, Madrid, Madrid, 28227", "company": "Empresa 59", "website": null, "position": null}, {"cif": null, "name": "Javier López", "tags": null, "email": "cliente60@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "695245052", "value": null, "status": "prospect", "address": "Calle 60, Nº 96, Madrid, Madrid, 28885", "company": "Empresa 60", "website": null, "position": null}, {"cif": null, "name": "David Ruiz", "tags": null, "email": "cliente61@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "673938075", "value": null, "status": "client", "address": "Calle 61, Nº 15, Madrid, Madrid, 28875", "company": "Empresa 61", "website": null, "position": null}, {"cif": null, "name": "Luis Navarro", "tags": null, "email": "cliente62@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "689932699", "value": null, "status": "client", "address": "Calle 62, Nº 91, Madrid, Madrid, 28467", "company": "Empresa 62", "website": null, "position": null}, {"cif": null, "name": "Carlos Ruiz", "tags": null, "email": "cliente63@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "680125407", "value": null, "status": "prospect", "address": "Calle 63, Nº 5, Madrid, Madrid, 28413", "company": "Empresa 63", "website": null, "position": null}, {"cif": null, "name": "David Pérez", "tags": null, "email": "cliente64@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "655160623", "value": null, "status": "client", "address": "Calle 64, Nº 67, Madrid, Madrid, 28155", "company": "Empresa 64", "website": null, "position": null}, {"cif": null, "name": "Carlos García", "tags": null, "email": "cliente65@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "690232215", "value": null, "status": "client", "address": "Calle 65, Nº 97, Madrid, Madrid, 28978", "company": "Empresa 65", "website": null, "position": null}, {"cif": null, "name": "Marta Torres", "tags": null, "email": "cliente66@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "617273857", "value": null, "status": "client", "address": "Calle 66, Nº 49, Madrid, Madrid, 28732", "company": "Empresa 66", "website": null, "position": null}, {"cif": null, "name": "Ana Navarro", "tags": null, "email": "cliente67@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "616831738", "value": null, "status": "prospect", "address": "Calle 67, Nº 61, Madrid, Madrid, 28328", "company": "Empresa 67", "website": null, "position": null}, {"cif": null, "name": "David López", "tags": null, "email": "cliente68@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "636315141", "value": null, "status": "prospect", "address": "Calle 68, Nº 43, Madrid, Madrid, 28607", "company": "Empresa 68", "website": null, "position": null}, {"cif": null, "name": "Ana Torres", "tags": null, "email": "cliente69@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "672514158", "value": null, "status": "prospect", "address": "Calle 69, Nº 3, Madrid, Madrid, 28556", "company": "Empresa 69", "website": null, "position": null}, {"cif": null, "name": "Javier Romero", "tags": null, "email": "cliente70@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "656964782", "value": null, "status": "prospect", "address": "Calle 70, Nº 90, Madrid, Madrid, 28510", "company": "Empresa 70", "website": null, "position": null}, {"cif": null, "name": "Miguel Sánchez", "tags": null, "email": "cliente71@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "654151768", "value": null, "status": "prospect", "address": "Calle 71, Nº 65, Madrid, Madrid, 28283", "company": "Empresa 71", "website": null, "position": null}, {"cif": null, "name": "Carlos Martín", "tags": null, "email": "cliente72@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "640701881", "value": null, "status": "client", "address": "Calle 72, Nº 24, Madrid, Madrid, 28433", "company": "Empresa 72", "website": null, "position": null}, {"cif": null, "name": "Laura García", "tags": null, "email": "cliente73@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "623283169", "value": null, "status": "prospect", "address": "Calle 73, Nº 14, Madrid, Madrid, 28931", "company": "Empresa 73", "website": null, "position": null}, {"cif": null, "name": "Luis Pérez", "tags": null, "email": "cliente74@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "644708025", "value": null, "status": "prospect", "address": "Calle 74, Nº 79, Madrid, Madrid, 28407", "company": "Empresa 74", "website": null, "position": null}, {"cif": null, "name": "Miguel Sánchez", "tags": null, "email": "cliente75@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "667176748", "value": null, "status": "client", "address": "Calle 75, Nº 62, Madrid, Madrid, 28474", "company": "Empresa 75", "website": null, "position": null}, {"cif": null, "name": "Marta Pérez", "tags": null, "email": "cliente76@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "651048290", "value": null, "status": "prospect", "address": "Calle 76, Nº 59, Madrid, Madrid, 28688", "company": "Empresa 76", "website": null, "position": null}, {"cif": null, "name": "Luis Sánchez", "tags": null, "email": "cliente77@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "612621152", "value": null, "status": "prospect", "address": "Calle 77, Nº 82, Madrid, Madrid, 28478", "company": "Empresa 77", "website": null, "position": null}, {"cif": null, "name": "Ana Sánchez", "tags": null, "email": "cliente78@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "653636582", "value": null, "status": "prospect", "address": "Calle 78, Nº 22, Madrid, Madrid, 28865", "company": "Empresa 78", "website": null, "position": null}, {"cif": null, "name": "Sara Pérez", "tags": null, "email": "cliente79@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "648909608", "value": null, "status": "client", "address": "Calle 79, Nº 12, Madrid, Madrid, 28121", "company": "Empresa 79", "website": null, "position": null}, {"cif": null, "name": "Ana Pérez", "tags": null, "email": "cliente80@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "690514417", "value": null, "status": "prospect", "address": "Calle 80, Nº 20, Madrid, Madrid, 28767", "company": "Empresa 80", "website": null, "position": null}, {"cif": null, "name": "Elena Pérez", "tags": null, "email": "cliente81@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "673432403", "value": null, "status": "client", "address": "Calle 81, Nº 59, Madrid, Madrid, 28134", "company": "Empresa 81", "website": null, "position": null}, {"cif": null, "name": "David Ruiz", "tags": null, "email": "cliente82@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "644422831", "value": null, "status": "client", "address": "Calle 82, Nº 39, Madrid, Madrid, 28387", "company": "Empresa 82", "website": null, "position": null}, {"cif": null, "name": "Sara García", "tags": null, "email": "cliente83@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "621572998", "value": null, "status": "client", "address": "Calle 83, Nº 87, Madrid, Madrid, 28644", "company": "Empresa 83", "website": null, "position": null}, {"cif": null, "name": "Ana Pérez", "tags": null, "email": "cliente84@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "631354305", "value": null, "status": "client", "address": "Calle 84, Nº 92, Madrid, Madrid, 28135", "company": "Empresa 84", "website": null, "position": null}, {"cif": null, "name": "David Ortega", "tags": null, "email": "cliente85@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "696310266", "value": null, "status": "client", "address": "Calle 85, Nº 93, Madrid, Madrid, 28782", "company": "Empresa 85", "website": null, "position": null}, {"cif": null, "name": "Sara Navarro", "tags": null, "email": "cliente86@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "671729151", "value": null, "status": "prospect", "address": "Calle 86, Nº 59, Madrid, Madrid, 28376", "company": "Empresa 86", "website": null, "position": null}, {"cif": null, "name": "Sara Romero", "tags": null, "email": "cliente87@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "668715937", "value": null, "status": "prospect", "address": "Calle 87, Nº 89, Madrid, Madrid, 28842", "company": "Empresa 87", "website": null, "position": null}, {"cif": null, "name": "Miguel Ruiz", "tags": null, "email": "cliente88@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "664225241", "value": null, "status": "client", "address": "Calle 88, Nº 60, Madrid, Madrid, 28252", "company": "Empresa 88", "website": null, "position": null}, {"cif": null, "name": "Carlos Torres", "tags": null, "email": "cliente89@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "659225376", "value": null, "status": "prospect", "address": "Calle 89, Nº 68, Madrid, Madrid, 28698", "company": "Empresa 89", "website": null, "position": null}, {"cif": null, "name": "Javier Martín", "tags": null, "email": "cliente90@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "638976364", "value": null, "status": "client", "address": "Calle 90, Nº 76, Madrid, Madrid, 28672", "company": "Empresa 90", "website": null, "position": null}, {"cif": null, "name": "Luis Torres", "tags": null, "email": "cliente91@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "653453222", "value": null, "status": "client", "address": "Calle 91, Nº 26, Madrid, Madrid, 28845", "company": "Empresa 91", "website": null, "position": null}, {"cif": null, "name": "Elena Sánchez", "tags": null, "email": "cliente92@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "680249670", "value": null, "status": "client", "address": "Calle 92, Nº 84, Madrid, Madrid, 28497", "company": "Empresa 92", "website": null, "position": null}, {"cif": null, "name": "Javier García", "tags": null, "email": "cliente93@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "625300075", "value": null, "status": "prospect", "address": "Calle 93, Nº 38, Madrid, Madrid, 28688", "company": "Empresa 93", "website": null, "position": null}, {"cif": null, "name": "Miguel Martín", "tags": null, "email": "cliente94@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "614394031", "value": null, "status": "prospect", "address": "Calle 94, Nº 4, Madrid, Madrid, 28421", "company": "Empresa 94", "website": null, "position": null}, {"cif": null, "name": "Elena García", "tags": null, "email": "cliente95@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "664772445", "value": null, "status": "prospect", "address": "Calle 95, Nº 71, Madrid, Madrid, 28386", "company": "Empresa 95", "website": null, "position": null}, {"cif": null, "name": "David Sánchez", "tags": null, "email": "cliente96@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "688807678", "value": null, "status": "client", "address": "Calle 96, Nº 2, Madrid, Madrid, 28317", "company": "Empresa 96", "website": null, "position": null}, {"cif": null, "name": "Carlos Pérez", "tags": null, "email": "cliente97@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "626056189", "value": null, "status": "client", "address": "Calle 97, Nº 6, Madrid, Madrid, 28874", "company": "Empresa 97", "website": null, "position": null}, {"cif": null, "name": "Ana Martín", "tags": null, "email": "cliente98@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "680979291", "value": null, "status": "prospect", "address": "Calle 98, Nº 81, Madrid, Madrid, 28200", "company": "Empresa 98", "website": null, "position": null}, {"cif": null, "name": "Carlos Martín", "tags": null, "email": "cliente99@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "633580305", "value": null, "status": "client", "address": "Calle 99, Nº 58, Madrid, Madrid, 28925", "company": "Empresa 99", "website": null, "position": null}, {"cif": null, "name": "Elena López", "tags": null, "email": "cliente100@empresa.com", "notes": "Cliente de prueba OmniTech", "phone": "654036980", "value": null, "status": "client", "address": "Calle 100, Nº 74, Madrid, Madrid, 28915", "company": "Empresa 100", "website": null, "position": null}], "summary": "El archivo contiene una lista de contactos con información detallada como nombre, empresa, email, teléfono, dirección y estado. Los contactos están clasificados como activos, inactivos o prospectos. (100 registros detectados)", "confidence": 95, "detected_type": "contact_list", "suggested_destination": "CRM"}	CRM	\N	100	\N	2026-06-15 14:42:10.356775
6	8	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	completed	OmniTech_20_Clientes_Ficticios.pdf	pdf	contact_list	95	OmniTech Core - 20 Clientes Ficticios\nDatos de prueba para importar en OmniTech.\nNombre Empresa Email Telefono Estado Valor (€)\nCliente 1 Empresa 1 cliente1@test.com 600111001 Activo 600\nCliente 2 Empresa 2 cliente2@test.com 600111002 Inactivo 700\nCliente 3 Empresa 3 cliente3@test.com 600111003 Prospecto 800\nCliente 4 Empresa 4 cliente4@test.com 600111004 Activo 900\nCliente 5 Empresa 5 cliente5@test.com 600111005 Inactivo 1000\nCliente 6 Empresa 6 cliente6@test.com 600111006 Prospecto 1100\nCliente 7 Empresa 7 cliente7@test.com 600111007 Activo 1200\nCliente 8 Empresa 8 cliente8@test.com 600111008 Inactivo 1300\nCliente 9 Empresa 9 cliente9@test.com 600111009 Prospecto 1400\nCliente 10 Empresa 10 cliente10@test.com 600111010 Activo 1500\nCliente 11 Empresa 11 cliente11@test.com 600111011 Inactivo 1600\nCliente 12 Empresa 12 cliente12@test.com 600111012 Prospecto 1700\nCliente 13 Empresa 13 cliente13@test.com 600111013 Activo 1800\nCliente 14 Empresa 14 cliente14@test.com 600111014 Inactivo 1900\nCliente 15 Empresa 15 cliente15@test.com 600111015 Prospecto 2000\nCliente 16 Empresa 16 cliente16@test.com 600111016 Activo 2100\nCliente 17 Empresa 17 cliente17@test.com 600111017 Inactivo 2200\nCliente 18 Empresa 18 cliente18@test.com 600111018 Prospecto 2300\nCliente 19 Empresa 19 cliente19@test.com 600111019 Activo 2400\nCliente 20 Empresa 20 cliente20@test.com 600111020 Inactivo 2500\n\n-- 1 of 1 --\n\n	{"records": [{"cif": null, "name": "Cliente 1", "tags": null, "email": "cliente1@test.com", "notes": null, "phone": "600111001", "value": 600, "status": "client", "address": null, "company": "Empresa 1", "website": null, "position": null}, {"cif": null, "name": "Cliente 2", "tags": null, "email": "cliente2@test.com", "notes": null, "phone": "600111002", "value": 700, "status": "client", "address": null, "company": "Empresa 2", "website": null, "position": null}, {"cif": null, "name": "Cliente 3", "tags": null, "email": "cliente3@test.com", "notes": null, "phone": "600111003", "value": 800, "status": "prospect", "address": null, "company": "Empresa 3", "website": null, "position": null}, {"cif": null, "name": "Cliente 4", "tags": null, "email": "cliente4@test.com", "notes": null, "phone": "600111004", "value": 900, "status": "client", "address": null, "company": "Empresa 4", "website": null, "position": null}, {"cif": null, "name": "Cliente 5", "tags": null, "email": "cliente5@test.com", "notes": null, "phone": "600111005", "value": 1000, "status": "client", "address": null, "company": "Empresa 5", "website": null, "position": null}, {"cif": null, "name": "Cliente 6", "tags": null, "email": "cliente6@test.com", "notes": null, "phone": "600111006", "value": 1100, "status": "prospect", "address": null, "company": "Empresa 6", "website": null, "position": null}, {"cif": null, "name": "Cliente 7", "tags": null, "email": "cliente7@test.com", "notes": null, "phone": "600111007", "value": 1200, "status": "client", "address": null, "company": "Empresa 7", "website": null, "position": null}, {"cif": null, "name": "Cliente 8", "tags": null, "email": "cliente8@test.com", "notes": null, "phone": "600111008", "value": 1300, "status": "client", "address": null, "company": "Empresa 8", "website": null, "position": null}, {"cif": null, "name": "Cliente 9", "tags": null, "email": "cliente9@test.com", "notes": null, "phone": "600111009", "value": 1400, "status": "prospect", "address": null, "company": "Empresa 9", "website": null, "position": null}, {"cif": null, "name": "Cliente 10", "tags": null, "email": "cliente10@test.com", "notes": null, "phone": "600111010", "value": 1500, "status": "client", "address": null, "company": "Empresa 10", "website": null, "position": null}, {"cif": null, "name": "Cliente 11", "tags": null, "email": "cliente11@test.com", "notes": null, "phone": "600111011", "value": 1600, "status": "client", "address": null, "company": "Empresa 11", "website": null, "position": null}, {"cif": null, "name": "Cliente 12", "tags": null, "email": "cliente12@test.com", "notes": null, "phone": "600111012", "value": 1700, "status": "prospect", "address": null, "company": "Empresa 12", "website": null, "position": null}, {"cif": null, "name": "Cliente 13", "tags": null, "email": "cliente13@test.com", "notes": null, "phone": "600111013", "value": 1800, "status": "client", "address": null, "company": "Empresa 13", "website": null, "position": null}, {"cif": null, "name": "Cliente 14", "tags": null, "email": "cliente14@test.com", "notes": null, "phone": "600111014", "value": 1900, "status": "client", "address": null, "company": "Empresa 14", "website": null, "position": null}, {"cif": null, "name": "Cliente 15", "tags": null, "email": "cliente15@test.com", "notes": null, "phone": "600111015", "value": 2000, "status": "prospect", "address": null, "company": "Empresa 15", "website": null, "position": null}, {"cif": null, "name": "Cliente 16", "tags": null, "email": "cliente16@test.com", "notes": null, "phone": "600111016", "value": 2100, "status": "client", "address": null, "company": "Empresa 16", "website": null, "position": null}, {"cif": null, "name": "Cliente 17", "tags": null, "email": "cliente17@test.com", "notes": null, "phone": "600111017", "value": 2200, "status": "client", "address": null, "company": "Empresa 17", "website": null, "position": null}, {"cif": null, "name": "Cliente 18", "tags": null, "email": "cliente18@test.com", "notes": null, "phone": "600111018", "value": 2300, "status": "prospect", "address": null, "company": "Empresa 18", "website": null, "position": null}, {"cif": null, "name": "Cliente 19", "tags": null, "email": "cliente19@test.com", "notes": null, "phone": "600111019", "value": 2400, "status": "client", "address": null, "company": "Empresa 19", "website": null, "position": null}, {"cif": null, "name": "Cliente 20", "tags": null, "email": "cliente20@test.com", "notes": null, "phone": "600111020", "value": 2500, "status": "client", "address": null, "company": "Empresa 20", "website": null, "position": null}], "summary": "Lista de 20 clientes ficticios con información de contacto y estado para importar en OmniTech.", "confidence": 95, "detected_type": "contact_list", "suggested_destination": "CRM"}	CRM	\N	20	\N	2026-06-15 14:44:25.610794
\.


--
-- Data for Name: integration_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_events (id, org_id, integration_slug, direction, event_type, status, summary, error_message, created_at, payload_json) FROM stdin;
26	10	whatsapp	outbound	connected	processed	Integración "WhatsApp Business" configurada	\N	2026-06-16 07:12:22.482258	\N
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integrations (id, slug, name, category, auth_type, description, icon_slug, plan_required, is_active, sort_order) FROM stdin;
1	whatsapp	WhatsApp Business	communication	api_key	Recibe y envía mensajes automáticamente. Activa la aceptación de presupuestos vía WhatsApp.	MessageCircle	free	t	0
2	stripe	Stripe	payments	api_key	Procesa pagos y rastrea cobros automáticamente cuando se aceptan presupuestos.	CreditCard	pro	t	1
3	webhook_outbound	Webhooks Salientes	automation	webhook	Envía eventos del CRM a cualquier URL. Conecta con Zapier, Make o tu sistema propio.	Globe	free	t	2
4	gmail	Gmail	communication	oauth2	Envía emails directamente desde el CRM usando tu cuenta de Gmail.	Mail	pro	t	3
5	google_calendar	Google Calendar	calendar	oauth2	Sincroniza citas del CRM con tu Google Calendar en tiempo real.	CalendarDays	pro	t	4
6	slack	Slack	automation	oauth2	Recibe notificaciones cuando se aceptan presupuestos o se añaden nuevos clientes.	Hash	pro	t	5
31	telegram	Telegram Bot	communication	api_key	Envía notificaciones y mensajes a clientes vía Telegram usando tu propio bot.	Send	free	t	6
\.


--
-- Data for Name: license_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.license_plans (id, org_id, plan, seats, valid_from, valid_until, is_active, billing_cycle, notes, assigned_by, created_at, updated_at) FROM stdin;
2	10	professional	10	2026-03-17 12:56:10.80667	\N	t	monthly	Plan demo para presentaciones comerciales	system	2026-06-15 12:56:10.80667	2026-06-15 12:56:10.80667
3	20	starter	5	2026-06-15 12:57:10.271339	\N	t	monthly	Workspace limpio para primeros clientes reales	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
\.


--
-- Data for Name: memory_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.memory_history (id, memory_id, org_id, action, prev_title, new_title, prev_val, new_val, source, changed_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, client_id, content, direction, is_ai, status, created_at, org_id) FROM stdin;
30	204	Hola! Vi vuestra web y me interesa saber más sobre el CRM para mi restaurante. Tengo 3 locales.	inbound	f	read	2026-06-07 22:36:18.48976	10
31	204	¡Hola Pepe! Encantados. Tenemos un módulo específico para hostelería. ¿Cuándo tienes 30 minutos para una demo?	outbound	f	sent	2026-06-07 21:53:18.48976	10
32	204	Perfecto! El viernes que viene a las 11h me va bien.	inbound	f	read	2026-06-07 21:13:18.48976	10
33	202	Buenos días. ¿Ya está lista la propuesta del e-Commerce? Tenemos presión del equipo comercial.	inbound	f	read	2026-06-13 03:48:18.48976	10
34	202	Buenos días Roberto! Sí, el presupuesto ya está. Te lo enviamos hoy por la tarde. ¿Prefieres que lo repasemos juntos en llamada?	outbound	f	sent	2026-06-13 03:23:18.48976	10
35	206	Hola! Soy de Peluquería Estilo Moderno. Me pasaron vuestro contacto. Necesitamos sistema para que los clientes reserven cita online.	inbound	f	read	2026-06-10 01:58:18.48976	10
\.


--
-- Data for Name: module_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.module_configs (id, org_id, module_slug, is_enabled, config, updated_by, created_at, updated_at) FROM stdin;
1	20	crm	t	{"maxClients": 100}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
2	20	quotes	t	{"taxRate": 21, "currency": "EUR"}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
3	20	calendar	t	{"reminderHours": 24}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
4	20	whatsapp	f	{"demoMode": false}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
5	20	ai_chat	t	{"model": "gpt-4o-mini"}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
6	20	import_ai	t	{}	system	2026-06-15 12:57:10.271339	2026-06-15 12:57:10.271339
7	10	crm	t	{"maxClients": 500}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
8	10	quotes	t	{"taxRate": 21, "currency": "EUR"}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
9	10	calendar	t	{"reminderHours": 24}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
10	10	whatsapp	t	{"demoMode": true}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
11	10	ai_chat	t	{"model": "gpt-4o-mini"}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
12	10	import_ai	t	{}	system	2026-06-15 12:58:18.48976	2026-06-15 12:58:18.48976
\.


--
-- Data for Name: org_integrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_integrations (id, org_id, integration_slug, status, config, credentials_enc, display_name, external_id, last_synced_at, expires_at, error_message, created_at, updated_at) FROM stdin;
5	10	whatsapp	active	\N	eyJwaG9uZU51bWJlcklkIjoiICAgIDEyMDIwNzE0NTk2NTQwMTAifQ==	\N	\N	\N	\N	\N	2026-06-16 07:12:22.065126	2026-06-16 07:12:22.065126
\.


--
-- Data for Name: org_invitations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_invitations (id, org_id, invited_by, email, role, token, expires_at, accepted_at, created_at) FROM stdin;
\.


--
-- Data for Name: org_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_members (id, org_id, user_id, role, joined_at, is_suspended) FROM stdin;
8	10	4	owner	2026-06-15 12:56:10.80667	f
9	10	6	owner	2026-06-15 12:56:10.80667	f
10	20	4	owner	2026-06-15 12:57:10.271339	f
11	20	6	owner	2026-06-15 12:57:10.271339	f
12	8	7	owner	2026-06-15 14:41:25.087887	f
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (id, name, slug, plan, logo_url, created_at, status) FROM stdin;
10	OmniTech Demo	omnitech-demo	professional	\N	2026-03-17 12:56:10.80667	active
20	Piloto Clientes	piloto-clientes	starter	\N	2026-06-15 12:57:10.271339	active
8	Demos	demos-0v5w7	free	\N	2026-06-15 14:41:24.97295	active
\.


--
-- Data for Name: platform_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_roles (id, clerk_user_id, role, display_name, email, granted_by, is_active, notes, created_at, updated_at) FROM stdin;
1	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	SUPER_ADMIN	A3 Servicio	a3servicio@gmail.com	system	t	\N	2026-06-14 03:00:29.723995	2026-06-14 03:00:29.723995
2	user_3F2in1cpKPN0a8yR8iRfeK9YZOd	SUPER_ADMIN	OmniTech Core	omnitechcore01@gmail.com	system	t	\N	2026-06-14 03:00:29.723995	2026-06-14 03:00:29.723995
\.


--
-- Data for Name: quote_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quote_items (id, quote_id, description, quantity, unit_price, total, order_index) FROM stdin;
30	15	Hosting servidor VPS dedicado	12	29.99	359.88	0
31	15	Mantenimiento y actualizaciones mensuales	12	45	540	0
32	15	Soporte técnico prioritario (4h/mes)	12	8.34	100.08	0
33	16	Gestión SEO mensual	3	450	1350	0
34	16	Gestión SEM (Google Ads)	3	380	1140	0
35	16	Community management RRSS	3	134.19	402.56	0
36	17	Análisis y diseño arquitectura	1	1200	1200	0
37	17	Desarrollo frontend + backend	1	3800	3800	0
38	17	Integración ERP Sage 50	1	1611.57	1611.57	0
39	18	Diseño logotipo (3 propuestas)	1	250	250	0
40	18	Manual de identidad corporativa	1	180	180	0
41	18	Papelería corporativa (tarjeta, hoja membrete)	1	107.19	107.19	0
42	19	Sesión análisis de procesos (4h)	1	480	480	0
43	19	Configuración y parametrización CRM	1	650	650	0
44	19	Formación equipo comercial (2 sesiones)	2	344.09	688.18	0
45	20	Configuración inicial de la plataforma de automatización de WhatsApp	1	800	800	0
46	20	Desarrollo de flujos de conversación personalizados para seguimiento de leads	1	900	900	1
47	20	Integración con CRM para gestión de leads	1	600	600	2
48	20	Capacitación al equipo sobre el uso de la herramienta	1	200	200	3
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotes (id, org_id, client_id, title, status, currency, subtotal, tax_rate, tax_amount, total, notes, valid_until, created_at, updated_at) FROM stdin;
15	10	202	Mantenimiento Web Corporativa — Plan Anual	sent	EUR	1000	21	210	1210	Incluye hosting, actualizaciones y soporte técnico mensual.	2026-06-30 12:58:18.48976	2026-06-10 12:58:18.48976	2026-06-15 12:58:18.48976
16	10	203	Campaña Marketing Digital — Q3 2026	accepted	EUR	2892.56	21	607.44	3500	SEO, SEM y gestión de redes sociales. Duración 3 meses.	2026-07-15 12:58:18.48976	2026-05-26 12:58:18.48976	2026-06-15 12:58:18.48976
17	10	202	Desarrollo e-Commerce B2B con Integración ERP	draft	EUR	6611.57	21	1388.43	8000	Portal de pedidos para clientes industriales. Integración con Sage 50.	2026-07-30 12:58:18.48976	2026-06-13 12:58:18.48976	2026-06-15 12:58:18.48976
18	10	205	Diseño de Identidad Corporativa Completa	sent	EUR	537.19	21	112.81	650	Logo, manual de marca, tarjetas y papelería corporativa.	2026-06-25 12:58:18.48976	2026-06-07 12:58:18.48976	2026-06-15 12:58:18.48976
19	10	209	Consultoría Estratégica CRM — Plan de Implantación	accepted	EUR	1818.18	21	381.82	2200	Análisis, configuración y formación. 4 sesiones presenciales.	2026-07-05 12:58:18.48976	2026-05-31 12:58:18.48976	2026-06-15 12:58:18.48976
20	8	229	Propuesta de Automatización de WhatsApp para Cliente 20	draft	EUR	2500	21	525	3025	Condiciones de pago: 50% al inicio y 50% a la entrega.\nAlcance del servicio: Incluye configuración, desarrollo, integración y capacitación.\nExclusiones: No incluye costos de licencias de software ni mantenimiento posterior.\nValidez de la propuesta: 30 días desde la fecha de emisión.	2026-07-15 14:46:00.21	2026-06-15 14:47:08.275174	2026-06-15 14:47:08.275174
\.


--
-- Data for Name: role_catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_catalog (role, scope, description, priority, created_at) FROM stdin;
SUPER_ADMIN	platform	Acceso total a la plataforma OmniTech	100	2026-06-14 03:34:25.28287
STAFF_OMNITECH	platform	Personal interno de OmniTech	90	2026-06-14 03:34:25.28287
owner	org	Propietario de la organización	80	2026-06-14 03:34:25.28287
admin	org	Administrador de la organización	70	2026-06-14 03:34:25.28287
member	org	Miembro estándar de la organización	60	2026-06-14 03:34:25.28287
read_only	org	Acceso de solo lectura	50	2026-06-14 03:34:25.28287
CLIENT	client	Usuario cliente externo (sin acceso al CRM)	10	2026-06-14 03:34:25.28287
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, clerk_id, email, name, avatar_url, created_at, status, suspended_reason, suspended_at) FROM stdin;
4	user_3F0QQ8H3pAYgpOdB649Z6mOHCoD	a3servicio@gmail.com	a3servicios servicios	https://img.clerk.com/eyJ0eXBlIjoicHJveHkiLCJzcmMiOiJodHRwczovL2ltYWdlcy5jbGVyay5kZXYvb2F1dGhfZ29vZ2xlL2ltZ18zRjBRUTZldjNoN1hidDc0ajVLeDBuVWlJUWgifQ	2026-06-11 20:24:48.772775	active	\N	\N
6	user_3F2in1cpKPN0a8yR8iRfeK9YZOd	omnitechcore01@gmail.com	\N	https://img.clerk.com/eyJ0eXBlIjoiZGVmYXVsdCIsImlpZCI6Imluc18zRXpoclBzWWNmN3E5RmhYMWE2c1QzR0VOakkiLCJyaWQiOiJ1c2VyXzNGMmluMWNwS1BOMGE4eVI4aVJmZUs5WVpPZCJ9	2026-06-12 15:55:29.920529	active	\N	\N
7	user_3F0QXYl1n6KKCsKs7wxRYdgZKJe	javito123451@gmail.com	Javilisto123 123	https://img.clerk.com/eyJ0eXBlIjoicHJveHkiLCJzcmMiOiJodHRwczovL2ltYWdlcy5jbGVyay5kZXYvb2F1dGhfZ29vZ2xlL2ltZ18zRjBRWFZ0VkIwUWkwekZadzVFREhyQUdXVHEifQ	2026-06-15 14:37:20.230219	active	\N	\N
\.


--
-- Name: activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_id_seq', 121, true);


--
-- Name: agent_memory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agent_memory_id_seq', 57, true);


--
-- Name: ai_budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_budgets_id_seq', 2, true);


--
-- Name: ai_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_messages_id_seq', 244, true);


--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_usage_logs_id_seq', 9, true);


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_id_seq', 40, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 38, true);


--
-- Name: backup_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backup_jobs_id_seq', 25, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_id_seq', 229, true);


--
-- Name: import_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.import_jobs_id_seq', 6, true);


--
-- Name: integration_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.integration_events_id_seq', 27, true);


--
-- Name: integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.integrations_id_seq', 423, true);


--
-- Name: license_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.license_plans_id_seq', 3, true);


--
-- Name: memory_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.memory_history_id_seq', 7, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 35, true);


--
-- Name: module_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.module_configs_id_seq', 12, true);


--
-- Name: org_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_integrations_id_seq', 5, true);


--
-- Name: org_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_invitations_id_seq', 3, true);


--
-- Name: org_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_members_id_seq', 12, true);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_id_seq', 8, true);


--
-- Name: platform_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.platform_roles_id_seq', 2, true);


--
-- Name: quote_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quote_items_id_seq', 48, true);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotes_id_seq', 20, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: activity activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id);


--
-- Name: agent_memory agent_memory_org_id_agent_slug_memory_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_org_id_agent_slug_memory_key_unique UNIQUE (org_id, agent_slug, memory_key);


--
-- Name: agent_memory agent_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_pkey PRIMARY KEY (id);


--
-- Name: ai_budgets ai_budgets_org_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_org_id_key UNIQUE (org_id);


--
-- Name: ai_budgets ai_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_pkey PRIMARY KEY (id);


--
-- Name: ai_messages ai_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_sessions ai_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: import_jobs import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_pkey PRIMARY KEY (id);


--
-- Name: integration_events integration_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events
    ADD CONSTRAINT integration_events_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_slug_unique UNIQUE (slug);


--
-- Name: license_plans license_plans_org_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_org_id_key UNIQUE (org_id);


--
-- Name: license_plans license_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_pkey PRIMARY KEY (id);


--
-- Name: memory_history memory_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history
    ADD CONSTRAINT memory_history_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: module_configs module_configs_org_id_module_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_org_id_module_slug_key UNIQUE (org_id, module_slug);


--
-- Name: module_configs module_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_pkey PRIMARY KEY (id);


--
-- Name: org_integrations org_integrations_org_id_integration_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_org_id_integration_slug_unique UNIQUE (org_id, integration_slug);


--
-- Name: org_integrations org_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_pkey PRIMARY KEY (id);


--
-- Name: org_invitations org_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_pkey PRIMARY KEY (id);


--
-- Name: org_invitations org_invitations_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_token_unique UNIQUE (token);


--
-- Name: org_members org_members_org_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_user_id_unique UNIQUE (org_id, user_id);


--
-- Name: org_members org_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_slug_unique UNIQUE (slug);


--
-- Name: platform_roles platform_roles_clerk_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles
    ADD CONSTRAINT platform_roles_clerk_user_id_key UNIQUE (clerk_user_id);


--
-- Name: platform_roles platform_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_roles
    ADD CONSTRAINT platform_roles_pkey PRIMARY KEY (id);


--
-- Name: quote_items quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: role_catalog role_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_catalog
    ADD CONSTRAINT role_catalog_pkey PRIMARY KEY (role);


--
-- Name: users users_clerk_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_clerk_id_unique UNIQUE (clerk_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_usage_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_usage_created ON public.ai_usage_logs USING btree (created_at DESC);


--
-- Name: idx_ai_usage_org_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_usage_org_created ON public.ai_usage_logs USING btree (org_id, created_at DESC);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_actor ON public.audit_logs USING btree (actor_clerk_id);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_org ON public.audit_logs USING btree (org_id);


--
-- Name: idx_import_jobs_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_import_jobs_org ON public.import_jobs USING btree (org_id, created_at DESC);


--
-- Name: activity activity_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: agent_memory agent_memory_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_budgets ai_budgets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_budgets
    ADD CONSTRAINT ai_budgets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_messages ai_messages_session_id_ai_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_session_id_ai_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.ai_sessions(id) ON DELETE CASCADE;


--
-- Name: ai_sessions ai_sessions_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: ai_sessions ai_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_usage_logs ai_usage_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: clients clients_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: import_jobs import_jobs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.import_jobs
    ADD CONSTRAINT import_jobs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: integration_events integration_events_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_events
    ADD CONSTRAINT integration_events_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: license_plans license_plans_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_plans
    ADD CONSTRAINT license_plans_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: memory_history memory_history_memory_id_agent_memory_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory_history
    ADD CONSTRAINT memory_history_memory_id_agent_memory_id_fk FOREIGN KEY (memory_id) REFERENCES public.agent_memory(id) ON DELETE CASCADE;


--
-- Name: messages messages_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: messages messages_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: module_configs module_configs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_configs
    ADD CONSTRAINT module_configs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_integrations org_integrations_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_integrations
    ADD CONSTRAINT org_integrations_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_invitations org_invitations_invited_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_invited_by_users_id_fk FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: org_invitations org_invitations_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_members org_members_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quote_items quote_items_quote_id_quotes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_quote_id_quotes_id_fk FOREIGN KEY (quote_id) REFERENCES public.quotes(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: quotes quotes_org_id_organizations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_org_id_organizations_id_fk FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict eFWmchPtLYXyckRoLb0Hz9dlJ3HuzqjJNeTx1xYogYBrHt9xZCWR0oXRV6EljBJ

